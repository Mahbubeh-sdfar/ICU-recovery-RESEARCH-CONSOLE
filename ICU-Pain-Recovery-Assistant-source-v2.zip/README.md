# ICU Pain & Recovery Assistant

Local research demonstration for exploring **artificially generated postoperative ICU records**, recovery observations, research evidence retrieval, and synthetic-data model experiments. It is not clinically validated and must not be used for patient care.

## Requirements

- Windows 11 (instructions below use PowerShell)
- Python 3.11 or 3.12
- Node.js 22.12 or newer with npm (the frontend uses Vite 8)
- Docker Desktop with Docker Compose v2 (only needed for PostgreSQL/pgvector)
- Ollama for local AI text generation; the initial chat model is `gemma3:4b`

The checked-in patient dataset is `data/synthetic_icu_patients.csv`. It contains 5,000 generated patients and 53,550 longitudinal observation rows. Do not replace it with real patient information.

## Installation and configuration

### Backend and database

From PowerShell at the repository root:

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `backend/.env` before starting services. It contains a development-only database password; choose a private local password and update both `POSTGRES_PASSWORD` and the password in `DATABASE_URL`. Keep `.env` private and out of source control. The Ollama defaults are:

```dotenv
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_CHAT_MODEL=gemma3:4b
OLLAMA_EMBED_MODEL=nomic-embed-text
```

Download local models when using assistant generation or embeddings:

```powershell
ollama pull gemma3:4b
ollama pull nomic-embed-text
```

Start PostgreSQL with pgvector and load the schema and generated cohort:

```powershell
docker compose -f docker-compose.yml up -d
python -m alembic upgrade head
python -m scripts.import_synthetic_dataset
python -m scripts.validate_database
```

PostgreSQL is bound to loopback. `DATABASE_ENABLED=false` selects CSV-backed mode and avoids PostgreSQL for the basic patient, recovery, and cohort endpoints. Database-backed evidence and conversation history require PostgreSQL.

### Start the local stack after setup

Once the backend environment, `backend/.env`, frontend dependencies, and Ollama models are installed, run this from the project root:

```powershell
.\start-local.ps1
```

The script starts Docker Desktop if needed, starts PostgreSQL/pgvector, applies database migrations, imports the bundled synthetic cohort, and launches the API and dashboard on loopback. Check `backend/.tmp/api.err.log` and `frontend/vite.err.log` if startup fails. Docker Desktop must remain running while using the database-backed features.

### Run the backend

From `backend/` with the virtual environment active:

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

- API: <http://127.0.0.1:8000>
- Swagger: <http://127.0.0.1:8000/docs>
- Health: <http://127.0.0.1:8000/health>

### Run the frontend

Open a second terminal at the repository root:

```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```

Open <http://127.0.0.1:5173>. `VITE_API_BASE_URL` selects the API origin; it defaults to `http://127.0.0.1:8000`. FastAPI allows the local Vite origins used by this setup.

## Architecture

```text
React + TypeScript + Vite
        │ REST / JSON
        ▼
FastAPI ── patient/recovery APIs ── CSV synthetic cohort or PostgreSQL
   │
   ├── ML predictions ── scikit-learn/joblib artifacts
   ├── LangGraph workflow ── Ollama provider (local chat + embeddings)
   │                         ├── PostgreSQL + pgvector semantic retrieval when indexed
   │                         └── lexical JSON evidence fallback
   └── research document APIs ── PDF extraction → PostgreSQL text chunks
                                └── separate Ollama embedding/indexing command
```

The backend uses a chat/embedding provider interface with an Ollama adapter. The prior DeepSeek/API-key dependency was removed from the specification; there is no DeepSeek provider in this implementation and no paid LLM account is required.

### Current integration boundary

The LangGraph chat and `POST /api/evidence/search` use `RAGService`: when PostgreSQL is enabled and chunks have embeddings, the query is embedded by Ollama, searched with pgvector cosine distance, and mapped to the original document/chunk/page metadata. When there are no indexed chunks, the service falls back to the local lexical evidence store. The PDF extraction batch remains separate and does not call an LLM; run `python -m scripts.embed_research_documents` after ingestion to create embeddings.

The schema and default `EMBEDDING_DIMENSION` are 768 to match `nomic-embed-text`. Alembic revision `0003_nomic_vector_768` updates an existing empty 384-dimensional embedding column. It deliberately stops if stored embeddings exist, because those must be regenerated and mixed-dimensional vectors must never be silently coerced.

## Usage

- Dashboard: synthetic cohort counts, generated target labels, and observation trends.
- Patient profile: synthetic demographics, surgery, assessments, vital signs, medication exposure, and mobility observations.
- Predictive analytics: 6-hour synthetic-only risk scores with limitations.
- AI assistant: asks for missing patient context, retrieves local passages, cites retrieved sources, and withholds unsafe or unsupported answers.
- Recovery monitoring: descriptive trajectories; it does not judge mobilization safety.
- Research & evaluation: saved model comparison reports and plots from `backend/reports/model_evaluation/`.

Train or regenerate the synthetic ML experiments from `backend/`:

```powershell
python train_models.py
```

The trainer performs a patient-level train/validation/test split and grouped cross-validation. Models are written to `backend/artifacts/` (ignored by source control); metrics and figures are written to `backend/reports/model_evaluation/`. The current report-serving route exposes only these generated evaluation artifacts.

Research PDFs in `data/papers/` are separate from patient histories. Only manifest-approved files are ingested by the protected research-document ingestion endpoint. Configure a private `INGESTION_ADMIN_TOKEN` in `backend/.env` before using it. PDF extraction does not run OCR, create embeddings, or call an LLM. After ingestion and migration, generate vectors in a distinct step:

```powershell
cd backend
python -m scripts.embed_research_documents
```

## Tests and operational checks

With backend dependencies installed, run:

```powershell
cd backend
python -m pytest -q
```

The tests cover API behavior, LangGraph routing and citation checks, database metadata/schema and pgvector configuration, PDF extraction/idempotency, and patient-level ML pipeline behavior. The live vector-RAG smoke test is opt-in and requires the local services and an indexed document:

```powershell
$env:RUN_DB_INTEGRATION = "1"
python -m pytest -q
```

Build the frontend with `npm run build` from `frontend/`.

## Safety, privacy, and limitations

- All bundled patient histories are artificial; research source documents are separate source material.
- Do not enter real patient identifiers or protected health information. Identifier checks are limited pattern checks, not a de-identification guarantee.
- The local API has no general user authentication. Keep it bound to loopback and do not expose it to a network.
- Ollama uses no API key. No provider key is included in source code. Database and ingestion credentials belong in the ignored `.env` file.
- Assistant responses are not autonomous diagnoses or treatment decisions. The system must not prescribe, issue orders, or execute treatment.
- Evidence coverage depends on the local collection. Citations are generated from retrieved source records; insufficient retrieval should result in an explicit limitation.
- Synthetic ML metrics do not establish clinical validity, real-world performance, or treatment benefit. Do not use predictions for care decisions.
- Vector RAG requires PostgreSQL/pgvector, applied migrations, Ollama, and indexed document chunks. In lexical fallback mode, the chat does not search pgvector. When model citations cannot be verified against retrieved passages, the generated draft is withheld and verified source records are returned instead.

See [spec.md](spec.md), [data/data_dictionary.md](data/data_dictionary.md), and [backend/README.md](backend/README.md) for detailed requirements and backend workflows.
