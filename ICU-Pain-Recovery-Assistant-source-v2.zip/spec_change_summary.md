# Specification change summary

Updated `spec.md` to make local Ollama the initial model provider and preserve provider independence across the application.

- Set Ollama at `http://localhost:11434`, with `gemma3:4b` for chat and `nomic-embed-text` for embeddings; added the requested environment variables.
- Removed the initial DeepSeek/API-key dependency. The initial version needs no paid API or external LLM account.
- Specified chat and embedding provider interfaces, with an Ollama adapter, so alternate providers can be added without changing LangGraph or the RAG flow.
- Made LangGraph the agent orchestrator and divided RAG into document chunking, embedding generation, pgvector retrieval, LLM response generation, and citation verification stages.
- Defined safe handling for Ollama unavailable, missing model, timeout, local resource limits, and malformed or empty model responses.
- Preserved the existing clinical safety rules, research goals, synthetic-only data policy, and dataset/outcome definitions.

## Decisions still needing approval

1. Confirm the actual embedding dimension produced by the selected local model and the corresponding pgvector schema/migration plan, including whether any existing vectors need regeneration.
2. Set the minimum supported Windows hardware profile, concurrent request limit, and default timeout/retry policy.
3. Decide whether LangGraph execution state is ephemeral or persisted in PostgreSQL, separately from conversation history.
4. Confirm the first authoritative knowledge-base documents and their versions, as already identified in the original specification.
5. Confirm the English-only initial interface choice, as already identified in the original specification.

No application code or model calls were added as part of this specification revision.
