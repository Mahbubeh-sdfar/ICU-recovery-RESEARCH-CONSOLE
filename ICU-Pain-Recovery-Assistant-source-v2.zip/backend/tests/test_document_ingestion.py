from pathlib import Path
import json

import pymupdf as fitz

from app.services.document_ingestion import (
    chunk_id_for, document_id_for, estimate_tokens, extract_pdf, make_chunks, sha256_bytes,
    ingest_documents,
)
from app.core.config import settings
from app.db.models import ClinicalDocument


def pdf_with_pages(path: Path, pages: list[str]) -> None:
    doc = fitz.open()
    for content in pages:
        page = doc.new_page()
        if content:
            page.insert_text((72, 72), content)
    doc.save(path)
    doc.close()


def test_ids_and_hashes_are_stable():
    digest = sha256_bytes(b"sample")
    assert digest == sha256_bytes(b"sample")
    assert document_id_for("papers/a.pdf") == document_id_for("papers/a.pdf")
    assert chunk_id_for("doc-a", 0, digest) == chunk_id_for("doc-a", 0, digest)
    assert chunk_id_for("doc-a", 1, digest) != chunk_id_for("doc-a", 0, digest)


def test_extraction_and_chunk_pages_are_traceable(tmp_path):
    path = tmp_path / "two-pages.pdf"
    pdf_with_pages(path, ["POSTOPERATIVE PAIN\n" + "Pain assessment paragraph. " * 70,
                         "MOBILIZATION\n" + "Recovery paragraph. " * 70])
    metadata, pages, issue = extract_pdf(path)
    assert issue is None
    assert metadata["page_count"] == 2
    chunks = make_chunks(pages, target=80, overlap=12)
    assert chunks
    assert all(chunk["page_start"] <= chunk["page_end"] for chunk in chunks)
    assert all(chunk["content_sha256"] == sha256_bytes(chunk["text"].encode()) for chunk in chunks)
    assert any("POSTOPERATIVE PAIN" in chunk["text"] for chunk in chunks)
    assert all(chunk["token_count"] == estimate_tokens(chunk["text"]) for chunk in chunks)


def test_image_only_pdf_is_explicitly_flagged_for_ocr(tmp_path):
    path = tmp_path / "scanned.pdf"
    pdf_with_pages(path, [""])
    _, pages, issue = extract_pdf(path)
    assert pages and issue == "needs_ocr"


def test_empty_pages_do_not_create_chunks():
    assert make_chunks([]) == []


def test_manifest_ingestion_is_idempotent_and_stores_original(tmp_path, monkeypatch):
    source_dir = tmp_path / "papers"
    source_dir.mkdir()
    source = source_dir / "article.pdf"
    pdf_with_pages(source, ["PAIN ASSESSMENT\n" + "A source paragraph for traceable educational text. " * 60])
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"documents": [{
        "document_id": "test-document", "file": "article.pdf", "title": "Test source",
        "approved_for_local_ingestion": True,
    }]}), encoding="utf-8")
    storage = tmp_path / "stored"
    monkeypatch.setattr(settings, "research_source_dir", source_dir)
    monkeypatch.setattr(settings, "research_manifest_path", manifest)
    monkeypatch.setattr(settings, "document_storage_dir", storage)

    class FakeSession:
        def __init__(self):
            self.documents = {}

        def get(self, model, key):
            assert model is ClinicalDocument
            return self.documents.get(key)

        def add(self, doc):
            self.documents[doc.document_id] = doc

        def commit(self):
            pass

        def rollback(self):
            pass

    session = FakeSession()
    first = ingest_documents(session)
    second = ingest_documents(session)
    assert first["results"][0]["status"] == "ingested"
    assert first["results"][0]["chunk_count"] > 0
    assert second["results"][0]["status"] == "skipped_unchanged"
    assert (storage / "test-document.pdf").read_bytes() == source.read_bytes()
    chunk = session.documents["test-document"].chunks[0]
    assert chunk.stable_chunk_id.startswith("chk-")
    assert chunk.page_start == chunk.page_end == 1
