from pathlib import Path

import numpy as np
import joblib
from sklearn.linear_model import LogisticRegression

from app.ml.training import (classification_metrics, make_pipeline, patient_level_frame, _prepare_split)
from app.services.dataset import DatasetService
from app.services.predictions import PredictionService


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "synthetic_icu_patients.csv"


def test_model_matrices_are_one_row_per_patient_and_use_preindex_features():
    dataset = DatasetService(DATA)
    for target in ("uncontrolled_pain", "delayed_mobilization"):
        frame = patient_level_frame(dataset, target)
        assert frame.patient_id.is_unique
        assert set(frame.data_split) == {"train", "test"}
        assert "target" in frame
        assert "nrs_pain_score" not in frame
        assert "first_mobilization_hours" not in frame
        assert "icu_length_of_stay_hours" not in frame
        assert "uncontrolled_pain_target" not in frame
        assert "delayed_mobilization_target" not in frame


def test_train_validation_test_partitions_are_disjoint_by_patient():
    frame = patient_level_frame(DatasetService(DATA), "delayed_mobilization")
    splits = _prepare_split(frame)
    patient_sets = {name: set(splits[name].patient_id) for name in ("fit", "validation", "test")}
    assert not patient_sets["fit"] & patient_sets["validation"]
    assert not patient_sets["fit"] & patient_sets["test"]
    assert not patient_sets["validation"] & patient_sets["test"]
    assert set(frame.loc[frame.data_split == "test", "patient_id"]) == patient_sets["test"]


def test_metrics_report_calibration_and_confusion_counts():
    y = np.array([0, 0, 1, 1])
    probabilities = np.array([0.1, 0.6, 0.4, 0.9])
    metrics = classification_metrics(y, probabilities, threshold=0.5)
    assert metrics["auroc"] == 0.75
    assert metrics["confusion_matrix"] == [[1, 1], [1, 1]]
    assert metrics["brier_score"] is not None
    assert metrics["sensitivity"] == 0.5
    assert metrics["specificity"] == 0.5


def test_saved_pipeline_accepts_runtime_prediction_features(tmp_path):
    dataset = DatasetService(DATA)
    frame = patient_level_frame(dataset, "uncontrolled_pain").query("data_split == 'train'").head(300)
    X = frame.drop(columns=["patient_id", "data_split", "target"])
    y = frame.target.to_numpy()
    pipeline = make_pipeline(frame, LogisticRegression(max_iter=1000), scale_numeric=True)
    pipeline.fit(X, y)
    joblib.dump({"pipeline": pipeline, "model_name": "test_model", "model_version": "test"},
                tmp_path / "uncontrolled_pain.joblib")
    patient_id = str(frame.iloc[0].patient_id)
    prediction = PredictionService(dataset, tmp_path).predict(patient_id, "uncontrolled_pain", 6)
    assert 0 <= prediction["probability"] <= 1
