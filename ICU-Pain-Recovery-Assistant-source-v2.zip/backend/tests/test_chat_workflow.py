from pathlib import Path

from fastapi.testclient import TestClient

from app.db.session import get_optional_db
from app.main import create_app
from app.services.chat_workflow import ICUChatWorkflow
from app.services.dataset import DatasetService
from app.services.evidence import EvidenceService
from app.services.predictions import PredictionService


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "synthetic_icu_patients.csv"


class FakeProvider:
    def __init__(self, response="A synthetic data summary."):
        self.response = response
        self.calls = []

    def generate(self, *, system_prompt, user_prompt):
        self.calls.append((system_prompt, user_prompt))
        return self.response


class FakePredictions:
    def __init__(self):
        self.calls = []

    def predict(self, patient_id, target, prediction_time_hours):
        self.calls.append((patient_id, target, prediction_time_hours))
        return {"patient_id": patient_id, "target": target, "probability": 0.4,
                "model_name": "fake", "model_version": "test", "prediction_time_hours": prediction_time_hours,
                "limitations": ["Synthetic-only research estimate."]}


def make_workflow(tmp_path, provider=None, predictions=None):
    dataset = DatasetService(DATA)
    evidence = EvidenceService(tmp_path / "evidence.json")
    return ICUChatWorkflow(dataset, evidence, predictions or FakePredictions(), provider or FakeProvider()), evidence


def test_patient_question_without_id_routes_to_clarification(tmp_path):
    provider = FakeProvider()
    workflow, _ = make_workflow(tmp_path, provider=provider)
    result = workflow.invoke("Summarize this patient's pain trend")
    assert result["clarification_needed"] is True
    assert "synthetic patient ID" in result["answer"]
    assert provider.calls == []


def test_evidence_question_abstains_when_retrieval_is_empty(tmp_path):
    provider = FakeProvider("Unsupported answer.")
    workflow, _ = make_workflow(tmp_path, provider=provider)
    result = workflow.invoke("What does the evidence say about ICU pain management?")
    assert "not return enough relevant evidence" in result["answer"]
    assert result["citations"] == []
    assert any("insufficient" in item.lower() for item in result["limitations"])
    assert provider.calls == []


def test_unsafe_medication_request_is_blocked_before_model_call(tmp_path):
    provider = FakeProvider("Give an opioid at 10 mg.")
    workflow, _ = make_workflow(tmp_path, provider=provider)
    result = workflow.invoke("What opioid dose should I give the patient?")
    assert "can’t" in result["answer"]
    assert result["citations"] == []
    assert provider.calls == []


def test_prediction_routes_with_synthetic_id_and_does_not_send_target_leakage(tmp_path):
    provider = FakeProvider("The available synthetic observations are summarized here.")
    predictions = FakePredictions()
    workflow, _ = make_workflow(tmp_path, provider=provider, predictions=predictions)
    result = workflow.invoke("Estimate risk of uncontrolled pain for SYN-00001")
    assert result["workflow_category"] == "prediction"
    assert predictions.calls == [("SYN-00001", "uncontrolled_pain", 6)]
    assert provider.calls
    user_prompt = provider.calls[0][1]
    for forbidden in ("uncontrolled_pain_target", "delayed_mobilization_target", "first_mobilization_hours",
                      "icu_length_of_stay_hours"):
        assert forbidden not in user_prompt
    assert "Synthetic-only research estimate." in result["limitations"]


def test_retrieved_citation_is_mapped_to_source_record(tmp_path):
    provider = FakeProvider("Pain is discussed in the retrieved source. [E1]")
    workflow, evidence = make_workflow(tmp_path, provider=provider)
    evidence.ingest({"source_id": "test-source", "title": "Test source", "text":
                     "Pain assessment in intensive care is discussed in this educational source. " * 20,
                     "organization": "Test", "year": 2024})
    result = workflow.invoke("What does the evidence say about pain assessment in intensive care?")
    assert result["citations"]
    assert result["citations"][0]["source_id"] == "test-source"
    assert result["citations"][0]["passage_id"].startswith("test-source-P")


def test_invalid_citation_is_blocked(tmp_path):
    provider = FakeProvider("Pain is discussed in the source. [E9]")
    workflow, evidence = make_workflow(tmp_path, provider=provider)
    evidence.ingest({"source_id": "test-source", "title": "Test source", "text":
                     "Pain assessment in intensive care is discussed. " * 20,
                     "organization": "Test", "year": 2024})
    result = workflow.invoke("What does the evidence say about pain assessment?")
    assert result["citations"]
    assert result["citations"][0]["source_id"] == "test-source"
    assert "withheld" in result["answer"].lower()
    assert "no clinical conclusion" in result["answer"].lower()


def test_graph_visualization_contains_all_required_nodes(tmp_path):
    workflow, _ = make_workflow(tmp_path)
    diagram = workflow.mermaid()
    for node in ("query_classifier", "patient_context", "data_validation", "ml_prediction",
                 "evidence_retrieval", "clinical_reasoning", "safety_verification", "response_generation"):
        assert node in diagram
    assert "response_generation" in diagram


def test_chat_api_uses_graph_and_returns_clarification_fields():
    app = create_app()
    app.dependency_overrides[get_optional_db] = lambda: None
    with TestClient(app) as client:
        response = client.post("/api/chat", json={"question": "Summarize this patient's pain trend"})
    assert response.status_code == 200
    body = response.json()
    assert body["workflow_category"] == "pain_assessment"
    assert body["clarification_needed"] is True
    assert body["missing_information"] == ["synthetic patient ID"]
