from __future__ import annotations

from pathlib import Path

import pytest

from app.db.base import Base
from app.db.models import (AIConversationHistory, ClinicalDocument, ClinicalObservation, DocumentChunk,
                           MLPrediction, MedicationRecord, MobilityRecoveryAssessment, PainAssessment, Patient)
from app.db.validation import validate_synthetic_records
from app.schemas.database import VectorSearchRequest
from app.services.dataset import DatasetService
from app.core.errors import ServiceError

ROOT = Path(__file__).resolve().parents[2]


def test_schema_contains_all_requested_tables_and_relationships():
    expected = {"patients", "clinical_observations", "pain_assessments", "medication_records",
                "mobility_recovery_assessments", "ml_predictions", "clinical_documents",
                "document_chunks", "ai_conversation_history"}
    assert expected.issubset(Base.metadata.tables)
    assert Patient.__table__.constraints
    assert ClinicalObservation.__table__.foreign_keys
    assert PainAssessment.__table__.foreign_keys
    assert MedicationRecord.__table__.foreign_keys
    assert MobilityRecoveryAssessment.__table__.foreign_keys
    assert MLPrediction.__table__.foreign_keys
    assert DocumentChunk.__table__.foreign_keys
    assert AIConversationHistory.__table__.foreign_keys


def test_document_chunks_have_pgvector_dimension_and_hnsw_index():
    column = DocumentChunk.__table__.c.embedding
    assert column.type.dim == 768
    assert any(index.name == "ix_document_chunks_embedding_hnsw" for index in DocumentChunk.__table__.indexes)
    assert ClinicalDocument.__table__.c.document_id.primary_key


def test_database_import_validation_rejects_non_synthetic_ids():
    with pytest.raises(ServiceError, match="not synthetic"):
        validate_synthetic_records({"PATIENT-123": [{"observation_id": "a"}]})


def test_bundled_synthetic_dataset_passes_import_validation():
    dataset = DatasetService(ROOT / "data" / "synthetic_icu_patients.csv")
    result = validate_synthetic_records(dataset.all_patient_records())
    assert result["patient_count"] == 5000
    assert result["observation_count"] == 53550


def test_vector_input_requires_configured_dimension():
    with pytest.raises(Exception):
        VectorSearchRequest(embedding=[0.1, 0.2])
    assert len(VectorSearchRequest(embedding=[0.01] * 768, embedding_model="demo-embedding-v1").embedding) == 768


def test_document_chunk_validation_rejects_direct_patient_identifiers():
    from app.schemas.database import DocumentChunkInput
    with pytest.raises(Exception, match="Do not store real patient identifiers"):
        DocumentChunkInput(text="Patient DOB 1980-01-01 and MRN 12345678901")
