from types import SimpleNamespace
from pathlib import Path

import pytest

from app.core.config import settings
from app.core.errors import ServiceError
from app.services.rag import RAGService
from app.services.chat_workflow import ICUChatWorkflow
from app.services.dataset import DatasetService


class FakeLexical:
    def __init__(self):
        self.search_calls = []
        self.sources = {}

    def search(self, query, limit):
        self.search_calls.append((query, limit))
        return [{"source_id": "lexical-source", "title": "Local source", "passage_id": "p1", "text": "pain"}]

    def source(self, source_id):
        if source_id not in self.sources:
            raise ServiceError("source_not_found", "Source unavailable", 404)
        return self.sources[source_id]


class FakeEmbedder:
    def __init__(self):
        self.inputs = []

    def embed(self, texts):
        self.inputs.extend(texts)
        return [[0.01] * settings.embedding_dimension]


class FakeResult:
    def __init__(self, rows):
        self.rows = rows

    def all(self):
        return self.rows


class FakeSession:
    def __init__(self, rows):
        self.rows = rows

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def execute(self, statement):
        return FakeResult(self.rows)


class FakeProvider:
    def generate(self, *, system_prompt, user_prompt):
        assert "Retrieved source" in user_prompt
        return "The retrieved source discusses pain assessment. [E1]"


class FakePredictions:
    def predict(self, *args, **kwargs):
        raise AssertionError("No patient prediction is expected for this evidence-only query.")


def test_vector_rag_embeds_query_and_maps_retrieved_chunk_to_citation():
    chunk = SimpleNamespace(stable_chunk_id="chk-demo", chunk_index=0, page_start=7,
                            page_end=8, page_number=7, section_heading="Pain assessment",
                            text="Source passage text")
    document = SimpleNamespace(document_id="demo-source", title="Demo source",
                               organization_or_authors="Example body", publication_year=2024,
                               source_type="guideline", official_url="https://example.test/source")
    lexical, embedder = FakeLexical(), FakeEmbedder()
    rag = RAGService(lexical, embedder,
                     session_factory=lambda: FakeSession([(chunk, document, 0.12)]),
                     database_enabled=True)

    passages = rag.search("postoperative pain assessment", limit=3)

    assert embedder.inputs == ["search_query: postoperative pain assessment"]
    assert passages[0]["source_id"] == "demo-source"
    assert passages[0]["passage_id"] == "chk-demo"
    assert passages[0]["location"] == "Pain assessment, pages 7–8"
    assert passages[0]["score"] == pytest.approx(0.88)
    assert lexical.search_calls == []


def test_vector_rag_falls_back_to_lexical_only_when_no_indexed_chunks():
    embedder, lexical = FakeEmbedder(), FakeLexical()
    rag = RAGService(lexical, embedder, session_factory=lambda: FakeSession([]), database_enabled=True)

    results = rag.search("postoperative pain", limit=2)

    assert results[0]["source_id"] == "lexical-source"
    assert lexical.search_calls == [("postoperative pain", 2)]


def test_vector_rag_uses_lexical_retrieval_when_database_is_disabled():
    embedder, lexical = FakeEmbedder(), FakeLexical()
    rag = RAGService(lexical, embedder, database_enabled=False)

    results = rag.search("postoperative pain", limit=4)

    assert results[0]["source_id"] == "lexical-source"
    assert embedder.inputs == []
    assert lexical.search_calls == [("postoperative pain", 4)]


def test_langgraph_uses_vector_passage_and_returns_verified_source_citation():
    root = Path(__file__).resolve().parents[2]
    chunk = SimpleNamespace(stable_chunk_id="chk-real-source", chunk_index=0, page_start=2,
                            page_end=2, page_number=2, section_heading="Assessment",
                            text="Retrieved source passage on pain assessment.")
    document = SimpleNamespace(document_id="real-source-id", title="Traceable study",
                               organization_or_authors="Study group", publication_year=2023,
                               source_type="research", official_url="https://example.test/paper")
    rag = RAGService(FakeLexical(), FakeEmbedder(),
                     session_factory=lambda: FakeSession([(chunk, document, 0.08)]),
                     database_enabled=True)
    graph = ICUChatWorkflow(
        DatasetService(root / "data" / "synthetic_icu_patients.csv"), rag,
        FakePredictions(), FakeProvider(),
    )

    result = graph.invoke("What does the evidence say about pain assessment?", include_evidence=True)

    assert result["citations"] == [{
        "source_id": "real-source-id", "title": "Traceable study", "organization": "Study group",
        "year": 2023, "url": "https://example.test/paper", "location": "Assessment, page 2",
        "passage_id": "chk-real-source",
    }]
