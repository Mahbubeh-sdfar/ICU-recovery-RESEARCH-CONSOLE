"""Opt-in smoke test for the local PostgreSQL/pgvector/Ollama path.

Run with RUN_DB_INTEGRATION=1 after Compose, migrations, and document embedding.
"""
import os

import pytest

from app.core.config import settings
from app.services.evidence import EvidenceService
from app.services.rag import RAGService
from app.providers.ollama import OllamaProvider


pytestmark = pytest.mark.skipif(
    os.getenv("RUN_DB_INTEGRATION") != "1",
    reason="requires local PostgreSQL/pgvector and Ollama services",
)


def test_ollama_embedding_retrieves_traceable_pgvector_passage():
    rag = RAGService(
        EvidenceService(settings.evidence_store_path),
        OllamaProvider(),
        database_enabled=True,
    )
    passages = rag.search("adult ICU pain assessment CPOT", limit=3)

    assert passages, "index at least one research document before running this check"
    assert passages[0]["source_id"]
    assert passages[0]["passage_id"]
    assert passages[0]["location"]
    assert passages[0]["text"].strip()
