from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from app.main import create_app
from app.services.chat import ChatService
from app.services.container import Services
from app.services.dataset import DatasetService
from app.services.evidence import EvidenceService
from app.services.predictions import PredictionService
from app.core.errors import ServiceError
from app.db.session import get_optional_db

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "synthetic_icu_patients.csv"


def make_test_app():
    app = create_app()
    app.dependency_overrides[get_optional_db] = lambda: None
    app.state.services = Services()
    return app


def test_patient_listing_and_observations_are_synthetic():
    app = make_test_app()
    with TestClient(app) as client:
        response = client.get("/api/patients", params={"limit": 3})
        assert response.status_code == 200
        body = response.json()
        assert body["total"] == 5000
        assert len(body["items"]) == 3
        assert body["synthetic_data"] is True
        patient_id = body["items"][0]["patient_id"]
        obs = client.get(f"/api/patients/{patient_id}/observations", params={"end_hour": 4}).json()
        assert [r["observation_hours_postop"] for r in obs["items"]] == [0, 4]


def test_validation_and_unknown_patient_have_structured_errors():
    app = make_test_app()
    with TestClient(app) as client:
        invalid = client.get("/api/patients", params={"limit": 9999})
        assert invalid.status_code == 422
        assert invalid.json()["error"]["code"] == "validation_error"
        missing = client.get("/api/patients/SYN-99999")
        assert missing.status_code == 404
        assert missing.json()["error"]["code"] == "patient_not_found"


def test_prediction_index_and_missing_artifact_handled():
    dataset = DatasetService(DATA)
    service = PredictionService(dataset, ROOT / "backend" / "tests" / "empty_models")
    patient = next(iter(dataset.all_patient_records()))
    features = dataset.prediction_features(patient, 6)
    assert "uncontrolled_pain_target" not in features
    assert "first_mobilization_hours" not in features
    assert "icu_length_of_stay_hours" not in features
    with pytest.raises(ServiceError) as error:
        service.predict(patient, "uncontrolled_pain", 6)
    assert error.value.code == "model_unavailable"
    with pytest.raises(ServiceError) as bad_time:
        service.predict(patient, "uncontrolled_pain", 12)
    assert bad_time.value.code == "unsupported_prediction_time"


def test_evidence_citations_only_reference_ingested_passages(tmp_path):
    evidence = EvidenceService(tmp_path / "store.json")
    source = {"source_id": "demo-guideline", "title": "Demonstration source title", "text":
              "Pain assessment and documentation can support communication across care teams. " * 10,
              "organization": "Demo organization", "year": 2024}
    evidence.ingest(source)
    found = evidence.search("pain assessment care teams")
    assert found and found[0]["source_id"] == "demo-guideline"
    assert found[0]["passage_id"].startswith("demo-guideline-P")
    assert evidence.source("demo-guideline")["passage_count"] >= 1


def test_chat_refuses_dosing_and_unavailable_evidence_abstains(tmp_path):
    dataset = DatasetService(DATA)
    evidence = EvidenceService(tmp_path / "store.json")
    chat = ChatService(dataset, evidence)
    refuse = chat.answer("What opioid dose should I give this patient?", None, False)
    assert "can’t prescribe" in refuse["answer"]
    unsupported = chat.answer("What do guidelines say about ICU pain?", None, False)
    assert unsupported["citations"] == []
    assert any("did not provide" in x for x in unsupported["limitations"])


def test_chat_request_rejects_common_real_identifiers():
    app = make_test_app()
    with TestClient(app) as client:
        response = client.post("/api/chat", json={"question": "Summarize the patient with MRN 12345678901"})
        assert response.status_code == 422
        assert response.json()["error"]["code"] == "validation_error"


def test_recovery_endpoint_is_not_a_safety_decision():
    app = make_test_app()
    with TestClient(app) as client:
        response = client.get("/api/recovery/patients/SYN-00001")
        assert response.status_code == 200
        assert "not a mobilization safety assessment" in response.json()["notice"]
