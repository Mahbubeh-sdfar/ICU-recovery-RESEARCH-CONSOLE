import httpx
import pytest

from app.core.errors import ServiceError
from app.providers.ollama import OllamaProvider


def test_missing_ollama_model_maps_to_safe_service_error(monkeypatch):
    def missing_model(*args, **kwargs):
        return httpx.Response(
            400,
            json={"error": "model 'gemma3:4b' not found"},
            request=httpx.Request("POST", "http://localhost:11434/api/chat"),
        )

    monkeypatch.setattr(httpx, "post", missing_model)
    provider = OllamaProvider(base_url="http://localhost:11434", chat_model="gemma3:4b")

    with pytest.raises(ServiceError) as error:
        provider.generate(system_prompt="safe", user_prompt="hello")

    assert error.value.code == "ollama_model_missing"


def test_ollama_empty_chat_response_is_rejected(monkeypatch):
    def empty_response(*args, **kwargs):
        return httpx.Response(
            200,
            json={"message": {"content": "  "}},
            request=httpx.Request("POST", "http://localhost:11434/api/chat"),
        )

    monkeypatch.setattr(httpx, "post", empty_response)
    provider = OllamaProvider(base_url="http://localhost:11434", chat_model="gemma3:4b")

    with pytest.raises(ServiceError) as error:
        provider.generate(system_prompt="safe", user_prompt="hello")

    assert error.value.code == "ollama_invalid_response"


def test_embedding_dimension_must_match_pgvector(monkeypatch):
    def wrong_dimension(*args, **kwargs):
        return httpx.Response(
            200,
            json={"embeddings": [[0.01] * 384]},
            request=httpx.Request("POST", "http://localhost:11434/api/embed"),
        )

    monkeypatch.setattr(httpx, "post", wrong_dimension)
    provider = OllamaProvider(base_url="http://localhost:11434", embed_model="nomic-embed-text")

    with pytest.raises(ServiceError) as error:
        provider.embed(["search_query: postoperative pain"])

    assert error.value.code == "embedding_dimension_mismatch"
