# FastAPI backend

Local REST API for the ICU Pain & Recovery Assistant research prototype. All bundled patient records are artificial. The API is not clinically validated and is not for patient care, treatment, dosing, or mobilization decisions.

## Requirements and setup

Python 3.10 or newer is recommended.

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
docker compose -f docker-compose.yml up -d
python -m alembic upgrade head
```

The default dataset path points to the generated project CSV. To regenerate it from the repository root, run `node data/generate_synthetic_icu.mjs`.

The Compose service runs PostgreSQL 16 with pgvector and binds only to loopback. The included password is for local development; replace `POSTGRES_PASSWORD` and the matching `DATABASE_URL` credentials in `.env` before using a shared machine. Persistent database files live in the Docker volume `icu_postgres_data`.

To keep running the API without PostgreSQL, set `DATABASE_ENABLED=false`. With the database enabled, apply migrations and import the synthetic CSV before using patient routes:

```powershell
cd backend
python -m alembic upgrade head
python -m scripts.import_synthetic_dataset
python -m scripts.validate_database
```

The import refuses to overwrite existing patient rows unless `--replace` is explicitly supplied. It validates the `SYN-` namespace, longitudinal ordering, category values, pain score ranges, and per-patient split/target consistency before importing.

The configured `nomic-embed-text` output and pgvector column use 768 dimensions. Migration `0003_nomic_vector_768` safely upgrades a legacy empty 384-dimensional column and aborts rather than coercing existing vectors. After ingesting authorized PDFs, index chunks in a separate operation:

```powershell
python -m scripts.ingest_research_documents
python -m scripts.embed_research_documents --batch-size 24
```

The embedding command uses Ollama's `search_document:` prefix and stores each vector with its model identifier. Chat query embedding uses `search_query:`. When matching embedded chunks exist, LangGraph retrieves them with pgvector cosine similarity and maps citations to the actual source document, section, and page. If no vector chunks are indexed, it uses the local lexical evidence collection. Do not mix vectors from different models or dimensions.

The Alembic schema includes `patients`, `clinical_observations`, `pain_assessments`, `medication_records`, `mobility_recovery_assessments`, `ml_predictions`, `clinical_documents`, `document_chunks`, and `ai_conversation_history`. Patient, observation, pain, medication, and recovery APIs read from PostgreSQL when `DATABASE_ENABLED=true`; CSV-backed behavior remains available with the flag disabled. Prediction results and chat turns are persisted when PostgreSQL is enabled.

## Run locally

```powershell
cd backend
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Swagger UI: <http://127.0.0.1:8000/docs>  
OpenAPI schema: <http://127.0.0.1:8000/openapi.json>  
Health check: <http://127.0.0.1:8000/health>

## Run the clinician-facing research dashboard

The React/TypeScript dashboard lives in `../frontend/` and connects to FastAPI at `http://127.0.0.1:8000` by default. Start the API in one terminal as above, then in a second PowerShell terminal:

```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```

Open <http://127.0.0.1:5173>. Set `VITE_API_BASE_URL` in `frontend/.env` if the API uses another address. The API allows the local Vite origins and serves saved synthetic model plots at `/model-reports/`. The dashboard labels all patient information as simulated and includes no interface for creating treatment orders.

The service intentionally has no authentication and is for local research use. Keep it bound to loopback; do not expose it to a network or load real patient data. Install Ollama for Windows and download the configured models (`ollama pull gemma3:4b` and `ollama pull nomic-embed-text`) before asking the assistant to generate responses. Defaults are `OLLAMA_BASE_URL=http://localhost:11434`, `OLLAMA_CHAT_MODEL=gemma3:4b`, and `OLLAMA_EMBED_MODEL=nomic-embed-text`; `OLLAMA_TIMEOUT_SECONDS` defaults to 180 and `OLLAMA_NUM_CTX` defaults to 2048 to better fit local-resource constraints. Adjust them for the machine and never treat a timeout as a clinical result.

## Train and evaluate synthetic-data models

Predictions are unavailable until model artifacts are trained. The trainer builds one feature row per patient from baseline data and observations available at or before hour 6. It uses the supplied patient-level `train` partition, creates a stratified patient-level validation split from that partition, and preserves the supplied `test` partition as the final holdout. Five-fold `StratifiedGroupKFold` tuning is grouped by patient ID. Preprocessing (numeric median imputation, categorical mode imputation, missing indicators, one-hot encoding, and numeric scaling for logistic regression) is fit inside each cross-validation pipeline.

Separate experiments compare Logistic Regression, Random Forest, and HistGradientBoosting for both targets. Class counts and prevalence are reported per partition; class weighting is used. Hyperparameters are selected by cross-validated AUROC. A research-only classification threshold is selected on validation F1 and then evaluated on test data. The test set is never used for tuning or threshold selection. Test reports include AUROC, AUPRC, sensitivity, specificity, precision, F1, Brier score, calibration curves, and confusion matrices. Feature importance uses validation-set permutation importance; a SHAP summary is attempted for the selected model where supported.

```powershell
cd backend
python train_models.py
```

Model artifacts are written to `backend/artifacts/` (ignored by git). To use a different dataset or artifact directory, set `DATASET_PATH` or `MODEL_DIR` in `backend/.env`.

The expanded training run saves all six tuned model artifacts plus the validation-selected model for each target to `backend/artifacts/`. Machine-readable evaluations, Markdown summaries, ROC/precision-recall/calibration plots, confusion matrices, feature-importance CSVs/plots, and SHAP plots where available are written to `backend/reports/model_evaluation/`. Each report is explicitly labeled as a synthetic-data experiment. These metrics do not represent real clinical distributions or clinical evidence, and thresholds are not care recommendations.

## Run tests

```powershell
cd backend
python -m pytest -q
```

Tests cover API schemas and errors, synthetic patient/observation access, prediction feature leakage boundaries and missing artifacts, evidence provenance, assistant safety behavior, LangGraph routing/clarification/abstention/citation checks, workflow visualization, database schema/vector dimensions/import validation, and recovery notices. API unit tests override the database dependency and can run without PostgreSQL; migration/import validation requires the Compose database.

## API overview

| Method and path | Purpose |
|---|---|
| `GET /health` | Service status and synthetic record count |
| `GET /api/patients` | Paginated patient list; optional surgery category filter |
| `GET /api/patients/{patient_id}` | Synthetic patient profile |
| `GET /api/patients/{patient_id}/observations` | Time-filtered longitudinal observations |
| `GET /api/patients/{patient_id}/timeline` | Chronological observations |
| `POST /api/predictions/{patient_id}` | Synthetic-only model estimate at the supported 6-hour index |
| `POST /api/chat` | Conditional LangGraph assistant workflow; asks for missing patient context, cites retrieved evidence, and refuses treatment execution |
| `POST /api/evidence/ingest` | Add supplied text and source metadata to the local passage library |
| `POST /api/evidence/search` | Search local passage collection and return actual source-linked passages |
| `GET /api/evidence/sources/{source_id}` | Retrieve source metadata |
| `GET /api/recovery/summary` | Synthetic cohort recovery summary |
| `GET /api/recovery/patients/{patient_id}` | Patient recovery observations, without a safety determination |
| `GET /api/analytics/summary` | Synthetic cohort summary |
| `GET /api/research/model-evaluation` | Evaluation status (no evaluation report is bundled) |
| `GET /api/database/health` | PostgreSQL and pgvector connectivity |
| `POST /api/evidence/documents` | Store document metadata and passages, with optional supplied embeddings |
| `POST /api/evidence/vector-search` | Cosine similarity search over embedded chunks for the specified embedding model |
| `GET /api/chat/{conversation_id}/history` | Retrieve persisted synthetic-only assistant conversation turns |
| `GET /api/research/documents` | List ingested research documents with source and rights metadata |
| `GET /api/research/documents/{document_id}` | Inspect document metadata and chunk provenance |
| `GET /api/research/documents/chunks/{stable_chunk_id}` | View extracted text and trace it to source, section, and PDF page range |
| `POST /api/admin/research-documents/ingest` | Run manifest-approved PDF ingestion; requires `X-Admin-Token` |

## Research PDF ingestion

Put authorized source PDFs in `../data/papers/`. The curated local allowlist is `research_corpus/manifest.json`; only entries with `approved_for_local_ingestion: true` are read. Set `RESEARCH_SOURCE_DIR`, `DOCUMENT_STORAGE_DIR`, `RESEARCH_MANIFEST_PATH`, `CHUNK_TARGET_TOKENS` (default 550), and `CHUNK_OVERLAP_TOKENS` (default 75) in `.env` to change locations or sizing. Original files are copied into `document_storage/research/` with stable names. Source files are never mixed with the generated patient CSV.

Apply the schema and run the idempotent batch from `backend/`:

```powershell
python -m alembic upgrade head
python -m scripts.ingest_research_documents
# or select an entry from research_corpus/manifest.json
python -m scripts.ingest_research_documents --document-id nice-critical-illness-rehab
```

The HTTP admin endpoint accepts `{"document_ids": ["..."]}` or `{}` and requires an `INGESTION_ADMIN_TOKEN` secret configured in the environment. The CLI is intended for trusted local operators and does not need that HTTP token. PyMuPDF extracts text and PDF metadata. Empty/scanned or encrypted files are explicitly marked `needs_ocr` or `failed`; this batch does not run OCR, create embeddings, or call an LLM. Chunk token counts are approximate word/punctuation counts, not model-token counts. Chunking aims at the configured target and overlap while retaining paragraphs, headings, and page ranges. Document and chunk IDs and SHA-256 hashes are deterministic; reruns with unchanged source hashes are skipped. Changed documents replace their prior chunks in a single transaction.

The manifest does not claim that every supplied PDF is openly licensed. It records known rights notices and flags unknown terms; confirm permissions before redistributing PDFs or extracted text. The documents are research sources, not synthetic patient histories, and neither source findings nor this pipeline support clinical validation or care.

Inspect a chunk with `GET /api/research/documents/chunks/{stable_chunk_id}` after ingestion. `GET /api/research/documents` and `GET /api/research/documents/{document_id}` provide the catalog and full metadata. Migration `0002_research_ingestion` adds source checksums, extraction status, licenses, stable chunk IDs, section/page ranges, and content hashes.

The `/api/chat` endpoint runs the conditional graph documented in [`docs/agent_workflow.md`](docs/agent_workflow.md). Its Ollama adapter is behind separate chat and embedding provider interfaces. When `DATABASE_ENABLED=true` and research chunks are embedded, the graph embeds the query with Ollama and retrieves evidence by pgvector cosine similarity. If no vector chunks are indexed, it falls back to the local lexical evidence collection. Citations are mapped to retrieved passage records; unsupported evidence leads to explicit abstention. Ollama outages, missing model tags, timeouts, resource errors, and malformed responses are returned as safe assistant limitations. It has no medication-ordering or treatment-execution tools. PDF extraction and chunking remain a no-embedding batch; run `python -m scripts.embed_research_documents` as a separate local indexing step after ingestion.

## Configuration and error handling

Copy `.env.example` to `.env`. Settings include `DATASET_PATH`, `MODEL_DIR`, `EVIDENCE_STORE_PATH`, `DATABASE_URL`, `DATABASE_ENABLED`, `EMBEDDING_DIMENSION`, `OLLAMA_BASE_URL`, `OLLAMA_CHAT_MODEL`, `OLLAMA_EMBED_MODEL`, and `OLLAMA_TIMEOUT_SECONDS`. `DATABASE_ENABLED=false` keeps CSV-backed local mode. Database writes persist prediction results and conversation history only in the configured local PostgreSQL database. Chat request validation blocks common direct identifiers (such as SSNs, email addresses, phone-length digit strings, dates of birth, MRNs, and home addresses); it cannot reliably detect every possible identifier, so send synthetic data only. Local Ollama needs no API key; if a different future provider requires credentials, keep them in environment variables only. Logs contain request method/path/status and request ID, not request bodies, patient values, or secrets. Errors use a structured JSON `error` object and do not return stack traces.

The default operational target definitions and the 6-hour prediction index are documented in `../data/data_dictionary.md`. Prediction probabilities and generated-data cohort summaries describe only this artificial dataset and must not be interpreted as estimates for real patients.
