"""Traceable research PDF ingestion metadata and chunk provenance.

Revision ID: 0002_research_ingestion
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_research_ingestion"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("clinical_documents", sa.Column("source_sha256", sa.String(64), nullable=True))
    op.add_column("clinical_documents", sa.Column("license_name", sa.String(300), nullable=True))
    op.add_column("clinical_documents", sa.Column("license_url", sa.Text(), nullable=True))
    op.add_column("clinical_documents", sa.Column("ingestion_status", sa.String(30), nullable=False, server_default="pending"))
    op.add_column("clinical_documents", sa.Column("page_count", sa.Integer(), nullable=True))
    op.add_column("clinical_documents", sa.Column("ingestion_message", sa.Text(), nullable=True))
    op.create_index("uq_clinical_documents_source_sha256", "clinical_documents", ["source_sha256"], unique=True)
    op.create_check_constraint("ck_clinical_documents_ingestion_status", "clinical_documents",
                               "ingestion_status IN ('pending', 'ingested', 'needs_ocr', 'failed')")
    op.add_column("document_chunks", sa.Column("page_start", sa.Integer(), nullable=True))
    op.add_column("document_chunks", sa.Column("page_end", sa.Integer(), nullable=True))
    op.add_column("document_chunks", sa.Column("content_sha256", sa.String(64), nullable=True))
    op.add_column("document_chunks", sa.Column("token_count", sa.Integer(), nullable=True))
    op.add_column("document_chunks", sa.Column("stable_chunk_id", sa.String(64), nullable=True))
    op.create_unique_constraint("uq_document_chunks_stable_id", "document_chunks", ["stable_chunk_id"])
    op.create_check_constraint("ck_document_chunks_page_start_positive", "document_chunks", "page_start IS NULL OR page_start >= 1")
    op.create_check_constraint("ck_document_chunks_page_range_valid", "document_chunks", "page_end IS NULL OR (page_start IS NOT NULL AND page_end >= page_start)")
    op.create_index("ix_document_chunks_content_sha256", "document_chunks", ["content_sha256"])


def downgrade() -> None:
    op.drop_index("ix_document_chunks_content_sha256", table_name="document_chunks")
    op.drop_constraint("ck_document_chunks_page_range_valid", "document_chunks", type_="check")
    op.drop_constraint("ck_document_chunks_page_start_positive", "document_chunks", type_="check")
    op.drop_constraint("uq_document_chunks_stable_id", "document_chunks", type_="unique")
    for column in ("stable_chunk_id", "token_count", "content_sha256", "page_end", "page_start"):
        op.drop_column("document_chunks", column)
    op.drop_constraint("ck_clinical_documents_ingestion_status", "clinical_documents", type_="check")
    op.drop_index("uq_clinical_documents_source_sha256", table_name="clinical_documents")
    for column in ("ingestion_message", "page_count", "ingestion_status", "license_url", "license_name", "source_sha256"):
        op.drop_column("clinical_documents", column)
