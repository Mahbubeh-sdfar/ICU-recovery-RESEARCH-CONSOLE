"""Initial synthetic ICU schema with pgvector support.

Revision ID: 0001_initial
Revises:
"""
from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import Vector

from app.core.config import settings

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.create_table(
        "patients",
        sa.Column("patient_id", sa.String(20), primary_key=True), sa.Column("age_years", sa.Integer(), nullable=False),
        sa.Column("sex_category", sa.String(40), nullable=False), sa.Column("surgery_category", sa.String(40), nullable=False),
        sa.Column("surgery_type", sa.String(80), nullable=False), sa.Column("asa_class_simulated", sa.Integer()),
        sa.Column("bmi_kg_m2", sa.Float()), sa.Column("diabetes", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("cardiovascular_comorbidity", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("chronic_pain", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("pulmonary_comorbidity", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("baseline_severity_index", sa.Float()), sa.Column("data_split", sa.String(10), nullable=False),
        sa.Column("prediction_time_hours", sa.Integer(), nullable=False, server_default="6"),
        sa.Column("synthetic_data", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.CheckConstraint("patient_id LIKE 'SYN-%'", name="ck_patients_synthetic_patient_id"),
        sa.CheckConstraint("age_years BETWEEN 18 AND 100", name="ck_patients_age_range"),
        sa.CheckConstraint("sex_category IN ('female', 'male', 'another_or_not_recorded')", name="ck_patients_sex_category_allowed"),
        sa.CheckConstraint("surgery_category IN ('cardiac', 'abdominal', 'orthopedic', 'thoracic', 'vascular', 'other')", name="ck_patients_surgery_category_allowed"),
        sa.CheckConstraint("asa_class_simulated IS NULL OR asa_class_simulated BETWEEN 1 AND 5", name="ck_patients_asa_class_range"),
        sa.CheckConstraint("data_split IN ('train', 'test')", name="ck_patients_data_split_allowed"),
        sa.CheckConstraint("baseline_severity_index IS NULL OR baseline_severity_index BETWEEN 0 AND 1", name="ck_patients_severity_range"),
    )
    op.create_index("ix_patients_surgery_category", "patients", ["surgery_category"])
    op.create_table(
        "clinical_observations",
        sa.Column("observation_id", sa.String(40), primary_key=True), sa.Column("patient_id", sa.String(20), nullable=False),
        sa.Column("hours_postop", sa.Integer(), nullable=False), sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("heart_rate_bpm", sa.Integer()), sa.Column("systolic_bp_mmhg", sa.Integer()), sa.Column("diastolic_bp_mmhg", sa.Integer()),
        sa.Column("respiratory_rate_bpm", sa.Integer()), sa.Column("oxygen_saturation_pct", sa.Float()), sa.Column("temperature_celsius", sa.Float()),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.patient_id"], ondelete="CASCADE"),
        sa.UniqueConstraint("patient_id", "observation_id", name="uq_clinical_observations_patient_observation"),
        sa.CheckConstraint("hours_postop >= 0", name="ck_clinical_observations_hours_nonnegative"),
        sa.CheckConstraint("heart_rate_bpm IS NULL OR heart_rate_bpm BETWEEN 20 AND 300", name="ck_clinical_observations_heart_rate_range"),
        sa.CheckConstraint("systolic_bp_mmhg IS NULL OR systolic_bp_mmhg BETWEEN 30 AND 300", name="ck_clinical_observations_systolic_range"),
        sa.CheckConstraint("diastolic_bp_mmhg IS NULL OR diastolic_bp_mmhg BETWEEN 20 AND 200", name="ck_clinical_observations_diastolic_range"),
        sa.CheckConstraint("respiratory_rate_bpm IS NULL OR respiratory_rate_bpm BETWEEN 1 AND 100", name="ck_clinical_observations_respiratory_rate_range"),
        sa.CheckConstraint("oxygen_saturation_pct IS NULL OR oxygen_saturation_pct BETWEEN 0 AND 100", name="ck_clinical_observations_oxygen_saturation_range"),
    )
    op.create_index("ix_observations_patient_time", "clinical_observations", ["patient_id", "hours_postop"])
    op.create_index("ix_observations_observed_at", "clinical_observations", ["observed_at"])
    op.create_table(
        "pain_assessments",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("patient_id", sa.String(20), nullable=False),
        sa.Column("observation_id", sa.String(40), nullable=False), sa.Column("assessment_type", sa.String(8), nullable=False),
        sa.Column("nrs_score", sa.Integer()), sa.Column("cpot_score", sa.Integer()), sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["patient_id", "observation_id"], ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        sa.UniqueConstraint("observation_id", name="uq_pain_assessments_observation_id"),
        sa.CheckConstraint("nrs_score IS NULL OR nrs_score BETWEEN 0 AND 10", name="ck_pain_assessments_nrs_range"),
        sa.CheckConstraint("cpot_score IS NULL OR cpot_score BETWEEN 0 AND 8", name="ck_pain_assessments_cpot_range"),
        sa.CheckConstraint("nrs_score IS NULL OR cpot_score IS NULL", name="ck_pain_assessments_nrs_cpot_not_interchangeable"),
        sa.CheckConstraint("assessment_type IN ('NRS', 'CPOT')", name="ck_pain_assessments_assessment_type_allowed"),
    )
    op.create_index("ix_pain_assessments_patient_type", "pain_assessments", ["patient_id", "assessment_type"])
    op.create_table(
        "medication_records",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("patient_id", sa.String(20), nullable=False),
        sa.Column("observation_id", sa.String(40), nullable=False), sa.Column("medication_category", sa.String(20), nullable=False),
        sa.Column("medication_route", sa.String(20), nullable=False), sa.Column("exposure_index", sa.Integer(), nullable=False),
        sa.Column("opioid_exposure", sa.Boolean(), nullable=False), sa.Column("administered_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["patient_id", "observation_id"], ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        sa.CheckConstraint("medication_category IN ('none', 'nonopioid', 'opioid', 'multimodal')", name="ck_medication_records_medication_category_allowed"),
        sa.CheckConstraint("medication_route IN ('none', 'oral', 'intravenous', 'epidural', 'other')", name="ck_medication_records_medication_route_allowed"),
        sa.CheckConstraint("exposure_index BETWEEN 0 AND 3", name="ck_medication_records_exposure_index_range"),
    )
    op.create_index("ix_medication_records_patient_time", "medication_records", ["patient_id", "administered_at"])
    op.create_table(
        "mobility_recovery_assessments",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("patient_id", sa.String(20), nullable=False),
        sa.Column("observation_id", sa.String(40), nullable=False), sa.Column("hours_postop", sa.Integer(), nullable=False),
        sa.Column("mobility_status", sa.String(30), nullable=False), sa.Column("first_mobilization_hours", sa.Float()),
        sa.Column("mobilization_by_72h", sa.Boolean()), sa.Column("icu_length_of_stay_hours", sa.Float()),
        sa.Column("uncontrolled_pain_target", sa.Integer()), sa.Column("delayed_mobilization_target", sa.Integer()),
        sa.ForeignKeyConstraint(["patient_id", "observation_id"], ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        sa.UniqueConstraint("observation_id", name="uq_recovery_assessment_observation_id"),
        sa.CheckConstraint("mobility_status IN ('in_bed', 'bed_exercises', 'chair_or_standing', 'walking_assisted')", name="ck_mobility_recovery_assessments_mobility_status_allowed"),
        sa.CheckConstraint("first_mobilization_hours IS NULL OR first_mobilization_hours >= 0", name="ck_mobility_recovery_assessments_first_mobilization_nonnegative"),
        sa.CheckConstraint("icu_length_of_stay_hours IS NULL OR icu_length_of_stay_hours > 0", name="ck_mobility_recovery_assessments_icu_los_positive"),
        sa.CheckConstraint("uncontrolled_pain_target IS NULL OR uncontrolled_pain_target IN (0, 1)", name="ck_mobility_recovery_assessments_pain_target_binary"),
        sa.CheckConstraint("delayed_mobilization_target IS NULL OR delayed_mobilization_target IN (0, 1)", name="ck_mobility_recovery_assessments_mobility_target_binary"),
    )
    op.create_index("ix_recovery_patient_time", "mobility_recovery_assessments", ["patient_id", "hours_postop"])
    op.create_table(
        "ml_predictions",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("patient_id", sa.String(20), nullable=False),
        sa.Column("target", sa.String(40), nullable=False), sa.Column("probability", sa.Float(), nullable=False),
        sa.Column("model_name", sa.String(100), nullable=False), sa.Column("model_version", sa.String(100), nullable=False),
        sa.Column("prediction_time_hours", sa.Integer(), nullable=False), sa.Column("feature_snapshot", sa.JSON()),
        sa.Column("predicted_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.patient_id"], ondelete="CASCADE"),
        sa.CheckConstraint("target IN ('uncontrolled_pain', 'delayed_mobilization')", name="ck_ml_predictions_target_allowed"),
        sa.CheckConstraint("probability BETWEEN 0 AND 1", name="ck_ml_predictions_probability_range"),
        sa.CheckConstraint("prediction_time_hours >= 0", name="ck_ml_predictions_prediction_time_nonnegative"),
    )
    op.create_index("ix_ml_predictions_patient_target_time", "ml_predictions", ["patient_id", "target", "predicted_at"])
    op.create_table(
        "clinical_documents",
        sa.Column("document_id", sa.String(120), primary_key=True), sa.Column("title", sa.String(500), nullable=False),
        sa.Column("organization_or_authors", sa.String(500)), sa.Column("publication_year", sa.Integer()),
        sa.Column("source_type", sa.String(100)), sa.Column("publisher", sa.String(300)), sa.Column("doi", sa.String(300)),
        sa.Column("official_url", sa.Text()), sa.Column("local_filename", sa.String(500)), sa.Column("version", sa.String(200)),
        sa.Column("access_date", sa.String(40)), sa.Column("copyright_note", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.CheckConstraint("publication_year IS NULL OR publication_year BETWEEN 1900 AND 2100", name="ck_clinical_documents_publication_year_range"),
    )
    op.create_index("ix_clinical_documents_year", "clinical_documents", ["publication_year"])
    op.create_table(
        "document_chunks",
        sa.Column("chunk_id", sa.Integer(), primary_key=True), sa.Column("document_id", sa.String(120), nullable=False),
        sa.Column("chunk_index", sa.Integer(), nullable=False), sa.Column("text", sa.Text(), nullable=False),
        sa.Column("page_number", sa.Integer()), sa.Column("section_heading", sa.String(500)),
        sa.Column("embedding_model", sa.String(200)),
        sa.Column("embedding", Vector(settings.embedding_dimension)),
        sa.ForeignKeyConstraint(["document_id"], ["clinical_documents.document_id"], ondelete="CASCADE"),
        sa.UniqueConstraint("document_id", "chunk_index", name="uq_document_chunks_document_index"),
        sa.CheckConstraint("chunk_index >= 0", name="ck_document_chunks_chunk_index_nonnegative"),
        sa.CheckConstraint("page_number IS NULL OR page_number >= 1", name="ck_document_chunks_page_number_positive"),
        sa.CheckConstraint("embedding IS NULL OR embedding_model IS NOT NULL", name="ck_document_chunks_embedding_model_required"),
    )
    op.create_index("ix_document_chunks_document", "document_chunks", ["document_id"])
    op.create_index("ix_document_chunks_embedding_hnsw", "document_chunks", ["embedding"], postgresql_using="hnsw",
                    postgresql_ops={"embedding": "vector_cosine_ops"})
    op.create_table(
        "ai_conversation_history",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("conversation_id", sa.String(36), nullable=False),
        sa.Column("patient_id", sa.String(20)), sa.Column("role", sa.String(12), nullable=False), sa.Column("content", sa.Text(), nullable=False),
        sa.Column("citations", sa.JSON()), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.patient_id"], ondelete="SET NULL"),
        sa.CheckConstraint("role IN ('user', 'assistant', 'system')", name="ck_ai_conversation_history_role_allowed"),
    )
    op.create_index("ix_ai_history_conversation_time", "ai_conversation_history", ["conversation_id", "created_at"])
    op.create_index("ix_ai_history_patient_time", "ai_conversation_history", ["patient_id", "created_at"])


def downgrade() -> None:
    op.drop_table("ai_conversation_history")
    op.drop_index("ix_document_chunks_embedding_hnsw", table_name="document_chunks")
    op.drop_table("document_chunks")
    op.drop_index("ix_clinical_documents_year", table_name="clinical_documents")
    op.drop_table("clinical_documents")
    op.drop_index("ix_ml_predictions_patient_target_time", table_name="ml_predictions")
    op.drop_table("ml_predictions")
    op.drop_index("ix_recovery_patient_time", table_name="mobility_recovery_assessments")
    op.drop_table("mobility_recovery_assessments")
    op.drop_index("ix_medication_records_patient_time", table_name="medication_records")
    op.drop_table("medication_records")
    op.drop_index("ix_pain_assessments_patient_type", table_name="pain_assessments")
    op.drop_table("pain_assessments")
    op.drop_index("ix_observations_observed_at", table_name="clinical_observations")
    op.drop_index("ix_observations_patient_time", table_name="clinical_observations")
    op.drop_table("clinical_observations")
    op.drop_index("ix_patients_surgery_category", table_name="patients")
    op.drop_table("patients")
    # Keep the shared vector extension installed; other databases objects may use it.
