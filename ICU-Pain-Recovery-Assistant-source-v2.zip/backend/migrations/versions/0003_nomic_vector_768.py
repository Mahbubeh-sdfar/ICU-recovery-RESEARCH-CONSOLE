"""Align pgvector with nomic-embed-text's 768-dimensional output.

Revision ID: 0003_nomic_vector_768
Revises: 0002_research_ingestion
"""
from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import Vector

revision = "0003_nomic_vector_768"
down_revision = "0002_research_ingestion"
branch_labels = None
depends_on = None

INDEX_NAME = "ix_document_chunks_embedding_hnsw"


def _dimension(bind) -> str | None:
    return bind.execute(sa.text(
        "SELECT format_type(a.atttypid, a.atttypmod) "
        "FROM pg_attribute a "
        "WHERE a.attrelid = 'document_chunks'::regclass AND a.attname = 'embedding' AND NOT a.attisdropped"
    )).scalar_one_or_none()


def _non_null_embeddings(bind) -> int:
    return int(bind.execute(sa.text(
        "SELECT count(*) FROM document_chunks WHERE embedding IS NOT NULL"
    )).scalar_one())


def upgrade() -> None:
    bind = op.get_bind()
    current = _dimension(bind)
    if current == "vector(768)":
        return
    count = _non_null_embeddings(bind)
    if count:
        raise RuntimeError(
            f"Cannot change {current} embeddings to vector(768) automatically: {count} vectors exist. "
            "Export and re-embed those document chunks with the configured embedding model, then retry."
        )
    op.drop_index(INDEX_NAME, table_name="document_chunks")
    op.alter_column(
        "document_chunks", "embedding", type_=Vector(768),
        postgresql_using="NULL::vector(768)",
    )
    op.create_index(
        INDEX_NAME, "document_chunks", ["embedding"], postgresql_using="hnsw",
        postgresql_ops={"embedding": "vector_cosine_ops"},
    )


def downgrade() -> None:
    bind = op.get_bind()
    current = _dimension(bind)
    if current != "vector(768)":
        return
    count = _non_null_embeddings(bind)
    if count:
        raise RuntimeError(
            f"Cannot downgrade to vector(384): {count} 768-dimensional embeddings exist. "
            "Remove or re-embed them before downgrading."
        )
    op.drop_index(INDEX_NAME, table_name="document_chunks")
    op.alter_column(
        "document_chunks", "embedding", type_=Vector(384),
        postgresql_using="NULL::vector(384)",
    )
    op.create_index(
        INDEX_NAME, "document_chunks", ["embedding"], postgresql_using="hnsw",
        postgresql_ops={"embedding": "vector_cosine_ops"},
    )
