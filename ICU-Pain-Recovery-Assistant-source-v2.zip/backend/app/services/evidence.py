from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.core.errors import ServiceError

TOKEN_RE = re.compile(r"[a-z0-9]+", re.I)


class EvidenceService:
    def __init__(self, store_path: Path):
        self.store_path = store_path
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self.sources: dict[str, dict[str, Any]] = {}
        if store_path.exists():
            try:
                self.sources = json.loads(store_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                raise RuntimeError("Evidence store is invalid or unreadable") from exc

    def ingest(self, payload: dict[str, Any]) -> dict[str, Any]:
        source_id = payload["source_id"]
        if source_id in self.sources:
            raise ServiceError("source_exists", "A source with this ID already exists.", 409)
        text = payload.pop("text")
        words = text.split()
        chunks, start = [], 0
        # Chunk on word boundaries with modest overlap; location is exact character offset.
        while start < len(words):
            end = min(start + 180, len(words))
            chunk_text = " ".join(words[start:end])
            chunks.append({"passage_id": f"{source_id}-P{len(chunks)+1:04d}", "text": chunk_text,
                           "location": f"text offset approximately {start}–{end} words"})
            if end == len(words):
                break
            start = end - 30
        source = payload | {"passages": chunks}
        self.sources[source_id] = source
        self._save()
        return {"source_id": source_id, "title": source["title"], "passage_count": len(chunks),
                "notice": "Metadata and text are stored as supplied; source authority and currency were not independently verified."}

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        terms = set(TOKEN_RE.findall(query.lower()))
        matches = []
        for source_id, source in self.sources.items():
            for passage in source["passages"]:
                passage_terms = TOKEN_RE.findall(passage["text"].lower())
                if not passage_terms:
                    continue
                overlap = sum(1 for word in passage_terms if word in terms)
                score = overlap / (len(terms) or 1)
                if score > 0:
                    matches.append({"source_id": source_id, "title": source["title"], "organization": source.get("organization"),
                                    "year": source.get("year"), "source_type": source.get("source_type"), "url": source.get("url"),
                                    "passage_id": passage["passage_id"], "location": passage["location"],
                                    "text": passage["text"], "score": round(score, 4)})
        return sorted(matches, key=lambda x: (-x["score"], x["source_id"], x["passage_id"]))[:limit]

    def source(self, source_id: str) -> dict[str, Any]:
        source = self.sources.get(source_id)
        if not source:
            raise ServiceError("source_not_found", "Evidence source was not found.", 404)
        return {k: v for k, v in source.items() if k != "passages"} | {"passage_count": len(source["passages"])}

    def _save(self) -> None:
        tmp = self.store_path.with_suffix(self.store_path.suffix + ".tmp")
        tmp.write_text(json.dumps(self.sources, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.store_path)
