from __future__ import annotations

import json
import re
from typing import Any, TypedDict

from langgraph.graph import END, START, StateGraph

from app.core.errors import ServiceError
from app.providers.protocols import ChatModelProvider
from app.services.dataset import DatasetService
from app.services.evidence import EvidenceService
from app.services.predictions import PredictionService


class WorkflowState(TypedDict, total=False):
    question: str
    patient_id: str | None
    include_evidence: bool
    category: str
    patient_required: bool
    evidence_required: bool
    prediction_target: str | None
    unsafe_request: bool
    patient_profile: dict[str, Any] | None
    patient_observations: list[dict[str, Any]]
    missing_information: list[str]
    clarification: str | None
    prediction: dict[str, Any] | None
    prediction_error: str | None
    evidence: list[dict[str, Any]]
    evidence_sufficient: bool
    evidence_error: str | None
    reasoning: str | None
    provider_error: str | None
    safety_blocked: bool
    safety_reason: str | None
    citations: list[dict[str, Any]]
    answer: str
    limitations: list[str]


UNSAFE_REQUEST = re.compile(
    r"\b(prescribe|order|administer|give|recommend|calculate)\b.{0,70}\b"
    r"(dose|dosage|opioid|morphine|fentanyl|medication|treatment|therapy)\b|"
    r"\b(dose|dosage|opioid|morphine|fentanyl|medication|treatment|therapy)\b.{0,70}\b"
    r"(prescribe|order|administer|give|recommend|calculate)\b|"
    r"\b(?:is|are|should|can|may)\b.{0,35}\b(patient|they|he|she)\b.{0,50}\b"
    r"(?:safe|unsafe|ready|mobilize|walk|ambulate)\b|"
    r"\b(?:recommend|clear|approve|decide)\b.{0,50}\b(mobilize|walk|ambulate)\b|"
    r"\b(write|place|execute)\b.{0,30}\b(order|treatment plan)\b|"
    r"\b(?:what should we|how should we|what can we|what treatment|treatment plan|how to treat)\b"
    r".{0,70}\b(?:pain|mobiliz|patient|opioid|medication|analgesia|recovery)\b",
    re.I,
)
EVIDENCE_TERMS = re.compile(
    r"\b(evidence|guidelines?|literature|research|recommendation|standard|stud(?:y|ies)|source|"
    r"what does .* say|according to|clinical practice|what is known)\b", re.I,
)
PATIENT_TERMS = re.compile(
    r"\b(this patient|the patient|patient's|their pain|their mobility|my patient|"
    r"summari[sz]e (this |the )?patient|patient trend)\b", re.I,
)
PREDICTION_TERMS = re.compile(r"\b(predict|prediction|risk|probability|likelihood|model estimate)\b", re.I)
PAIN_TERMS = re.compile(r"\b(pain|nrs|cpot|analgesi[ac])\b", re.I)
MOBILITY_TERMS = re.compile(r"\b(mobiliz|mobility|walk|ambulat|rehabilitat|recovery)\b", re.I)
SEDATION_TERMS = re.compile(r"\b(rass|sedation|agitation)\b", re.I)
VITAL_TERMS = re.compile(r"\b(heart rate|blood pressure|respiratory rate|oxygen saturation|vital signs?)\b", re.I)
MEDICATION_TERMS = re.compile(r"\b(medication exposure|opioid exposure|medications? received|medication history)\b", re.I)
EVIDENCE_MARKER = re.compile(r"\[(E\d+)\]")
UNSAFE_OUTPUT = re.compile(
    r"\b(?:I recommend|administer|give the patient|order|prescribe|start .* at \d+|"
    r"safe to mobilize|unsafe to mobilize|cleared to mobilize)\b|"
    r"\b(?:should|recommend|prescribe|administer|order|increase|decrease|start|stop)\b"
    r".{0,45}\b(?:medication|opioid|dose|dosage|treatment|therapy|analgesia|analgesic)\b|"
    r"\b(?:consider|suggest|use|add|start|stop)\b.{0,45}\b"
    r"(?:medication|opioid|dose|dosage|treatment|therapy|analgesia|analgesic)\b|"
    r"\b(?:safe|unsafe|cleared|ready)\b.{0,30}\b(?:mobilize|walk|ambulate)\b", re.I,
)

PATIENT_FIELDS = (
    "observation_id", "observation_hours_postop", "nrs_pain_score", "cpot_pain_score",
    "pain_assessment_type", "rass_score", "heart_rate_bpm", "systolic_bp_mmhg",
    "diastolic_bp_mmhg", "respiratory_rate_bpm", "oxygen_saturation_pct",
    "mobility_status", "medication_category", "medication_route", "opioid_exposure",
    "medication_exposure_index",
)
FORBIDDEN_CONTEXT_FIELDS = {
    "uncontrolled_pain_target", "delayed_mobilization_target", "first_mobilization_hours",
    "icu_length_of_stay_hours", "mobilization_by_72h", "data_split",
}


class ICUChatWorkflow:
    """Conditional LangGraph for synthetic patient context and cited evidence answers."""

    def __init__(self, dataset: DatasetService, evidence: EvidenceService,
                 predictions: PredictionService, provider: ChatModelProvider):
        self.dataset = dataset
        self.evidence = evidence
        self.predictions = predictions
        self.provider = provider
        graph = StateGraph(WorkflowState)
        graph.add_node("query_classifier", self.query_classifier)
        graph.add_node("patient_context", self.patient_context)
        graph.add_node("data_validation", self.data_validation)
        graph.add_node("ml_prediction", self.ml_prediction)
        graph.add_node("evidence_retrieval", self.evidence_retrieval)
        graph.add_node("clinical_reasoning", self.clinical_reasoning)
        graph.add_node("safety_verification", self.safety_verification)
        graph.add_node("response_generation", self.response_generation)
        graph.add_edge(START, "query_classifier")
        graph.add_conditional_edges("query_classifier", self._after_classification, {
            "safety_verification": "safety_verification", "patient_context": "patient_context",
        })
        graph.add_edge("patient_context", "data_validation")
        graph.add_conditional_edges("data_validation", self._after_validation, {
            "response_generation": "response_generation", "ml_prediction": "ml_prediction",
        })
        graph.add_conditional_edges("ml_prediction", self._after_prediction, {
            "evidence_retrieval": "evidence_retrieval", "clinical_reasoning": "clinical_reasoning",
        })
        graph.add_edge("evidence_retrieval", "clinical_reasoning")
        graph.add_edge("clinical_reasoning", "safety_verification")
        graph.add_edge("safety_verification", "response_generation")
        graph.add_edge("response_generation", END)
        self.graph = graph.compile()

    def invoke(self, question: str, patient_id: str | None = None,
               include_evidence: bool = False) -> dict[str, Any]:
        state = self.graph.invoke({"question": question, "patient_id": patient_id,
                                   "include_evidence": include_evidence})
        return {"answer": state["answer"], "patient_id": state.get("patient_id"),
                "citations": state.get("citations", []),
                "limitations": state.get("limitations", []),
                "synthetic_data_notice": "All patient information is artificially generated.",
                "workflow_category": state.get("category", "general"),
                "clarification_needed": bool(state.get("clarification")),
                "missing_information": state.get("missing_information", [])}

    def _after_classification(self, state: WorkflowState) -> str:
        return "safety_verification" if state.get("unsafe_request") else "patient_context"

    def _after_validation(self, state: WorkflowState) -> str:
        return "response_generation" if state.get("clarification") else "ml_prediction"

    def _after_prediction(self, state: WorkflowState) -> str:
        return "evidence_retrieval" if state.get("evidence_required") else "clinical_reasoning"

    @staticmethod
    def query_classifier(state: WorkflowState) -> dict[str, Any]:
        question = state["question"]
        is_unsafe = bool(UNSAFE_REQUEST.search(question))
        prediction_target = None
        if PREDICTION_TERMS.search(question):
            prediction_target = "delayed_mobilization" if MOBILITY_TERMS.search(question) else "uncontrolled_pain"
        patient_required = bool(state.get("patient_id") or PATIENT_TERMS.search(question)
                                or prediction_target or re.search(r"\bSYN-[0-9]{5}\b", question, re.I))
        evidence_required = bool(state.get("include_evidence") or EVIDENCE_TERMS.search(question)
                                 or ((PAIN_TERMS.search(question) or MOBILITY_TERMS.search(question)
                                      or SEDATION_TERMS.search(question) or VITAL_TERMS.search(question))
                                     and not patient_required))
        if is_unsafe:
            category = "unsafe_action"
        elif prediction_target:
            category = "prediction"
        elif evidence_required:
            category = "clinical_evidence"
        elif patient_required and PAIN_TERMS.search(question):
            category = "pain_assessment"
        elif patient_required and SEDATION_TERMS.search(question):
            category = "sedation_assessment"
        elif patient_required and VITAL_TERMS.search(question):
            category = "vital_signs"
        elif patient_required and MOBILITY_TERMS.search(question):
            category = "mobility_recovery"
        elif patient_required and MEDICATION_TERMS.search(question):
            category = "medication_exposure"
        elif patient_required:
            category = "patient_summary"
        else:
            category = "general"
        return {"category": category, "patient_required": patient_required,
                "prediction_target": prediction_target, "evidence_required": evidence_required,
                "unsafe_request": is_unsafe, "evidence": [], "citations": [],
                "missing_information": [], "limitations": []}

    def patient_context(self, state: WorkflowState) -> dict[str, Any]:
        patient_id = state.get("patient_id")
        if not patient_id:
            match = re.search(r"\b(SYN-[0-9]{5})\b", state["question"], re.I)
            patient_id = match.group(1).upper() if match else None
        if not patient_id:
            return {"patient_id": None, "patient_profile": None, "patient_observations": []}
        try:
            profile = self.dataset.profile(patient_id)
            end_hour = profile.get("prediction_time_hours", 6) if state.get("prediction_target") else 168
            observations = self.dataset.observations(patient_id, end_hour=int(end_hour), limit=500)["items"]
        except ServiceError as exc:
            return {"patient_id": patient_id, "patient_profile": None, "patient_observations": [],
                    "missing_information": ["a valid synthetic patient profile"],
                    "clarification": f"I could not retrieve {patient_id}. Please verify the synthetic patient ID."}
        # Keep model targets and future recovery outcomes out of model-facing context.
        safe_observations = []
        for row in observations:
            safe_observations.append({key: row.get(key) for key in PATIENT_FIELDS if key in row
                                     and key not in FORBIDDEN_CONTEXT_FIELDS})
        return {"patient_id": patient_id, "patient_profile": profile,
                "patient_observations": safe_observations}

    @staticmethod
    def data_validation(state: WorkflowState) -> dict[str, Any]:
        if state.get("clarification"):
            return {}
        if state.get("patient_required") and not state.get("patient_id"):
            message = "Please provide the synthetic patient ID (for example, SYN-00001) so I can retrieve the correct context."
            return {"clarification": message, "missing_information": ["synthetic patient ID"]}
        if not state.get("patient_required"):
            return {}
        profile = state.get("patient_profile")
        if not profile:
            return {"clarification": "I could not retrieve the requested patient. Please verify the synthetic patient ID.",
                    "missing_information": ["retrievable synthetic patient profile"]}
        records = state.get("patient_observations", [])
        errors = []
        hours = [row.get("observation_hours_postop") for row in records]
        if hours != sorted(hours):
            errors.append("chronological observation order")
        for row in records:
            nrs, cpot = row.get("nrs_pain_score"), row.get("cpot_pain_score")
            if nrs is not None and not 0 <= nrs <= 10:
                errors.append("valid NRS value")
            if cpot is not None and not 0 <= cpot <= 8:
                errors.append("valid CPOT value")
            if nrs is not None and cpot is not None:
                errors.append("non-interchangeable NRS/CPOT assessment fields")
        question = state["question"]
        if state.get("patient_required") and PAIN_TERMS.search(question) and not any(
            row.get("nrs_pain_score") is not None or row.get("cpot_pain_score") is not None for row in records
        ):
            errors.append("a recorded pain assessment")
        if state.get("patient_required") and SEDATION_TERMS.search(question) and not any(row.get("rass_score") is not None for row in records):
            errors.append("a recorded RASS assessment")
        if state.get("patient_required") and VITAL_TERMS.search(question) and not any(
            any(row.get(field) is not None for field in ("heart_rate_bpm", "systolic_bp_mmhg", "respiratory_rate_bpm", "oxygen_saturation_pct"))
            for row in records
        ):
            errors.append("at least one recorded vital sign")
        if state.get("patient_required") and MOBILITY_TERMS.search(question) and not any(row.get("mobility_status") for row in records):
            errors.append("a recorded mobility status")
        if state.get("patient_required") and MEDICATION_TERMS.search(question) and not any(
            any(row.get(field) is not None for field in ("medication_category", "opioid_exposure", "medication_exposure_index"))
            for row in records
        ):
            errors.append("recorded medication exposure")
        if state.get("prediction_target") and not records:
            errors.append("observations available at or before the prediction time")
        if errors:
            unique_errors = list(dict.fromkeys(errors))
            return {"missing_information": unique_errors,
                    "clarification": "I need clarification or corrected data before I can summarize this patient: "
                                    + ", ".join(unique_errors) + "."}
        return {"missing_information": []}

    def ml_prediction(self, state: WorkflowState) -> dict[str, Any]:
        target = state.get("prediction_target")
        if not target or not state.get("patient_id"):
            return {"prediction": None}
        prediction_time = int((state.get("patient_profile") or {}).get("prediction_time_hours", 6))
        try:
            result = self.predictions.predict(state["patient_id"], target, prediction_time)
            return {"prediction": result, "prediction_error": None}
        except ServiceError as exc:
            return {"prediction": None, "prediction_error": exc.message}

    def evidence_retrieval(self, state: WorkflowState) -> dict[str, Any]:
        if not state.get("evidence_required"):
            return {"evidence": [], "evidence_sufficient": True}
        try:
            matches = self.evidence.search(state["question"], 4)
        except ServiceError as exc:
            return {"evidence": [], "evidence_sufficient": False,
                    "evidence_error": exc.code}
        evidence = []
        for index, item in enumerate(matches, start=1):
            evidence.append({"evidence_ref": f"E{index}", **item})
        return {"evidence": evidence, "evidence_sufficient": bool(evidence)}

    def clinical_reasoning(self, state: WorkflowState) -> dict[str, Any]:
        # No model is called for unsafe, undersupported evidence, or missing-data branches.
        if state.get("evidence_required") and not state.get("evidence_sufficient"):
            return {"reasoning": None}
        profile = state.get("patient_profile")
        context: dict[str, Any] = {
            "category": state.get("category"),
            "patient": profile,
            "observations": state.get("patient_observations", []),
            "prediction": state.get("prediction"),
            "prediction_unavailable_reason": state.get("prediction_error"),
            "retrieved_evidence": [{k: item.get(k) for k in (
                "evidence_ref", "title", "organization", "year", "location", "text", "url", "passage_id", "source_id"
            )} for item in state.get("evidence", [])],
        }
        system = (
            "You are a cautious research assistant in a synthetic-data ICU recovery prototype. "
            "Do not diagnose, prescribe, recommend or execute treatment, issue orders, or determine mobilization safety. "
            "Use only supplied patient fields and retrieved evidence. Never infer missing measurements or future outcomes. "
            "For every clinical/evidence claim, cite the supplied evidence reference exactly as [E1], [E2], etc. "
            "Do not invent source details. If evidence is insufficient, say so. Keep patient data, model estimates, "
            "and research evidence distinct. Be concise and explicitly state uncertainty."
        )
        user = (f"Question: {state['question']}\n\nSupplied context (synthetic patient data and retrieved sources only):\n"
                + json.dumps(context, ensure_ascii=False, default=str))
        try:
            draft = self.provider.generate(system_prompt=system, user_prompt=user)
        except ServiceError as exc:
            return {"reasoning": None, "provider_error": exc.code}
        except Exception:
            return {"reasoning": None, "provider_error": "model_provider_error"}
        return {"reasoning": draft}

    @staticmethod
    def safety_verification(state: WorkflowState) -> dict[str, Any]:
        if state.get("unsafe_request"):
            return {"safety_blocked": True, "safety_reason": "The request asks for an autonomous clinical action or decision."}
        if state.get("provider_error"):
            return {"safety_blocked": False, "safety_reason": None, "citations": []}
        draft = state.get("reasoning") or ""
        if UNSAFE_OUTPUT.search(draft):
            return {"safety_blocked": True, "safety_reason": "The draft contains prescribing, treatment-order, or mobilization-safety language."}
        refs = {item["evidence_ref"] for item in state.get("evidence", [])}
        found = set(EVIDENCE_MARKER.findall(draft))
        if any(ref not in refs for ref in found):
            return {"safety_blocked": True, "safety_reason": "The draft contains a citation reference that was not retrieved."}
        # For evidence questions, each non-empty substantive paragraph needs a retrieved citation.
        if state.get("evidence_required"):
            if not refs:
                return {"safety_blocked": True, "safety_reason": "The knowledge base did not return supporting evidence."}
            paragraphs = [p.strip() for p in draft.splitlines() if p.strip()]
            if not paragraphs or any(not EVIDENCE_MARKER.search(p) for p in paragraphs):
                return {"safety_blocked": True, "safety_reason": "One or more evidence-answer paragraphs are not linked to a retrieved citation."}
        citations = []
        used = set()
        for item in state.get("evidence", []):
            if item["evidence_ref"] in found:
                used.add(item["evidence_ref"])
                citations.append({"source_id": item["source_id"], "title": item["title"],
                                  "organization": item.get("organization"), "year": item.get("year"),
                                  "url": item.get("url"), "location": item.get("location"),
                                  "passage_id": item["passage_id"]})
        return {"safety_blocked": False, "safety_reason": None, "citations": citations}

    @staticmethod
    def response_generation(state: WorkflowState) -> dict[str, Any]:
        limitations = ["All patient data are synthetic and unsuitable for patient care."]
        if state.get("clarification"):
            return {"answer": state["clarification"], "citations": [], "limitations": limitations + state.get("missing_information", []),
                    "clarification_needed": True, "missing_information": state.get("missing_information", [])}
        if state.get("unsafe_request"):
            message = ("I can’t place orders, prescribe or recommend treatment, or decide whether a patient is safe to mobilize. "
                       "This assistant is limited to organizing synthetic data and summarizing retrieved research for clinician review."
                       )
            return {"answer": message,
                    "citations": [], "limitations": limitations + [state.get("safety_reason") or "Clinical actions are not supported."],
                    "clarification_needed": False, "missing_information": []}
        if state.get("evidence_required") and not state.get("evidence_sufficient"):
            reason = "Evidence retrieval failed; no clinical conclusion is provided." if state.get("evidence_error") else "Evidence was insufficient; no clinical conclusion is provided."
            return {"answer": "The available clinical knowledge base did not return enough relevant evidence to answer this question confidently. Please consult the source documents or appropriate clinical guidance.",
                    "citations": [], "limitations": limitations + [reason],
                    "clarification_needed": False, "missing_information": []}
        if state.get("safety_blocked"):
            if state.get("evidence_required") and state.get("evidence"):
                citations = [{"source_id": item["source_id"], "title": item["title"],
                              "organization": item.get("organization"), "year": item.get("year"),
                              "url": item.get("url"), "location": item.get("location"),
                              "passage_id": item["passage_id"]}
                             for item in state["evidence"]]
                answer = ("The generated draft was withheld because its citations could not be verified. "
                          "Retrieved source records are listed for review; no clinical conclusion is provided.")
            else:
                citations = []
                answer = "I can’t return this draft because it did not pass the safety and citation checks. Please rephrase the request or consult the cited source material."
            return {"answer": answer,
                    "citations": citations, "limitations": limitations + [state.get("safety_reason") or "Safety verification failed."],
                    "clarification_needed": False, "missing_information": []}
        if state.get("provider_error"):
            return {"answer": "The local language model is unavailable or returned an invalid response. No generated clinical summary is available; please retry after checking the local Ollama service and configured model.",
                    "citations": [], "limitations": limitations + [f"Model response unavailable ({state['provider_error']})."],
                    "clarification_needed": False, "missing_information": []}
        answer = state.get("reasoning") or "I could not generate a supported response from the supplied information."
        if state.get("prediction_error"):
            limitations.append(f"ML prediction unavailable: {state['prediction_error']}")
        if state.get("prediction"):
            limitations.extend(state["prediction"].get("limitations", []))
        return {"answer": answer, "citations": state.get("citations", []),
                "limitations": list(dict.fromkeys(limitations)), "clarification_needed": False,
                "missing_information": []}

    def mermaid(self) -> str:
        return self.graph.get_graph().draw_mermaid()
