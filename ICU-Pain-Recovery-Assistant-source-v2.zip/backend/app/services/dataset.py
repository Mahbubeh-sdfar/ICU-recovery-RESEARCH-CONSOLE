from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path
from typing import Any

from app.core.errors import ServiceError

NUMERIC_FIELDS = {
    "age_years", "asa_class_simulated", "bmi_kg_m2", "diabetes", "cardiovascular_comorbidity",
    "chronic_pain", "pulmonary_comorbidity", "baseline_severity_index", "nrs_pain_score",
    "cpot_pain_score", "rass_score", "heart_rate_bpm", "systolic_bp_mmhg", "diastolic_bp_mmhg",
    "respiratory_rate_bpm", "oxygen_saturation_pct", "medication_exposure_index", "opioid_exposure",
    "observation_hours_postop", "prediction_time_hours", "first_mobilization_hours", "mobilization_by_72h",
    "icu_length_of_stay_hours", "uncontrolled_pain_target", "delayed_mobilization_target",
}


def parse_row(raw: dict[str, str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in raw.items():
        if value == "":
            result[key] = None
        elif key in NUMERIC_FIELDS:
            number = float(value)
            result[key] = int(number) if number.is_integer() else number
        else:
            result[key] = value
    return result


class DatasetService:
    def __init__(self, dataset_path: Path):
        self.dataset_path = dataset_path
        self._patients: dict[str, dict[str, Any]] = {}
        self._observations: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self.load()

    def load(self) -> None:
        if not self.dataset_path.is_file():
            raise RuntimeError(f"Synthetic dataset not found: {self.dataset_path}")
        patients: dict[str, dict[str, Any]] = {}
        observations: dict[str, list[dict[str, Any]]] = defaultdict(list)
        with self.dataset_path.open(newline="", encoding="utf-8") as handle:
            for raw in csv.DictReader(handle):
                row = parse_row(raw)
                patient_id = row.get("patient_id", "")
                if not patient_id.startswith("SYN-"):
                    raise RuntimeError("Dataset contains a non-synthetic patient identifier")
                patients.setdefault(patient_id, row)
                observations[patient_id].append(row)
        for records in observations.values():
            records.sort(key=lambda item: item["observation_hours_postop"])
        self._patients, self._observations = patients, observations

    @property
    def patient_count(self) -> int:
        return len(self._patients)

    @property
    def observation_count(self) -> int:
        return sum(map(len, self._observations.values()))

    def list_patients(self, limit: int = 50, offset: int = 0, surgery_category: str | None = None) -> dict[str, Any]:
        items = [self.profile(pid) for pid in sorted(self._patients)
                 if surgery_category is None or self._patients[pid].get("surgery_category") == surgery_category]
        return {"items": items[offset:offset + limit], "total": len(items), "limit": limit, "offset": offset,
                "synthetic_data": True}

    def profile(self, patient_id: str) -> dict[str, Any]:
        row = self._patients.get(patient_id)
        if row is None:
            raise ServiceError("patient_not_found", "Synthetic patient was not found.", 404)
        keys = ["patient_id", "age_years", "sex_category", "surgery_category", "surgery_type", "asa_class_simulated",
                "bmi_kg_m2", "diabetes", "cardiovascular_comorbidity", "chronic_pain", "pulmonary_comorbidity",
                "baseline_severity_index", "data_split", "prediction_time_hours"]
        return {key: row.get(key) for key in keys} | {"synthetic_data": True}

    def observations(self, patient_id: str, start_hour: int = 0, end_hour: int = 168, limit: int = 500) -> dict[str, Any]:
        self.profile(patient_id)
        matches = [r for r in self._observations[patient_id]
                   if start_hour <= r["observation_hours_postop"] <= end_hour]
        return {"patient_id": patient_id, "items": matches[:limit], "total": len(matches), "synthetic_data": True}

    def all_patient_records(self) -> dict[str, list[dict[str, Any]]]:
        return self._observations

    def prediction_features(self, patient_id: str, prediction_time_hours: int = 6) -> dict[str, Any]:
        records = self._observations.get(patient_id)
        if records is None:
            raise ServiceError("patient_not_found", "Synthetic patient was not found.", 404)
        baseline_keys = ["age_years", "sex_category", "surgery_category", "surgery_type", "asa_class_simulated", "bmi_kg_m2",
                         "diabetes", "cardiovascular_comorbidity", "chronic_pain", "pulmonary_comorbidity", "baseline_severity_index"]
        features = {key: records[0].get(key) for key in baseline_keys}
        eligible = [r for r in records if r["observation_hours_postop"] <= prediction_time_hours]
        numeric = ["nrs_pain_score", "cpot_pain_score", "rass_score", "heart_rate_bpm", "systolic_bp_mmhg",
                   "diastolic_bp_mmhg", "respiratory_rate_bpm", "oxygen_saturation_pct", "medication_exposure_index", "opioid_exposure"]
        for field in numeric:
            values = [r[field] for r in eligible if r.get(field) is not None]
            features[f"pre_index_mean_{field}"] = sum(values) / len(values) if values else float("nan")
        # Categories reflect exposure observed by index, not future treatment.
        for field in ("pain_assessment_type", "medication_category", "medication_route", "mobility_status"):
            values = [r[field] for r in eligible if r.get(field) is not None]
            features[f"pre_index_last_{field}"] = values[-1] if values else "unavailable"
        features["pre_index_observation_count"] = len(eligible)
        return features

    def recovery(self, patient_id: str) -> dict[str, Any]:
        records = self._observations.get(patient_id)
        if records is None:
            raise ServiceError("patient_not_found", "Synthetic patient was not found.", 404)
        first = records[0]
        mobility = [{"hours_postop": r["observation_hours_postop"], "status": r["mobility_status"]} for r in records]
        return {"patient_id": patient_id, "first_mobilization_hours": first["first_mobilization_hours"],
                "mobilization_by_72h": first["mobilization_by_72h"], "icu_length_of_stay_hours": first["icu_length_of_stay_hours"],
                "delayed_mobilization_target": first["delayed_mobilization_target"], "mobility_timeline": mobility,
                "synthetic_data": True,
                "notice": "Descriptive simulated recovery data; not a mobilization safety assessment."}

    def summary(self) -> dict[str, Any]:
        first_rows = [records[0] for records in self._observations.values()]
        category_counts: dict[str, int] = defaultdict(int)
        for row in first_rows:
            category_counts[row["surgery_category"]] += 1
        pain_labeled = [r for r in first_rows if r["uncontrolled_pain_target"] is not None]
        return {"synthetic_data": True, "patient_count": self.patient_count, "observation_count": self.observation_count,
                "surgery_category_counts": dict(category_counts),
                "uncontrolled_pain_labeled_count": len(pain_labeled),
                "uncontrolled_pain_positive_count": sum(r["uncontrolled_pain_target"] == 1 for r in pain_labeled),
                "delayed_mobilization_positive_count": sum(r["delayed_mobilization_target"] == 1 for r in first_rows),
                "median_first_mobilization_hours": sorted(r["first_mobilization_hours"] for r in first_rows if r["first_mobilization_hours"] is not None)[len(first_rows)//2],
                "notice": "Synthetic generator summaries are not real clinical distributions or validated estimates."}
