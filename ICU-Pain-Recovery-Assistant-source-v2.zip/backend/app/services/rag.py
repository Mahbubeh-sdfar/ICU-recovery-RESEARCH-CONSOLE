from __future__ import annotations

import logging
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import ServiceError
from app.db.models import ClinicalDocument, DocumentChunk
from app.db.session import SessionLocal
from app.providers.protocols import EmbeddingProvider
from app.services.evidence import EvidenceService

logger = logging.getLogger(__name__)


class RAGService:
    """Evidence retrieval with pgvector as the DB-enabled path and lexical fallback."""

    def __init__(self, lexical: EvidenceService, embedder: EmbeddingProvider,
                 session_factory: Callable[[], Session] | None = None,
                 database_enabled: bool | None = None):
        self.lexical = lexical
        self.embedder = embedder
        self.session_factory = session_factory or SessionLocal
        self.database_enabled = settings.database_enabled if database_enabled is None else database_enabled

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        if not self.database_enabled:
            return self.lexical.search(query, limit)

        try:
            vectors = self.embedder.embed([f"search_query: {query}"])
            if len(vectors) != 1 or len(vectors[0]) != settings.embedding_dimension:
                raise ServiceError("embedding_dimension_mismatch", "The query embedding does not match the pgvector schema dimension.", 503)
            distance = DocumentChunk.embedding.cosine_distance(vectors[0]).label("cosine_distance")
            statement = (select(DocumentChunk, ClinicalDocument, distance)
                         .join(ClinicalDocument, ClinicalDocument.document_id == DocumentChunk.document_id)
                         .where(DocumentChunk.embedding.is_not(None),
                                DocumentChunk.embedding_model == settings.ollama_embed_model)
                         .order_by(distance).limit(limit))
            with self.session_factory() as session:
                rows = session.execute(statement).all()
        except ServiceError:
            raise
        except SQLAlchemyError as exc:
            logger.exception("pgvector_retrieval_failed")
            raise ServiceError("vector_retrieval_unavailable", "Vector evidence retrieval is unavailable; confirm PostgreSQL, pgvector, and migrations.", 503) from exc
        except Exception as exc:
            logger.exception("rag_embedding_or_retrieval_failed")
            raise ServiceError("vector_retrieval_unavailable", "The local embedding or vector retrieval step failed.", 503) from exc

        if not rows:
            return self.lexical.search(query, limit)
        passages = []
        for chunk, document, distance_value in rows:
            page_start = chunk.page_start or chunk.page_number
            page_end = chunk.page_end or page_start
            location = f"page {page_start}" if page_start else "page unavailable"
            if page_end and page_start and page_end != page_start:
                location = f"pages {page_start}–{page_end}"
            if chunk.section_heading:
                location = f"{chunk.section_heading}, {location}"
            passages.append({
                "source_id": document.document_id,
                "title": document.title,
                "organization": document.organization_or_authors,
                "year": document.publication_year,
                "source_type": document.source_type,
                "url": document.official_url,
                "passage_id": chunk.stable_chunk_id or f"{document.document_id}-chunk-{chunk.chunk_index}",
                "location": location,
                "text": chunk.text,
                "score": round(1.0 - float(distance_value), 6),
            })
        return passages

    def source(self, source_id: str) -> dict[str, Any]:
        if not self.database_enabled:
            return self.lexical.source(source_id)
        try:
            with self.session_factory() as session:
                document = session.get(ClinicalDocument, source_id)
                if document:
                    return {
                        "source_id": document.document_id,
                        "title": document.title,
                        "organization": document.organization_or_authors,
                        "year": document.publication_year,
                        "source_type": document.source_type,
                        "url": document.official_url,
                        "copyright_note": document.copyright_note,
                        "passage_count": len(document.chunks),
                    }
        except SQLAlchemyError as exc:
            logger.exception("evidence_source_lookup_failed")
            raise ServiceError("database_unavailable", "Research source metadata is unavailable.", 503) from exc
        return self.lexical.source(source_id)
