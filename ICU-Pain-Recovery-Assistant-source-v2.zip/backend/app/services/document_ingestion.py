"""Deterministic PDF extraction and provenance-preserving chunking.

No OCR, embeddings, or LLM calls are made here. Token counts are estimates based
on word/punctuation units so the pipeline has no tokenizer model dependency.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pymupdf as fitz
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import ClinicalDocument, DocumentChunk

logger = logging.getLogger(__name__)
DOI_RE = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Z0-9]+", re.I)
YEAR_RE = re.compile(r"\b(19\d{2}|20\d{2})\b")
TOKEN_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def document_id_for(relative_path: str) -> str:
    return "doc-" + hashlib.sha256(relative_path.replace("\\", "/").encode()).hexdigest()[:32]


def chunk_id_for(document_id: str, index: int, content_hash: str) -> str:
    return "chk-" + hashlib.sha256(f"{document_id}:{index}:{content_hash}".encode()).hexdigest()[:40]


def estimate_tokens(text: str) -> int:
    return len(TOKEN_RE.findall(text))


@dataclass
class ExtractedPage:
    number: int
    paragraphs: list[tuple[str, str | None]]


def _heading_and_paragraphs(page: fitz.Page) -> list[tuple[str, str | None]]:
    """Extract block text, using relative font size and typography as heading clues."""
    data = page.get_text("dict")
    sizes = [span["size"] for block in data.get("blocks", []) for line in block.get("lines", [])
             for span in line.get("spans", []) if span.get("text", "").strip()]
    median = sorted(sizes)[len(sizes) // 2] if sizes else 0
    result: list[tuple[str, str | None]] = []
    for block in data.get("blocks", []):
        if "lines" not in block:
            continue
        lines = []
        block_sizes = []
        for line in block["lines"]:
            line_text = "".join(span.get("text", "") for span in line.get("spans", [])).strip()
            if line_text:
                lines.append(line_text)
                block_sizes.extend(span.get("size", 0) for span in line.get("spans", []) if span.get("text", "").strip())
        text = " ".join(lines).strip()
        if not text:
            continue
        is_heading = bool(block_sizes and median and sum(block_sizes) / len(block_sizes) >= median * 1.18)
        is_heading = is_heading or (len(text) <= 120 and text.isupper() and any(c.isalpha() for c in text))
        result.append((text, text[:500] if is_heading else None))
    return result


def extract_pdf(path: Path) -> tuple[dict[str, Any], list[ExtractedPage], str | None]:
    """Return metadata, page text, and an explicit extraction status."""
    try:
        doc = fitz.open(path)
    except Exception as exc:
        raise ValueError(f"PDF could not be opened: {type(exc).__name__}: {exc}") from exc
    if doc.is_encrypted:
        doc.close()
        raise ValueError("PDF is encrypted and cannot be extracted without a password")
    pages: list[ExtractedPage] = []
    visible_chars = 0
    nonempty = 0
    sparse_image_pages = 0
    for index, page in enumerate(doc, start=1):
        paragraphs = _heading_and_paragraphs(page)
        visible_chars += sum(len(value) for value, _ in paragraphs)
        nonempty += bool(paragraphs)
        page_chars = sum(len(value) for value, _ in paragraphs)
        if page_chars < 40 and page.get_images(full=True):
            sparse_image_pages += 1
        pages.append(ExtractedPage(index, paragraphs))
    metadata = dict(doc.metadata or {})
    front = "\n".join(text for page in pages[:3] for text, _ in page.paragraphs)
    doi_match = DOI_RE.search(front) or DOI_RE.search(metadata.get("keywords") or "")
    year_match = YEAR_RE.search(front[:12000])
    title = (metadata.get("title") or "").strip() or next((v for p in pages[:2] for v, h in p.paragraphs if len(v) > 15 and not h), "")
    result = {
        "title": title[:500] or None,
        "authors": (metadata.get("author") or "").strip() or None,
        "publication_year": int(year_match.group(1)) if year_match else None,
        "doi": doi_match.group(0).rstrip(".,;)") if doi_match else None,
        "page_count": len(pages),
        "pdf_metadata": {k: v for k, v in metadata.items() if v},
    }
    doc.close()
    scanned_majority = bool(pages) and sparse_image_pages / len(pages) >= 0.8
    if not nonempty or visible_chars < 80 or scanned_majority:
        return result, pages, "needs_ocr"
    return result, pages, None


def _text_units(pages: list[ExtractedPage]) -> list[tuple[str, str | None, int]]:
    units: list[tuple[str, str | None, int]] = []
    section: str | None = None
    for page in pages:
        for text, heading in page.paragraphs:
            if heading:
                section = heading
            else:
                units.append((text, section, page.number))
    return units


def make_chunks(pages: list[ExtractedPage], target: int | None = None, overlap: int | None = None) -> list[dict[str, Any]]:
    target = target or settings.chunk_target_tokens
    overlap = settings.chunk_overlap_tokens if overlap is None else overlap
    if target < 1 or overlap < 0 or overlap >= target:
        raise ValueError("target must be positive and overlap must be in [0, target)")
    units = _text_units(pages)
    chunks: list[dict[str, Any]] = []
    current: list[tuple[str, str | None, int]] = []

    def emit(items: list[tuple[str, str | None, int]]) -> None:
        if not items:
            return
        content = "\n\n".join(f"[{section}]\n{text}" if section else text for text, section, _ in items)
        content_hash = sha256_bytes(content.encode("utf-8"))
        chunks.append({"text": content, "section_heading": next((s for _, s, _ in items if s), None),
                       "page_start": min(p for _, _, p in items), "page_end": max(p for _, _, p in items),
                       "content_sha256": content_hash, "token_count": estimate_tokens(content)})

    for text, section, page in units:
        pieces = [text]
        if estimate_tokens(text) > target:
            words = text.split()
            pieces = []
            part: list[str] = []
            for word in words:
                if part and estimate_tokens(" ".join(part + [word])) > target:
                    pieces.append(" ".join(part))
                    part = []
                part.append(word)
            if part:
                pieces.append(" ".join(part))
        for piece in pieces:
            piece_unit = (piece, section, page)
            if current and estimate_tokens(" ".join(x[0] for x in current) + " " + piece) > target:
                emit(current)
                carry: list[tuple[str, str | None, int]] = []
                count = 0
                for item in reversed(current):
                    n = estimate_tokens(item[0])
                    if count + n > overlap:
                        break
                    carry.insert(0, item)
                    count += n
                current = carry
            current.append(piece_unit)
    emit(current)
    return chunks


def load_manifest(path: Path | None = None) -> dict[str, Any]:
    path = path or settings.research_manifest_path
    return json.loads(path.read_text(encoding="utf-8"))


def ingest_documents(session: Session, document_ids: list[str] | None = None) -> dict[str, Any]:
    manifest = load_manifest()
    entries = manifest.get("documents", [])
    if document_ids:
        entries = [entry for entry in entries if entry.get("document_id") in set(document_ids)]
        found = {entry["document_id"] for entry in entries}
        missing = sorted(set(document_ids) - found)
        if missing:
            raise ValueError(f"Unknown document IDs in manifest: {', '.join(missing)}")
    results = []
    for item in entries:
        if not item.get("approved_for_local_ingestion", False):
            continue
        rel = Path(item["file"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Manifest file paths must stay inside RESEARCH_SOURCE_DIR")
        source = settings.research_source_dir / rel
        if not source.is_file():
            results.append({"document_id": item["document_id"], "status": "failed", "reason": "source file not found"})
            continue
        raw = source.read_bytes()
        file_hash = sha256_bytes(raw)
        existing = session.get(ClinicalDocument, item["document_id"])
        if existing and existing.source_sha256 == file_hash and existing.ingestion_status == "ingested":
            results.append({"document_id": existing.document_id, "status": "skipped_unchanged", "chunk_count": len(existing.chunks)})
            continue
        try:
            extraction_error: str | None = None
            try:
                extracted, pages, issue = extract_pdf(source)
            except Exception as exc:
                extracted, pages, issue = {"page_count": None}, [], "failed"
                extraction_error = str(exc)
            if issue:
                status = issue
                chunks: list[dict[str, Any]] = []
            else:
                status = "ingested"
                chunks = make_chunks(pages)
            settings.document_storage_dir.mkdir(parents=True, exist_ok=True)
            stored_name = f"{item['document_id']}.pdf"
            destination = settings.document_storage_dir / stored_name
            with tempfile.NamedTemporaryFile(dir=settings.document_storage_dir, delete=False) as temp:
                temp.write(raw)
                temp_path = Path(temp.name)
            temp_path.replace(destination)
            if existing:
                session.delete(existing)
                session.flush()
            title = item.get("title") or extracted.get("title") or source.stem
            doc = ClinicalDocument(
                document_id=item["document_id"], title=title,
                organization_or_authors=item.get("authors") or extracted.get("authors"),
                publication_year=item.get("publication_year") or extracted.get("publication_year"),
                source_type=item.get("source_type", "research_pdf"), publisher=item.get("publisher"),
                doi=item.get("doi") or extracted.get("doi"), official_url=item.get("official_url"),
                local_filename=stored_name, version=item.get("version"), access_date=item.get("access_date"),
                copyright_note=item.get("copyright_note"), source_sha256=file_hash,
                license_name=item.get("license_name"), license_url=item.get("license_url"),
                ingestion_status=status, ingestion_message=extraction_error or issue,
                page_count=extracted.get("page_count"),
            chunks=[DocumentChunk(chunk_index=i, stable_chunk_id=chunk_id_for(item["document_id"], i, chunk["content_sha256"]),
                                  text=chunk["text"], section_heading=chunk["section_heading"],
                                      page_number=chunk["page_start"], page_start=chunk["page_start"],
                                      page_end=chunk["page_end"], content_sha256=chunk["content_sha256"],
                                      token_count=chunk["token_count"], embedding=None, embedding_model=None)
                        for i, chunk in enumerate(chunks)],
            )
            session.add(doc)
            session.commit()
            results.append({"document_id": doc.document_id, "status": status, "chunk_count": len(chunks),
                            "page_count": doc.page_count, "reason": extraction_error or issue})
        except Exception as exc:
            session.rollback()
            logger.exception("research_document_ingestion_failed document_id=%s", item["document_id"])
            results.append({"document_id": item["document_id"], "status": "failed", "reason": f"{type(exc).__name__}: {exc}"})
    return {"results": results, "processed": len(results), "synthetic_patient_data": False,
            "notice": "Research documents are source material, separate from synthetic patient histories. No OCR or embeddings were generated."}
