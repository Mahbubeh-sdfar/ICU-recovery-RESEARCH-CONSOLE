from app.core.config import settings
from app.services.chat import ChatService
from app.services.chat_workflow import ICUChatWorkflow
from app.services.dataset import DatasetService
from app.services.evidence import EvidenceService
from app.services.rag import RAGService
from app.services.predictions import PredictionService
from app.providers.ollama import OllamaProvider


class Services:
    def __init__(self) -> None:
        self.dataset = DatasetService(settings.dataset_path)
        self.evidence = EvidenceService(settings.evidence_store_path)
        self.ollama = OllamaProvider()
        self.rag = RAGService(self.evidence, self.ollama)
        self.predictions = PredictionService(self.dataset, settings.model_dir)
        self.chat = ChatService(self.dataset, self.evidence)
        self.chat_workflow = ICUChatWorkflow(self.dataset, self.rag, self.predictions, self.ollama)
