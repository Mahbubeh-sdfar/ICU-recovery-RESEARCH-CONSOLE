from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import pandas as pd

from app.core.errors import ServiceError
from app.services.dataset import DatasetService


TARGETS = {
    "uncontrolled_pain": "uncontrolled_pain",
    "delayed_mobilization": "delayed_mobilization",
}


class PredictionService:
    def __init__(self, dataset: DatasetService, model_dir: Path):
        self.dataset = dataset
        self.model_dir = model_dir

    def predict(self, patient_id: str, target: str, prediction_time_hours: int) -> dict[str, Any]:
        if prediction_time_hours != 6:
            raise ServiceError("unsupported_prediction_time", "This prototype only supports its documented 6-hour prediction index.", 422)
        self.dataset.profile(patient_id)
        artifact_path = self.model_dir / f"{target}.joblib"
        if target not in TARGETS:
            raise ServiceError("unsupported_target", "The requested research outcome is not supported.", 422)
        if not artifact_path.is_file():
            raise ServiceError("model_unavailable", "No trained research model is available. Train the baseline models before requesting predictions.", 503)
        try:
            artifact = joblib.load(artifact_path)
            features = pd.DataFrame([self.dataset.prediction_features(patient_id, prediction_time_hours)])
            probability = float(artifact["pipeline"].predict_proba(features)[0][1])
        except Exception as exc:
            raise ServiceError("model_inference_failed", "The research model could not produce a prediction.", 503) from exc
        return {"patient_id": patient_id, "target": target, "probability": probability,
                "model_name": artifact.get("model_name", "logistic_regression"),
                "model_version": artifact.get("model_version", "unknown"),
                "prediction_time_hours": prediction_time_hours,
                "prediction_timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "explanation": "This is a model association based on synthetic data; it is not causal or a clinical recommendation.",
                "limitations": ["Trained on artificial data only.", "Not clinically validated and unsuitable for patient care.",
                                "Not a treatment recommendation; clinician judgment remains essential."]}
