from __future__ import annotations

import re
from typing import Any

from app.services.dataset import DatasetService
from app.services.evidence import EvidenceService

UNSAFE_PATTERNS = [
    re.compile(r"\b(what|which|recommend|prescribe|give|administer)\b.{0,50}\b(dose|dosage|opioid|morphine|fentanyl|medication)\b", re.I),
    re.compile(r"\b(is|are|can|should)\b.{0,50}\b(patient|they|he|she)\b.{0,50}\b(safe|unsafe)\b.{0,30}\b(mobiliz|walk|ambulat)", re.I),
    re.compile(r"\b(can|should)\b.{0,25}\b(patient|they|he|she)\b.{0,30}\b(mobiliz|walk|ambulat)\b", re.I),
]
EVIDENCE_TERMS = re.compile(r"\b(guidelines?|evidence|literature|research|recommendation|standard|stud(?:y|ies)|source|clinical practice)\b", re.I)


class ChatService:
    def __init__(self, dataset: DatasetService, evidence: EvidenceService):
        self.dataset = dataset
        self.evidence = evidence

    def answer(self, question: str, patient_id: str | None, include_evidence: bool) -> dict[str, Any]:
        if any(pattern.search(question) for pattern in UNSAFE_PATTERNS):
            return {"answer": "I can’t prescribe or suggest medication doses, or decide whether a patient is safe to mobilize. Please use qualified clinical assessment and local protocols. This prototype only organizes artificial data and retrieved source text.",
                    "patient_id": patient_id, "citations": [],
                    "limitations": ["No treatment, dosing, or mobilization-safety decisions are provided."]}

        patient_record = None
        if patient_id:
            patient_record = self.dataset.profile(patient_id)
        elif re.search(r"\b(this patient|the patient|their pain|their mobility)\b", question, re.I):
            return {"answer": "Please include a synthetic patient ID (for example, SYN-00001) so I can retrieve the intended patient context.",
                    "patient_id": None, "citations": [], "limitations": ["No patient was selected."]}

        want_evidence = include_evidence or bool(EVIDENCE_TERMS.search(question))
        citations, excerpts = [], []
        if want_evidence:
            passages = self.evidence.search(question, 3)
            if passages:
                for item in passages:
                    excerpts.append(f"[{item['passage_id']}] {item['text']}")
                    citations.append({"source_id": item["source_id"], "title": item["title"],
                                      "organization": item.get("organization"), "year": item.get("year"),
                                      "url": item.get("url"), "location": item["location"], "passage_id": item["passage_id"]})
            else:
                excerpts.append("The local evidence collection has no matching passages, so it cannot support an evidence-based answer.")

        pieces = []
        if patient_record:
            obs = self.dataset.observations(patient_id, end_hour=24, limit=20)["items"]
            pain = [r for r in obs if r["nrs_pain_score"] is not None or r["cpot_pain_score"] is not None]
            mobility = [r for r in obs if r["mobility_status"] is not None]
            values = [f"{r['observation_hours_postop']}h: NRS {r['nrs_pain_score']}" if r["nrs_pain_score"] is not None
                      else f"{r['observation_hours_postop']}h: CPOT {r['cpot_pain_score']}" for r in pain]
            pieces.append(f"Synthetic patient {patient_id}: {patient_record['surgery_category']} surgery, age {patient_record['age_years']} years. "
                          f"Available pain assessments through 24h: {('; '.join(values) if values else 'none recorded')}. "
                          f"Mobility observations retrieved: {len(mobility)}. These are simulated observations.")
        if excerpts:
            pieces.append("Retrieved evidence passages:\n" + "\n".join(excerpts))
        if not pieces:
            if want_evidence and not citations:
                pieces.append("The local evidence collection did not provide a matching passage, so there is not enough evidence to answer this clinical question confidently.")
            else:
                pieces.append("I can summarize a selected synthetic patient or search the local evidence collection. No external source or patient context was used for this response.")
        limitations = ["All patient records are artificial and are not suitable for patient care."]
        if want_evidence and not citations:
            limitations.append("The local evidence collection did not provide a matching passage; no evidence-backed clinical answer is available.")
        return {"answer": "\n\n".join(pieces), "patient_id": patient_id, "citations": citations, "limitations": limitations}
