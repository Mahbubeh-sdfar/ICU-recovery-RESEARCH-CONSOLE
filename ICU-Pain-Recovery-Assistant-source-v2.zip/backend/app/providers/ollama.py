from __future__ import annotations

import logging
import math
from typing import Any

import httpx

from app.core.config import settings
from app.core.errors import ServiceError

logger = logging.getLogger(__name__)


class OllamaProvider:
    """Local Ollama adapter; application workflows depend on provider protocols."""

    def __init__(self, base_url: str | None = None, chat_model: str | None = None,
                 embed_model: str | None = None, timeout_seconds: float | None = None):
        self.base_url = (base_url or settings.ollama_base_url).rstrip("/")
        self.chat_model = chat_model or settings.ollama_chat_model
        self.embed_model = embed_model or settings.ollama_embed_model
        self.timeout_seconds = timeout_seconds or settings.ollama_timeout_seconds

    def _post(self, endpoint: str, payload: dict[str, Any], model: str) -> dict[str, Any]:
        try:
            response = httpx.post(f"{self.base_url}{endpoint}", json=payload,
                                  timeout=self.timeout_seconds)
        except httpx.ConnectError as exc:
            raise ServiceError("ollama_unavailable", "Ollama is not running at the configured local address.", 503) from exc
        except httpx.TimeoutException as exc:
            raise ServiceError("ollama_timeout", "Ollama did not respond before the configured timeout.", 504) from exc
        except httpx.RequestError as exc:
            raise ServiceError("ollama_unavailable", "The local Ollama service could not be reached.", 503) from exc

        error_text = ""
        if response.status_code == 400:
            try:
                error_text = str(response.json().get("error", "")).lower()
            except (ValueError, AttributeError):
                pass
        if response.status_code == 404 or ("model" in error_text and "not found" in error_text):
            raise ServiceError("ollama_model_missing", f"Configured Ollama model '{model}' is not downloaded.", 503)
        if response.status_code >= 500 or (response.status_code == 400 and any(
            term in error_text for term in ("memory", "resource", "load model", "insufficient")
        )):
            # Ollama commonly returns a server error when a model cannot be loaded locally.
            logger.warning("ollama_local_capacity_error status=%d model=%s", response.status_code, model)
            raise ServiceError("ollama_insufficient_resources", "Ollama could not load the model with available local resources.", 503)
        if response.is_error:
            raise ServiceError("ollama_request_failed", "Ollama rejected the model request.", 502)
        try:
            body = response.json()
        except ValueError as exc:
            raise ServiceError("ollama_invalid_response", "Ollama returned a malformed response.", 502) from exc
        if not isinstance(body, dict):
            raise ServiceError("ollama_invalid_response", "Ollama returned a response with an invalid shape.", 502)
        return body

    def generate(self, *, system_prompt: str, user_prompt: str) -> str:
        body = self._post("/api/chat", {
            "model": self.chat_model,
            "messages": [{"role": "system", "content": system_prompt},
                         {"role": "user", "content": user_prompt}],
            "stream": False,
            "options": {"num_ctx": settings.ollama_num_ctx, "temperature": 0.1},
        }, self.chat_model)
        message = body.get("message")
        content = message.get("content") if isinstance(message, dict) else None
        if not isinstance(content, str) or not content.strip():
            raise ServiceError("ollama_invalid_response", "Ollama returned an empty or malformed chat response.", 502)
        return content.strip()

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        body = self._post("/api/embed", {"model": self.embed_model, "input": texts}, self.embed_model)
        vectors = body.get("embeddings")
        if (not isinstance(vectors, list) or len(vectors) != len(texts)
                or any(not isinstance(v, list) or not v or any(not isinstance(n, (int, float)) for n in v) for v in vectors)):
            raise ServiceError("ollama_invalid_response", "Ollama returned malformed embeddings.", 502)
        dimensions = {len(vector) for vector in vectors}
        if len(dimensions) != 1:
            raise ServiceError("ollama_invalid_response", "Ollama returned embeddings with inconsistent dimensions.", 502)
        if dimensions != {settings.embedding_dimension}:
            actual = next(iter(dimensions))
            raise ServiceError(
                "embedding_dimension_mismatch",
                f"Ollama returned {actual}-dimensional embeddings; the database expects {settings.embedding_dimension}.",
                502,
            )
        if any(not math.isfinite(float(value)) for vector in vectors for value in vector):
            raise ServiceError("ollama_invalid_response", "Ollama returned non-finite embedding values.", 502)
        return vectors
