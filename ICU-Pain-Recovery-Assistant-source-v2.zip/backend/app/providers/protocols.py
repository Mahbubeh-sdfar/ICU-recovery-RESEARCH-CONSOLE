from __future__ import annotations

from typing import Protocol


class ChatModelProvider(Protocol):
    def generate(self, *, system_prompt: str, user_prompt: str) -> str: ...


class EmbeddingProvider(Protocol):
    def embed(self, texts: list[str]) -> list[list[float]]: ...
