from __future__ import annotations

import logging
import uuid
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.exc import SQLAlchemyError

from app.api import chat, documents, evidence, patients, predictions, recovery, research
from app.api import database as database_api
from app.core.errors import ServiceError
from app.core.logging_config import configure_logging
from app.services.container import Services

configure_logging()
logger = logging.getLogger("icu_backend")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.services = Services()
    logger.info("backend_started synthetic_patients=%d", app.state.services.dataset.patient_count)
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="ICU Pain & Recovery Assistant API",
        description=("Local research prototype using synthetic postoperative ICU data. "
                     "Not clinically validated and not for patient care."),
        version="0.1.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "X-Request-ID"],
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))[:100]
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        logger.info("http_request request_id=%s method=%s path=%s status=%s", request_id,
                    request.method, request.url.path, response.status_code)
        return response

    @app.exception_handler(ServiceError)
    async def service_error_handler(request: Request, exc: ServiceError):
        return JSONResponse(status_code=exc.status_code, content={"error": {"code": exc.code,
            "message": exc.message, "request_id": getattr(request.state, "request_id", None)}})

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request: Request, exc: RequestValidationError):
        details = [{"field": ".".join(str(part) for part in error["loc"]), "message": error["msg"]}
                   for error in exc.errors()]
        return JSONResponse(status_code=422, content={"error": {"code": "validation_error",
            "message": "Request validation failed.", "details": details,
            "request_id": getattr(request.state, "request_id", None)}})

    @app.exception_handler(StarletteHTTPException)
    async def http_error_handler(request: Request, exc: StarletteHTTPException):
        return JSONResponse(status_code=exc.status_code, content={"error": {"code": "http_error",
            "message": str(exc.detail), "request_id": getattr(request.state, "request_id", None)}})

    @app.exception_handler(SQLAlchemyError)
    async def database_error_handler(request: Request, exc: SQLAlchemyError):
        logger.error("database_error request_id=%s error_type=%s", getattr(request.state, "request_id", "unknown"), type(exc).__name__)
        return JSONResponse(status_code=503, content={"error": {"code": "database_unavailable",
            "message": "The database operation could not be completed.", "request_id": getattr(request.state, "request_id", None)}})

    @app.exception_handler(Exception)
    async def internal_error_handler(request: Request, exc: Exception):
        logger.error("unhandled_error request_id=%s error_type=%s", getattr(request.state, "request_id", "unknown"), type(exc).__name__)
        return JSONResponse(status_code=500, content={"error": {"code": "internal_error",
            "message": "An unexpected server error occurred.", "request_id": getattr(request.state, "request_id", None)}})

    @app.get("/health", tags=["health"])
    def health(request: Request):
        svc = getattr(request.app.state, "services", None)
        return {"status": "ok" if svc else "starting", "synthetic_data": True,
                "patient_count": svc.dataset.patient_count if svc else 0}

    app.include_router(patients.router)
    app.include_router(predictions.router)
    app.include_router(chat.router)
    app.include_router(evidence.router)
    app.include_router(evidence.source_router)
    app.include_router(database_api.router)
    app.include_router(database_api.evidence_router)
    app.include_router(database_api.history_router)
    app.include_router(recovery.router)
    app.include_router(research.router)
    app.include_router(documents.router)
    app.include_router(documents.admin_router)
    report_dir = Path(__file__).resolve().parents[1] / "reports" / "model_evaluation"
    if report_dir.is_dir():
        app.mount("/model-reports", StaticFiles(directory=report_dir), name="model-reports")
    return app


app = create_app()
