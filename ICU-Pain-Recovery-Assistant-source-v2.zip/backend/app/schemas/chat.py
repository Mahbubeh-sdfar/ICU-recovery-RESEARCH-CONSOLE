from pydantic import BaseModel, Field, field_validator

from app.core.privacy import contains_direct_identifier


class ChatRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    patient_id: str | None = Field(default=None, pattern=r"^SYN-[0-9]{5}$")
    include_evidence: bool = False
    conversation_id: str | None = Field(default=None, max_length=36, pattern=r"^[0-9a-fA-F-]{36}$")

    @field_validator("question")
    @classmethod
    def reject_common_identifiers(cls, question: str) -> str:
        if contains_direct_identifier(question):
            raise ValueError("Do not include real patient identifiers or personal information.")
        return question


class Citation(BaseModel):
    source_id: str
    title: str
    organization: str | None = None
    year: int | None = None
    url: str | None = None
    location: str | None = None
    passage_id: str


class ChatResponse(BaseModel):
    answer: str
    patient_id: str | None = None
    conversation_id: str | None = None
    citations: list[Citation] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    workflow_category: str = "general"
    clarification_needed: bool = False
    missing_information: list[str] = Field(default_factory=list)
    synthetic_data_notice: str = "All patient information is artificially generated."
