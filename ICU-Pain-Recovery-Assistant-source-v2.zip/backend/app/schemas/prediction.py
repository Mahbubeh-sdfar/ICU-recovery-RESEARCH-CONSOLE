from typing import Literal

from pydantic import BaseModel, Field


class PredictionRequest(BaseModel):
    target: Literal["uncontrolled_pain", "delayed_mobilization"]
    prediction_time_hours: int = Field(default=6, ge=0, le=24)


class PredictionResponse(BaseModel):
    patient_id: str
    target: str
    probability: float
    model_name: str
    model_version: str
    prediction_time_hours: int
    prediction_timestamp_utc: str
    explanation: str
    limitations: list[str]
