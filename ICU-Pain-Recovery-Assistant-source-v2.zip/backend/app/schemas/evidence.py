from pydantic import BaseModel, Field, HttpUrl
from pydantic import field_validator

from app.core.privacy import contains_direct_identifier


class EvidenceIngestRequest(BaseModel):
    source_id: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9._-]+$")
    title: str = Field(min_length=3, max_length=500)
    text: str = Field(min_length=50, max_length=500_000)
    organization: str | None = Field(default=None, max_length=300)
    year: int | None = Field(default=None, ge=1900, le=2100)
    source_type: str | None = Field(default=None, max_length=100)
    url: HttpUrl | None = None
    version: str | None = Field(default=None, max_length=200)
    copyright_note: str | None = Field(default=None, max_length=1000)

    @field_validator("text")
    @classmethod
    def synthetic_evidence_text_only(cls, text: str) -> str:
        if contains_direct_identifier(text):
            raise ValueError("Do not store real patient identifiers or personal information in the evidence collection.")
        return text


class EvidenceSearchRequest(BaseModel):
    query: str = Field(min_length=3, max_length=1000)
    limit: int = Field(default=5, ge=1, le=20)


class EvidencePassage(BaseModel):
    passage_id: str
    source_id: str
    title: str
    organization: str | None = None
    year: int | None = None
    source_type: str | None = None
    url: str | None = None
    location: str
    text: str
    score: float


class EvidenceSearchResponse(BaseModel):
    query: str
    passages: list[EvidencePassage]
    message: str | None = None
