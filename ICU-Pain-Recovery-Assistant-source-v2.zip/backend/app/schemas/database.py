from pydantic import BaseModel, Field, field_validator, model_validator

from app.core.config import settings
from app.core.privacy import contains_direct_identifier


class DocumentChunkInput(BaseModel):
    text: str = Field(min_length=1, max_length=100_000)
    page_number: int | None = Field(default=None, ge=1)
    section_heading: str | None = Field(default=None, max_length=500)
    embedding: list[float] | None = Field(default=None, min_length=settings.embedding_dimension,
                                          max_length=settings.embedding_dimension)
    embedding_model: str | None = Field(default=None, max_length=200)

    @field_validator("text")
    @classmethod
    def synthetic_document_text_only(cls, text: str) -> str:
        if contains_direct_identifier(text):
            raise ValueError("Do not store real patient identifiers or personal information in clinical documents.")
        return text

    @field_validator("embedding")
    @classmethod
    def finite_embedding(cls, value):
        if value is not None and any(not (-1e10 < item < 1e10) for item in value):
            raise ValueError("embedding values must be finite")
        if value is not None and sum(item * item for item in value) == 0:
            raise ValueError("embedding must not be the zero vector")
        return value

    @model_validator(mode="after")
    def model_required_for_embedding(self):
        if self.embedding is not None and not self.embedding_model:
            raise ValueError("embedding_model is required when an embedding is supplied")
        return self


class ClinicalDocumentIngest(BaseModel):
    document_id: str = Field(min_length=1, max_length=120, pattern=r"^[A-Za-z0-9._-]+$")
    title: str = Field(min_length=3, max_length=500)
    chunks: list[DocumentChunkInput] = Field(min_length=1, max_length=5000)
    organization_or_authors: str | None = Field(default=None, max_length=500)
    publication_year: int | None = Field(default=None, ge=1900, le=2100)
    source_type: str | None = Field(default=None, max_length=100)
    publisher: str | None = Field(default=None, max_length=300)
    doi: str | None = Field(default=None, max_length=300)
    official_url: str | None = Field(default=None, max_length=2000)
    local_filename: str | None = Field(default=None, max_length=500)
    version: str | None = Field(default=None, max_length=200)
    access_date: str | None = Field(default=None, max_length=40)
    copyright_note: str | None = Field(default=None, max_length=3000)


class VectorSearchRequest(BaseModel):
    embedding: list[float] = Field(min_length=settings.embedding_dimension, max_length=settings.embedding_dimension)
    embedding_model: str = Field(min_length=1, max_length=200)
    limit: int = Field(default=5, ge=1, le=50)

    @field_validator("embedding")
    @classmethod
    def finite_embedding(cls, value):
        if any(not (-1e10 < item < 1e10) for item in value):
            raise ValueError("embedding values must be finite")
        if sum(item * item for item in value) == 0:
            raise ValueError("embedding must not be the zero vector")
        return value
