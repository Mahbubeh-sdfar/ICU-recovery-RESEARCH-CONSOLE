from pydantic import BaseModel, Field


class DocumentIngestionRequest(BaseModel):
    document_ids: list[str] | None = Field(default=None, max_length=50)


class DocumentListResponse(BaseModel):
    documents: list[dict]
    count: int
