from typing import Any

from pydantic import BaseModel, ConfigDict


class PatientRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    patient_id: str
    age_years: int
    surgery_category: str
    surgery_type: str


class ObservationRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    observation_id: str
    patient_id: str
    observation_hours_postop: int

