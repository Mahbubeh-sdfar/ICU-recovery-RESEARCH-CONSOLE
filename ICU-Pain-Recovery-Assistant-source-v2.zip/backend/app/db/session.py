from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings
from app.core.errors import ServiceError


engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, class_=Session)


def get_db() -> Generator[Session, None, None]:
    if not settings.database_enabled:
        raise ServiceError("database_disabled", "Database integration is disabled; set DATABASE_ENABLED=true.", 503)
    session = SessionLocal()
    try:
        yield session
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_optional_db() -> Generator[Session | None, None, None]:
    if not settings.database_enabled:
        yield None
        return
    yield from get_db()
