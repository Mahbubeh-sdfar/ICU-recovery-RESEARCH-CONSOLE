from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.core.errors import ServiceError
from app.db.models import (ClinicalObservation, MedicationRecord, MobilityRecoveryAssessment, PainAssessment, Patient)
from app.db.validation import validate_synthetic_records
from app.services.dataset import DatasetService


def _as_datetime(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def import_synthetic_dataset(session: Session, dataset: DatasetService, replace_existing: bool = False,
                             patient_batch_size: int = 250) -> dict[str, int]:
    records = dataset.all_patient_records()
    counts = validate_synthetic_records(records)
    existing = session.scalar(select(func.count()).select_from(Patient)) or 0
    if existing and not replace_existing:
        raise ServiceError("database_not_empty", "Database already contains patients. Pass --replace to explicitly replace synthetic patient data.", 409)
    if existing:
        session.execute(delete(Patient))  # dependent rows use ON DELETE CASCADE
        session.flush()

    patient_ids = sorted(records)
    inserted_observations = 0
    for offset in range(0, len(patient_ids), patient_batch_size):
        batch_ids = patient_ids[offset:offset + patient_batch_size]
        patient_rows: list[dict[str, Any]] = []
        obs_rows: list[dict[str, Any]] = []
        pain_rows: list[dict[str, Any]] = []
        medication_rows: list[dict[str, Any]] = []
        recovery_rows: list[dict[str, Any]] = []
        for patient_id in batch_ids:
            rows = records[patient_id]
            first = rows[0]
            patient_rows.append({
                "patient_id": patient_id, "age_years": first["age_years"], "sex_category": first["sex_category"],
                "surgery_category": first["surgery_category"], "surgery_type": first["surgery_type"],
                "asa_class_simulated": first["asa_class_simulated"], "bmi_kg_m2": first["bmi_kg_m2"],
                "diabetes": bool(first["diabetes"]), "cardiovascular_comorbidity": bool(first["cardiovascular_comorbidity"]),
                "chronic_pain": bool(first["chronic_pain"]), "pulmonary_comorbidity": bool(first["pulmonary_comorbidity"]),
                "baseline_severity_index": first["baseline_severity_index"], "data_split": first["data_split"],
                "prediction_time_hours": first["prediction_time_hours"], "synthetic_data": True,
            })
            for row in rows:
                obs_id, hour, observed_at = row["observation_id"], row["observation_hours_postop"], _as_datetime(row["observation_datetime_utc"])
                obs_rows.append({"observation_id": obs_id, "patient_id": patient_id, "hours_postop": hour,
                    "observed_at": observed_at, "heart_rate_bpm": row["heart_rate_bpm"],
                    "systolic_bp_mmhg": row["systolic_bp_mmhg"], "diastolic_bp_mmhg": row["diastolic_bp_mmhg"],
                    "respiratory_rate_bpm": row["respiratory_rate_bpm"], "oxygen_saturation_pct": row["oxygen_saturation_pct"]})
                pain_rows.append({"patient_id": patient_id, "observation_id": obs_id, "assessment_type": row["pain_assessment_type"],
                    "nrs_score": row["nrs_pain_score"], "cpot_score": row["cpot_pain_score"], "observed_at": observed_at})
                medication_rows.append({"patient_id": patient_id, "observation_id": obs_id,
                    "medication_category": row["medication_category"], "medication_route": row["medication_route"],
                    "exposure_index": row["medication_exposure_index"], "opioid_exposure": bool(row["opioid_exposure"]),
                    "administered_at": observed_at})
                outcome_fields = hour == 0
                recovery_rows.append({"patient_id": patient_id, "observation_id": obs_id, "hours_postop": hour,
                    "mobility_status": row["mobility_status"],
                    "first_mobilization_hours": row["first_mobilization_hours"] if outcome_fields else None,
                    "mobilization_by_72h": bool(row["mobilization_by_72h"]) if outcome_fields else None,
                    "icu_length_of_stay_hours": row["icu_length_of_stay_hours"] if outcome_fields else None,
                    "uncontrolled_pain_target": row["uncontrolled_pain_target"] if outcome_fields else None,
                    "delayed_mobilization_target": row["delayed_mobilization_target"] if outcome_fields else None})
        session.execute(Patient.__table__.insert(), patient_rows)
        session.execute(ClinicalObservation.__table__.insert(), obs_rows)
        session.execute(PainAssessment.__table__.insert(), pain_rows)
        session.execute(MedicationRecord.__table__.insert(), medication_rows)
        session.execute(MobilityRecoveryAssessment.__table__.insert(), recovery_rows)
        session.flush()
        inserted_observations += len(obs_rows)

    session.commit()
    return counts | {"patients_imported": len(patient_ids), "observations_imported": inserted_observations}
