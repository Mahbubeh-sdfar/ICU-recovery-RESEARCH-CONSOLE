from __future__ import annotations

from datetime import datetime
from typing import Any

from pgvector.sqlalchemy import Vector
from sqlalchemy import (Boolean, CheckConstraint, DateTime, Float, ForeignKey, ForeignKeyConstraint,
                        Index, Integer, JSON, String, Text, UniqueConstraint, func, text)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.config import settings
from app.db.base import Base


class Patient(Base):
    __tablename__ = "patients"
    __table_args__ = (
        CheckConstraint("patient_id LIKE 'SYN-%'", name="synthetic_patient_id"),
        CheckConstraint("age_years BETWEEN 18 AND 100", name="age_range"),
        CheckConstraint("sex_category IN ('female', 'male', 'another_or_not_recorded')", name="sex_category_allowed"),
        CheckConstraint("surgery_category IN ('cardiac', 'abdominal', 'orthopedic', 'thoracic', 'vascular', 'other')", name="surgery_category_allowed"),
        CheckConstraint("asa_class_simulated IS NULL OR asa_class_simulated BETWEEN 1 AND 5", name="asa_class_range"),
        CheckConstraint("data_split IN ('train', 'test')", name="data_split_allowed"),
        CheckConstraint("baseline_severity_index IS NULL OR baseline_severity_index BETWEEN 0 AND 1", name="severity_range"),
    )
    patient_id: Mapped[str] = mapped_column(String(20), primary_key=True)
    age_years: Mapped[int] = mapped_column(Integer, nullable=False)
    sex_category: Mapped[str] = mapped_column(String(40), nullable=False)
    surgery_category: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    surgery_type: Mapped[str] = mapped_column(String(80), nullable=False)
    asa_class_simulated: Mapped[int | None] = mapped_column(Integer)
    bmi_kg_m2: Mapped[float | None] = mapped_column(Float)
    diabetes: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    cardiovascular_comorbidity: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    chronic_pain: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    pulmonary_comorbidity: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    baseline_severity_index: Mapped[float | None] = mapped_column(Float)
    data_split: Mapped[str] = mapped_column(String(10), nullable=False)
    prediction_time_hours: Mapped[int] = mapped_column(Integer, nullable=False, server_default="6")
    synthetic_data: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    observations: Mapped[list[ClinicalObservation]] = relationship(back_populates="patient", cascade="all, delete-orphan")
    predictions: Mapped[list[MLPrediction]] = relationship(back_populates="patient", cascade="all, delete-orphan")


class ClinicalObservation(Base):
    __tablename__ = "clinical_observations"
    __table_args__ = (
        UniqueConstraint("patient_id", "observation_id", name="uq_clinical_observations_patient_observation"),
        CheckConstraint("hours_postop >= 0", name="hours_nonnegative"),
        CheckConstraint("heart_rate_bpm IS NULL OR heart_rate_bpm BETWEEN 20 AND 300", name="heart_rate_range"),
        CheckConstraint("systolic_bp_mmhg IS NULL OR systolic_bp_mmhg BETWEEN 30 AND 300", name="systolic_range"),
        CheckConstraint("diastolic_bp_mmhg IS NULL OR diastolic_bp_mmhg BETWEEN 20 AND 200", name="diastolic_range"),
        CheckConstraint("respiratory_rate_bpm IS NULL OR respiratory_rate_bpm BETWEEN 1 AND 100", name="respiratory_rate_range"),
        CheckConstraint("oxygen_saturation_pct IS NULL OR oxygen_saturation_pct BETWEEN 0 AND 100", name="oxygen_saturation_range"),
        ForeignKeyConstraint(["patient_id"], ["patients.patient_id"], ondelete="CASCADE"),
        Index("ix_observations_patient_time", "patient_id", "hours_postop"),
        Index("ix_observations_observed_at", "observed_at"),
    )
    observation_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    patient_id: Mapped[str] = mapped_column(String(20), nullable=False)
    hours_postop: Mapped[int] = mapped_column(Integer, nullable=False)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    heart_rate_bpm: Mapped[int | None] = mapped_column(Integer)
    systolic_bp_mmhg: Mapped[int | None] = mapped_column(Integer)
    diastolic_bp_mmhg: Mapped[int | None] = mapped_column(Integer)
    respiratory_rate_bpm: Mapped[int | None] = mapped_column(Integer)
    oxygen_saturation_pct: Mapped[float | None] = mapped_column(Float)
    temperature_celsius: Mapped[float | None] = mapped_column(Float)
    patient: Mapped[Patient] = relationship(back_populates="observations")
    pain_assessment: Mapped[PainAssessment | None] = relationship(back_populates="observation", cascade="all, delete-orphan", uselist=False)
    medication_records: Mapped[list[MedicationRecord]] = relationship(back_populates="observation", cascade="all, delete-orphan")
    recovery_assessment: Mapped[MobilityRecoveryAssessment | None] = relationship(back_populates="observation", cascade="all, delete-orphan", uselist=False)


class PainAssessment(Base):
    __tablename__ = "pain_assessments"
    __table_args__ = (
        ForeignKeyConstraint(["patient_id", "observation_id"],
                             ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        CheckConstraint("nrs_score IS NULL OR nrs_score BETWEEN 0 AND 10", name="nrs_range"),
        CheckConstraint("cpot_score IS NULL OR cpot_score BETWEEN 0 AND 8", name="cpot_range"),
        CheckConstraint("nrs_score IS NULL OR cpot_score IS NULL", name="nrs_cpot_not_interchangeable"),
        CheckConstraint("assessment_type IN ('NRS', 'CPOT')", name="assessment_type_allowed"),
        UniqueConstraint("observation_id", name="uq_pain_assessments_observation_id"),
        Index("ix_pain_assessments_patient_type", "patient_id", "assessment_type"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[str] = mapped_column(String(20), nullable=False)
    observation_id: Mapped[str] = mapped_column(String(40), nullable=False)
    assessment_type: Mapped[str] = mapped_column(String(8), nullable=False)
    nrs_score: Mapped[int | None] = mapped_column(Integer)
    cpot_score: Mapped[int | None] = mapped_column(Integer)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    observation: Mapped[ClinicalObservation] = relationship(back_populates="pain_assessment")


class MedicationRecord(Base):
    __tablename__ = "medication_records"
    __table_args__ = (
        ForeignKeyConstraint(["patient_id", "observation_id"],
                             ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        CheckConstraint("medication_category IN ('none', 'nonopioid', 'opioid', 'multimodal')", name="medication_category_allowed"),
        CheckConstraint("medication_route IN ('none', 'oral', 'intravenous', 'epidural', 'other')", name="medication_route_allowed"),
        CheckConstraint("exposure_index BETWEEN 0 AND 3", name="exposure_index_range"),
        Index("ix_medication_records_patient_time", "patient_id", "administered_at"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[str] = mapped_column(String(20), nullable=False)
    observation_id: Mapped[str] = mapped_column(String(40), nullable=False)
    medication_category: Mapped[str] = mapped_column(String(20), nullable=False)
    medication_route: Mapped[str] = mapped_column(String(20), nullable=False)
    exposure_index: Mapped[int] = mapped_column(Integer, nullable=False)
    opioid_exposure: Mapped[bool] = mapped_column(Boolean, nullable=False)
    administered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    observation: Mapped[ClinicalObservation] = relationship(back_populates="medication_records")


class MobilityRecoveryAssessment(Base):
    __tablename__ = "mobility_recovery_assessments"
    __table_args__ = (
        ForeignKeyConstraint(["patient_id", "observation_id"],
                             ["clinical_observations.patient_id", "clinical_observations.observation_id"], ondelete="CASCADE"),
        CheckConstraint("mobility_status IN ('in_bed', 'bed_exercises', 'chair_or_standing', 'walking_assisted')", name="mobility_status_allowed"),
        CheckConstraint("first_mobilization_hours IS NULL OR first_mobilization_hours >= 0", name="first_mobilization_nonnegative"),
        CheckConstraint("icu_length_of_stay_hours IS NULL OR icu_length_of_stay_hours > 0", name="icu_los_positive"),
        CheckConstraint("uncontrolled_pain_target IS NULL OR uncontrolled_pain_target IN (0, 1)", name="pain_target_binary"),
        CheckConstraint("delayed_mobilization_target IS NULL OR delayed_mobilization_target IN (0, 1)", name="mobility_target_binary"),
        UniqueConstraint("observation_id", name="uq_recovery_assessment_observation_id"),
        Index("ix_recovery_patient_time", "patient_id", "hours_postop"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[str] = mapped_column(String(20), nullable=False)
    observation_id: Mapped[str] = mapped_column(String(40), nullable=False)
    hours_postop: Mapped[int] = mapped_column(Integer, nullable=False)
    mobility_status: Mapped[str] = mapped_column(String(30), nullable=False)
    first_mobilization_hours: Mapped[float | None] = mapped_column(Float)
    mobilization_by_72h: Mapped[bool | None] = mapped_column(Boolean)
    icu_length_of_stay_hours: Mapped[float | None] = mapped_column(Float)
    uncontrolled_pain_target: Mapped[int | None] = mapped_column(Integer)
    delayed_mobilization_target: Mapped[int | None] = mapped_column(Integer)
    observation: Mapped[ClinicalObservation] = relationship(back_populates="recovery_assessment")


class MLPrediction(Base):
    __tablename__ = "ml_predictions"
    __table_args__ = (
        CheckConstraint("target IN ('uncontrolled_pain', 'delayed_mobilization')", name="target_allowed"),
        CheckConstraint("probability BETWEEN 0 AND 1", name="probability_range"),
        CheckConstraint("prediction_time_hours >= 0", name="prediction_time_nonnegative"),
        Index("ix_ml_predictions_patient_target_time", "patient_id", "target", "predicted_at"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[str] = mapped_column(ForeignKey("patients.patient_id", ondelete="CASCADE"), nullable=False)
    target: Mapped[str] = mapped_column(String(40), nullable=False)
    probability: Mapped[float] = mapped_column(Float, nullable=False)
    model_name: Mapped[str] = mapped_column(String(100), nullable=False)
    model_version: Mapped[str] = mapped_column(String(100), nullable=False)
    prediction_time_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    feature_snapshot: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    predicted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    patient: Mapped[Patient] = relationship(back_populates="predictions")


class ClinicalDocument(Base):
    __tablename__ = "clinical_documents"
    __table_args__ = (
        CheckConstraint("publication_year IS NULL OR publication_year BETWEEN 1900 AND 2100", name="publication_year_range"),
        Index("ix_clinical_documents_year", "publication_year"),
    )
    document_id: Mapped[str] = mapped_column(String(120), primary_key=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    organization_or_authors: Mapped[str | None] = mapped_column(String(500))
    publication_year: Mapped[int | None] = mapped_column(Integer)
    source_type: Mapped[str | None] = mapped_column(String(100))
    publisher: Mapped[str | None] = mapped_column(String(300))
    doi: Mapped[str | None] = mapped_column(String(300))
    official_url: Mapped[str | None] = mapped_column(Text)
    local_filename: Mapped[str | None] = mapped_column(String(500))
    version: Mapped[str | None] = mapped_column(String(200))
    access_date: Mapped[str | None] = mapped_column(String(40))
    copyright_note: Mapped[str | None] = mapped_column(Text)
    source_sha256: Mapped[str | None] = mapped_column(String(64), unique=True)
    license_name: Mapped[str | None] = mapped_column(String(300))
    license_url: Mapped[str | None] = mapped_column(Text)
    ingestion_status: Mapped[str] = mapped_column(String(30), nullable=False, server_default="pending")
    ingestion_message: Mapped[str | None] = mapped_column(Text)
    page_count: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    chunks: Mapped[list[DocumentChunk]] = relationship(back_populates="document", cascade="all, delete-orphan")


class DocumentChunk(Base):
    __tablename__ = "document_chunks"
    __table_args__ = (
        UniqueConstraint("document_id", "chunk_index", name="uq_document_chunks_document_index"),
        UniqueConstraint("stable_chunk_id", name="uq_document_chunks_stable_id"),
        CheckConstraint("chunk_index >= 0", name="chunk_index_nonnegative"),
        CheckConstraint("page_number IS NULL OR page_number >= 1", name="page_number_positive"),
        CheckConstraint("page_start IS NULL OR page_start >= 1", name="page_start_positive"),
        CheckConstraint("page_end IS NULL OR page_end >= page_start", name="page_range_valid"),
        CheckConstraint("embedding IS NULL OR embedding_model IS NOT NULL", name="embedding_model_required"),
        Index("ix_document_chunks_document", "document_id"),
        Index("ix_document_chunks_embedding_hnsw", "embedding", postgresql_using="hnsw",
              postgresql_ops={"embedding": "vector_cosine_ops"}),
    )
    chunk_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stable_chunk_id: Mapped[str | None] = mapped_column(String(64))
    document_id: Mapped[str] = mapped_column(ForeignKey("clinical_documents.document_id", ondelete="CASCADE"), nullable=False)
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    page_number: Mapped[int | None] = mapped_column(Integer)
    section_heading: Mapped[str | None] = mapped_column(String(500))
    page_start: Mapped[int | None] = mapped_column(Integer)
    page_end: Mapped[int | None] = mapped_column(Integer)
    content_sha256: Mapped[str | None] = mapped_column(String(64))
    token_count: Mapped[int | None] = mapped_column(Integer)
    embedding_model: Mapped[str | None] = mapped_column(String(200))
    embedding: Mapped[list[float] | None] = mapped_column(Vector(settings.embedding_dimension))
    document: Mapped[ClinicalDocument] = relationship(back_populates="chunks")


class AIConversationHistory(Base):
    __tablename__ = "ai_conversation_history"
    __table_args__ = (
        CheckConstraint("role IN ('user', 'assistant', 'system')", name="role_allowed"),
        Index("ix_ai_history_conversation_time", "conversation_id", "created_at"),
        Index("ix_ai_history_patient_time", "patient_id", "created_at"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    conversation_id: Mapped[str] = mapped_column(String(36), nullable=False)
    patient_id: Mapped[str | None] = mapped_column(ForeignKey("patients.patient_id", ondelete="SET NULL"))
    role: Mapped[str] = mapped_column(String(12), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    citations: Mapped[list[dict[str, Any]] | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
