from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import ServiceError
from app.db.models import (ClinicalObservation, MedicationRecord, MobilityRecoveryAssessment, PainAssessment, Patient)


class DatabaseQueries:
    def __init__(self, session: Session):
        self.session = session

    def list_patients(self, limit: int, offset: int, surgery_category: str | None = None) -> dict[str, Any]:
        statement = select(Patient).order_by(Patient.patient_id)
        count = select(func.count()).select_from(Patient)
        if surgery_category:
            statement = statement.where(Patient.surgery_category == surgery_category)
            count = count.where(Patient.surgery_category == surgery_category)
        total = self.session.scalar(count) or 0
        patients = self.session.scalars(statement.offset(offset).limit(limit)).all()
        items = [self._patient_dict(patient) for patient in patients]
        return {"items": items, "total": total, "limit": limit, "offset": offset, "synthetic_data": True}

    def patient(self, patient_id: str) -> dict[str, Any]:
        patient = self.session.get(Patient, patient_id)
        if not patient:
            raise ServiceError("patient_not_found", "Synthetic patient was not found.", 404)
        return self._patient_dict(patient)

    @staticmethod
    def _patient_dict(patient: Patient) -> dict[str, Any]:
        return {"patient_id": patient.patient_id, "age_years": patient.age_years, "sex_category": patient.sex_category,
                "surgery_category": patient.surgery_category, "surgery_type": patient.surgery_type,
                "asa_class_simulated": patient.asa_class_simulated, "bmi_kg_m2": patient.bmi_kg_m2,
                "diabetes": patient.diabetes, "cardiovascular_comorbidity": patient.cardiovascular_comorbidity,
                "chronic_pain": patient.chronic_pain, "pulmonary_comorbidity": patient.pulmonary_comorbidity,
                "baseline_severity_index": patient.baseline_severity_index, "data_split": patient.data_split,
                "prediction_time_hours": patient.prediction_time_hours, "synthetic_data": True}

    def observations(self, patient_id: str, start_hour: int = 0, end_hour: int = 168, limit: int = 500) -> dict[str, Any]:
        self.patient(patient_id)
        observations = self.session.scalars(select(ClinicalObservation).where(
            ClinicalObservation.patient_id == patient_id,
            ClinicalObservation.hours_postop >= start_hour,
            ClinicalObservation.hours_postop <= end_hour,
        ).order_by(ClinicalObservation.hours_postop).limit(limit)).all()
        items = []
        for observation in observations:
            pain = self.session.scalar(select(PainAssessment).where(PainAssessment.observation_id == observation.observation_id))
            medications = self.session.scalars(select(MedicationRecord).where(
                MedicationRecord.observation_id == observation.observation_id)).all()
            recovery = self.session.scalar(select(MobilityRecoveryAssessment).where(
                MobilityRecoveryAssessment.observation_id == observation.observation_id))
            items.append({
                "patient_id": patient_id, "observation_id": observation.observation_id,
                "observation_hours_postop": observation.hours_postop,
                "observation_datetime_utc": observation.observed_at.isoformat(),
                "heart_rate_bpm": observation.heart_rate_bpm, "systolic_bp_mmhg": observation.systolic_bp_mmhg,
                "diastolic_bp_mmhg": observation.diastolic_bp_mmhg, "respiratory_rate_bpm": observation.respiratory_rate_bpm,
                "oxygen_saturation_pct": observation.oxygen_saturation_pct,
                "pain_assessment_type": pain.assessment_type if pain else None,
                "nrs_pain_score": pain.nrs_score if pain else None, "cpot_pain_score": pain.cpot_score if pain else None,
                "medication_records": [{"medication_category": m.medication_category, "medication_route": m.medication_route,
                                        "medication_exposure_index": m.exposure_index, "opioid_exposure": m.opioid_exposure}
                                       for m in medications],
                "mobility_status": recovery.mobility_status if recovery else None,
                "first_mobilization_hours": recovery.first_mobilization_hours if recovery else None,
                "mobilization_by_72h": recovery.mobilization_by_72h if recovery else None,
                "icu_length_of_stay_hours": recovery.icu_length_of_stay_hours if recovery else None,
                "uncontrolled_pain_target": recovery.uncontrolled_pain_target if recovery else None,
                "delayed_mobilization_target": recovery.delayed_mobilization_target if recovery else None,
            })
        return {"patient_id": patient_id, "items": items, "total": len(items), "synthetic_data": True}

    def recovery(self, patient_id: str) -> dict[str, Any]:
        self.patient(patient_id)
        records = self.session.scalars(select(MobilityRecoveryAssessment).where(
            MobilityRecoveryAssessment.patient_id == patient_id).order_by(MobilityRecoveryAssessment.hours_postop)).all()
        first = next((r for r in records if r.first_mobilization_hours is not None or r.icu_length_of_stay_hours is not None), None)
        return {"patient_id": patient_id,
                "first_mobilization_hours": first.first_mobilization_hours if first else None,
                "mobilization_by_72h": first.mobilization_by_72h if first else None,
                "icu_length_of_stay_hours": first.icu_length_of_stay_hours if first else None,
                "uncontrolled_pain_target": first.uncontrolled_pain_target if first else None,
                "delayed_mobilization_target": first.delayed_mobilization_target if first else None,
                "mobility_timeline": [{"hours_postop": r.hours_postop, "status": r.mobility_status} for r in records],
                "synthetic_data": True,
                "notice": "Descriptive simulated recovery data; not a mobilization safety assessment."}

    def summary(self) -> dict[str, Any]:
        patients = self.session.scalars(select(Patient)).all()
        recoveries = self.session.scalars(select(MobilityRecoveryAssessment).where(
            MobilityRecoveryAssessment.first_mobilization_hours.is_not(None)
            | MobilityRecoveryAssessment.icu_length_of_stay_hours.is_not(None))).all()
        categories: dict[str, int] = {}
        for patient in patients:
            categories[patient.surgery_category] = categories.get(patient.surgery_category, 0) + 1
        pain_labeled = [r for r in recoveries if r.uncontrolled_pain_target is not None]
        mobilization_times = sorted(r.first_mobilization_hours for r in recoveries if r.first_mobilization_hours is not None)
        median = mobilization_times[len(mobilization_times) // 2] if mobilization_times else None
        obs_count = self.session.scalar(select(func.count()).select_from(ClinicalObservation)) or 0
        return {"synthetic_data": True, "patient_count": len(patients), "observation_count": obs_count,
                "surgery_category_counts": categories, "uncontrolled_pain_labeled_count": len(pain_labeled),
                "uncontrolled_pain_positive_count": sum(r.uncontrolled_pain_target == 1 for r in pain_labeled),
                "delayed_mobilization_positive_count": sum(r.delayed_mobilization_target == 1 for r in recoveries),
                "median_first_mobilization_hours": median,
                "notice": "Synthetic generator summaries are not real clinical distributions or validated estimates."}
