from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from app.core.errors import ServiceError

SYNTHETIC_ID = re.compile(r"^SYN-[0-9]{5}$")
VALID_SURGERIES = {"cardiac", "abdominal", "orthopedic", "thoracic", "vascular", "other"}
VALID_MEDICATIONS = {"none", "nonopioid", "opioid", "multimodal"}
VALID_ROUTES = {"none", "oral", "intravenous", "epidural", "other"}
VALID_MOBILITY = {"in_bed", "bed_exercises", "chair_or_standing", "walking_assisted"}


def validate_synthetic_records(records: dict[str, list[dict[str, Any]]]) -> dict[str, int]:
    errors: list[str] = []
    observation_ids: set[str] = set()
    for patient_id, rows in records.items():
        if not SYNTHETIC_ID.fullmatch(patient_id):
            errors.append(f"Patient ID is not synthetic-format: {patient_id}")
        if not rows:
            errors.append(f"Patient has no observations: {patient_id}")
            continue
        splits = {row.get("data_split") for row in rows}
        if len(splits) != 1:
            errors.append(f"Patient crosses dataset splits: {patient_id}")
        hours = []
        pain_targets, delay_targets = set(), set()
        for row in rows:
            obs_id = row.get("observation_id")
            if not obs_id or obs_id in observation_ids:
                errors.append(f"Missing or duplicate observation ID for {patient_id}")
            observation_ids.add(obs_id)
            hour = row.get("observation_hours_postop")
            if not isinstance(hour, int) or hour < 0:
                errors.append(f"Invalid observation time for {patient_id}")
            else:
                hours.append(hour)
            if row.get("surgery_category") not in VALID_SURGERIES:
                errors.append(f"Invalid surgery category for {patient_id}")
            if row.get("medication_category") not in VALID_MEDICATIONS or row.get("medication_route") not in VALID_ROUTES:
                errors.append(f"Invalid medication category/route for {patient_id}")
            if row.get("mobility_status") not in VALID_MOBILITY:
                errors.append(f"Invalid mobility status for {patient_id}")
            nrs, cpot = row.get("nrs_pain_score"), row.get("cpot_pain_score")
            if nrs is not None and not 0 <= nrs <= 10:
                errors.append(f"NRS out of range for {patient_id}")
            if cpot is not None and not 0 <= cpot <= 8:
                errors.append(f"CPOT out of range for {patient_id}")
            if nrs is not None and cpot is not None:
                errors.append(f"NRS and CPOT cannot both be recorded for {patient_id}")
            pain_targets.add(row.get("uncontrolled_pain_target"))
            delay_targets.add(row.get("delayed_mobilization_target"))
        if hours != sorted(set(hours)):
            errors.append(f"Observation times are duplicated or unordered for {patient_id}")
        if len(pain_targets) != 1 or len(delay_targets) != 1:
            errors.append(f"Outcome target differs across patient rows: {patient_id}")
    if errors:
        raise ServiceError("dataset_validation_failed", "Synthetic dataset validation failed: " + "; ".join(errors[:8]), 422)
    return {"patient_count": len(records), "observation_count": len(observation_ids)}
