from fastapi import APIRouter, Depends

from app.api.dependencies import services
from app.schemas.evidence import EvidenceIngestRequest, EvidenceSearchRequest, EvidenceSearchResponse

router = APIRouter(prefix="/api/evidence", tags=["clinical evidence"])
source_router = APIRouter(prefix="/api", tags=["clinical evidence"])


@router.post("/ingest", status_code=201)
def ingest_evidence(body: EvidenceIngestRequest, svc=Depends(services)):
    return svc.evidence.ingest(body.model_dump(mode="json", exclude_none=True))


@router.post("/search", response_model=EvidenceSearchResponse)
def search_evidence(body: EvidenceSearchRequest, svc=Depends(services)):
    passages = svc.rag.search(body.query, body.limit)
    return {"query": body.query, "passages": passages,
            "message": None if passages else "No matching passage was found in the local evidence collection."}


@router.get("/sources/{source_id}")
def get_source(source_id: str, svc=Depends(services)):
    return svc.rag.source(source_id)


@source_router.get("/sources/{source_id}")
def get_source_compat(source_id: str, svc=Depends(services)):
    """Source metadata route matching the initial project API specification."""
    return svc.rag.source(source_id)
