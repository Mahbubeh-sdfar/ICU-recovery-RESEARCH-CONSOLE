from fastapi import APIRouter, Depends
from uuid import uuid4
from sqlalchemy.exc import SQLAlchemyError

from app.api.dependencies import services
from app.core.errors import ServiceError
from app.db.models import AIConversationHistory
from app.db.session import get_optional_db
from app.schemas.chat import ChatRequest, ChatResponse

router = APIRouter(prefix="/api", tags=["AI assistant"])


@router.post("/chat", response_model=ChatResponse)
def chat(body: ChatRequest, svc=Depends(services), session=Depends(get_optional_db)):
    answer = svc.chat_workflow.invoke(body.question, body.patient_id, body.include_evidence)
    conversation_id = body.conversation_id or str(uuid4())
    if session is not None:
        session.add_all([
            AIConversationHistory(conversation_id=conversation_id, patient_id=body.patient_id,
                                  role="user", content=body.question),
            AIConversationHistory(conversation_id=conversation_id, patient_id=body.patient_id,
                                  role="assistant", content=answer["answer"], citations=answer["citations"]),
        ])
        try:
            session.commit()
        except SQLAlchemyError as exc:
            session.rollback()
            raise ServiceError("conversation_persistence_failed", "Conversation history could not be saved.", 503) from exc
    return answer | {"conversation_id": conversation_id}
