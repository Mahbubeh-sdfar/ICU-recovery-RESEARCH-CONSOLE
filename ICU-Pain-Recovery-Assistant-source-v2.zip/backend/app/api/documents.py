from __future__ import annotations

import hmac

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import ClinicalDocument, DocumentChunk
from app.db.session import get_db
from app.schemas.documents import DocumentIngestionRequest
from app.services.document_ingestion import ingest_documents

router = APIRouter(prefix="/api/research/documents", tags=["research documents"])
admin_router = APIRouter(prefix="/api/admin/research-documents", tags=["research document administration"])


def require_ingestion_admin(x_admin_token: str | None = Header(default=None)) -> None:
    configured = settings.ingestion_admin_token
    if not configured:
        raise HTTPException(status_code=503, detail="Research ingestion is disabled: configure INGESTION_ADMIN_TOKEN.")
    if not x_admin_token or not hmac.compare_digest(configured, x_admin_token):
        raise HTTPException(status_code=401, detail="Valid X-Admin-Token is required.")


@router.get("")
def list_documents(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                   session: Session = Depends(get_db)):
    rows = session.scalars(select(ClinicalDocument).order_by(ClinicalDocument.title).offset(offset).limit(limit)).all()
    return {"count": len(rows), "documents": [{
        "document_id": d.document_id, "title": d.title, "organization_or_authors": d.organization_or_authors,
        "publication_year": d.publication_year, "doi": d.doi, "official_url": d.official_url,
        "source_type": d.source_type, "publisher": d.publisher, "license_name": d.license_name,
        "license_url": d.license_url, "copyright_note": d.copyright_note,
        "page_count": d.page_count, "ingestion_status": d.ingestion_status,
        "ingestion_message": d.ingestion_message,
        "chunk_count": len(d.chunks),
    } for d in rows]}


@router.get("/{document_id}")
def get_document(document_id: str, session: Session = Depends(get_db)):
    doc = session.get(ClinicalDocument, document_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Research document not found.")
    return {"document_id": doc.document_id, "title": doc.title, "organization_or_authors": doc.organization_or_authors,
            "publication_year": doc.publication_year, "doi": doc.doi, "official_url": doc.official_url,
            "source_type": doc.source_type, "publisher": doc.publisher, "local_filename": doc.local_filename,
            "version": doc.version, "access_date": doc.access_date, "copyright_note": doc.copyright_note,
            "license_name": doc.license_name, "license_url": doc.license_url,
            "source_sha256": doc.source_sha256, "page_count": doc.page_count,
            "ingestion_status": doc.ingestion_status, "ingestion_message": doc.ingestion_message,
            "chunks": [{"stable_chunk_id": c.stable_chunk_id, "chunk_index": c.chunk_index,
                        "section_heading": c.section_heading, "page_start": c.page_start,
                        "page_end": c.page_end, "content_sha256": c.content_sha256,
                        "token_count_estimate": c.token_count} for c in doc.chunks]}


@router.get("/chunks/{chunk_id}")
def get_chunk(chunk_id: str, session: Session = Depends(get_db)):
    chunk = session.scalar(select(DocumentChunk).where(DocumentChunk.stable_chunk_id == chunk_id))
    if not chunk:
        raise HTTPException(status_code=404, detail="Research document chunk not found.")
    doc = session.get(ClinicalDocument, chunk.document_id)
    return {"stable_chunk_id": chunk.stable_chunk_id, "chunk_index": chunk.chunk_index,
            "document_id": chunk.document_id, "document_title": doc.title if doc else None,
            "authors": doc.organization_or_authors if doc else None,
            "publication_year": doc.publication_year if doc else None,
            "doi": doc.doi if doc else None, "official_url": doc.official_url if doc else None,
            "source_filename": doc.local_filename if doc else None,
            "section_heading": chunk.section_heading, "page_start": chunk.page_start,
            "page_end": chunk.page_end, "content_sha256": chunk.content_sha256,
            "token_count_estimate": chunk.token_count, "text": chunk.text,
            "notice": "Research document text; separate from synthetic patient histories. Verify source permissions before redistribution."}


@admin_router.post("/ingest", dependencies=[Depends(require_ingestion_admin)])
def run_ingestion(body: DocumentIngestionRequest, session: Session = Depends(get_db)):
    try:
        return ingest_documents(session, body.document_ids)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
