from fastapi import APIRouter, Depends
import json
from pathlib import Path

from app.api.dependencies import services
from app.db.queries import DatabaseQueries
from app.db.session import get_optional_db

router = APIRouter(prefix="/api", tags=["research"])


@router.get("/analytics/summary")
def analytics_summary(svc=Depends(services), session=Depends(get_optional_db)):
    if session is not None:
        return DatabaseQueries(session).summary()
    return svc.dataset.summary()


@router.get("/research/model-evaluation")
def model_evaluation():
    report_path = Path(__file__).resolve().parents[2] / "reports" / "model_evaluation" / "evaluation_summary.json"
    if report_path.is_file():
        return json.loads(report_path.read_text(encoding="utf-8"))
    return {"status": "not_evaluated", "targets": {},
            "message": "No evaluation report is available. Run the documented synthetic-data training workflow.",
            "synthetic_data_experiment": True}
