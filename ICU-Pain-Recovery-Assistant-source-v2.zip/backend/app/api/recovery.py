from fastapi import APIRouter, Depends

from app.api.dependencies import services
from app.db.queries import DatabaseQueries
from app.db.session import get_optional_db

router = APIRouter(prefix="/api/recovery", tags=["recovery monitoring"])


@router.get("/summary")
def recovery_summary(svc=Depends(services), session=Depends(get_optional_db)):
    if session is not None:
        return DatabaseQueries(session).summary()
    return svc.dataset.summary()


@router.get("/patients/{patient_id}")
def patient_recovery(patient_id: str, svc=Depends(services), session=Depends(get_optional_db)):
    if session is not None:
        return DatabaseQueries(session).recovery(patient_id)
    return svc.dataset.recovery(patient_id)
