from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

from app.core.errors import ServiceError
from app.db.models import AIConversationHistory, ClinicalDocument, DocumentChunk
from app.db.session import get_db
from app.schemas.database import ClinicalDocumentIngest, VectorSearchRequest

router = APIRouter(prefix="/api/database", tags=["database"])
evidence_router = APIRouter(prefix="/api/evidence", tags=["clinical evidence"])
history_router = APIRouter(prefix="/api/chat", tags=["AI assistant"])


@router.get("/health")
def database_health(session: Session = Depends(get_db)):
    try:
        session.execute(text("SELECT 1"))
        extension = session.execute(text("SELECT extname FROM pg_extension WHERE extname = 'vector'")).scalar()
        return {"status": "ok" if extension else "extension_missing", "database": "postgresql",
                "pgvector": "enabled" if extension else "not_enabled"}
    except SQLAlchemyError as exc:
        raise ServiceError("database_unavailable", "PostgreSQL is unavailable or migrations have not been applied.", 503) from exc


@evidence_router.post("/documents", status_code=201)
def ingest_document(body: ClinicalDocumentIngest, session: Session = Depends(get_db)):
    document = ClinicalDocument(
        document_id=body.document_id, title=body.title, organization_or_authors=body.organization_or_authors,
        publication_year=body.publication_year, source_type=body.source_type, publisher=body.publisher,
        doi=body.doi, official_url=body.official_url, local_filename=body.local_filename,
        version=body.version, access_date=body.access_date, copyright_note=body.copyright_note,
        chunks=[DocumentChunk(chunk_index=i, text=chunk.text, page_number=chunk.page_number,
                              section_heading=chunk.section_heading, embedding_model=chunk.embedding_model,
                              embedding=chunk.embedding)
                for i, chunk in enumerate(body.chunks)],
    )
    session.add(document)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise ServiceError("document_conflict", "Document ID already exists or a database constraint was violated.", 409) from exc
    return {"document_id": document.document_id, "title": document.title,
            "chunk_count": len(document.chunks), "embedded_chunk_count": sum(c.embedding is not None for c in document.chunks),
            "notice": "Document metadata and text are stored as supplied; source authenticity and currency are not verified."}


@evidence_router.post("/vector-search")
def vector_search(body: VectorSearchRequest, session: Session = Depends(get_db)):
    distance = DocumentChunk.embedding.cosine_distance(body.embedding).label("cosine_distance")
    statement = (select(DocumentChunk, ClinicalDocument, distance)
                 .join(ClinicalDocument, ClinicalDocument.document_id == DocumentChunk.document_id)
                 .where(DocumentChunk.embedding.is_not(None), DocumentChunk.embedding_model == body.embedding_model)
                 .order_by(distance).limit(body.limit))
    try:
        results = session.execute(statement).all()
    except SQLAlchemyError as exc:
        raise ServiceError("vector_search_failed", "Vector search failed; confirm the pgvector migration is applied.", 503) from exc
    passages = [{"chunk_id": chunk.chunk_id, "document_id": doc.document_id, "title": doc.title,
                 "organization_or_authors": doc.organization_or_authors, "publication_year": doc.publication_year,
                 "source_type": doc.source_type, "doi": doc.doi, "official_url": doc.official_url,
                 "page_number": chunk.page_number, "section_heading": chunk.section_heading,
                 "embedding_model": chunk.embedding_model,
                 "text": chunk.text, "cosine_distance": float(dist)} for chunk, doc, dist in results]
    return {"passages": passages, "count": len(passages),
            "message": None if passages else "No embedded document chunks matched. Ingest chunks with embeddings first."}


@history_router.get("/{conversation_id}/history")
def conversation_history(conversation_id: str, session: Session = Depends(get_db)):
    rows = session.scalars(select(AIConversationHistory).where(
        AIConversationHistory.conversation_id == conversation_id).order_by(AIConversationHistory.created_at, AIConversationHistory.id)).all()
    return {"conversation_id": conversation_id,
            "messages": [{"role": row.role, "content": row.content, "patient_id": row.patient_id,
                         "citations": row.citations or [], "created_at": row.created_at.isoformat()} for row in rows]}
