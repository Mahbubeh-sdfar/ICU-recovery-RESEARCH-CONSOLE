from fastapi import APIRouter, Depends
from sqlalchemy.exc import SQLAlchemyError

from app.api.dependencies import services
from app.core.errors import ServiceError
from app.db.models import MLPrediction
from app.db.session import get_optional_db
from app.schemas.prediction import PredictionRequest, PredictionResponse

router = APIRouter(prefix="/api/predictions", tags=["research predictions"])


@router.post("/{patient_id}", response_model=PredictionResponse)
def predict(patient_id: str, body: PredictionRequest, svc=Depends(services), session=Depends(get_optional_db)):
    result = svc.predictions.predict(patient_id, body.target, body.prediction_time_hours)
    if session is not None:
        session.add(MLPrediction(patient_id=patient_id, target=body.target, probability=result["probability"],
            model_name=result["model_name"], model_version=result["model_version"],
            prediction_time_hours=body.prediction_time_hours))
        try:
            session.commit()
        except SQLAlchemyError as exc:
            session.rollback()
            raise ServiceError("prediction_persistence_failed", "Prediction was generated but could not be recorded in database history.", 503) from exc
    return result
