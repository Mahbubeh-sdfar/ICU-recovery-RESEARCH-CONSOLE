from typing import Any

from fastapi import APIRouter, Depends, Query

from app.api.dependencies import services
from app.db.queries import DatabaseQueries
from app.db.session import get_optional_db

router = APIRouter(prefix="/api/patients", tags=["patients"])


@router.get("")
def list_patients(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                  surgery_category: str | None = Query(None, max_length=40), svc=Depends(services),
                  session=Depends(get_optional_db)) -> dict[str, Any]:
    if session is not None:
        return DatabaseQueries(session).list_patients(limit, offset, surgery_category)
    return svc.dataset.list_patients(limit, offset, surgery_category)


@router.get("/{patient_id}")
def get_patient(patient_id: str, svc=Depends(services), session=Depends(get_optional_db)) -> dict[str, Any]:
    if session is not None:
        return DatabaseQueries(session).patient(patient_id)
    return svc.dataset.profile(patient_id)


@router.get("/{patient_id}/observations")
def get_observations(patient_id: str, start_hour: int = Query(0, ge=0, le=168),
                     end_hour: int = Query(168, ge=0, le=168), limit: int = Query(500, ge=1, le=1000),
                     svc=Depends(services), session=Depends(get_optional_db)) -> dict[str, Any]:
    if end_hour < start_hour:
        from app.core.errors import ServiceError
        raise ServiceError("invalid_time_range", "end_hour must be greater than or equal to start_hour.", 422)
    if session is not None:
        return DatabaseQueries(session).observations(patient_id, start_hour, end_hour, limit)
    return svc.dataset.observations(patient_id, start_hour, end_hour, limit)


@router.get("/{patient_id}/timeline")
def patient_timeline(patient_id: str, svc=Depends(services), session=Depends(get_optional_db)) -> dict[str, Any]:
    if session is not None:
        return DatabaseQueries(session).observations(patient_id)
    return svc.dataset.observations(patient_id)
