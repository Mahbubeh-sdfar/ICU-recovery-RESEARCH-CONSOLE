import re


_DIRECT_IDENTIFIER_PATTERNS = (
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),  # SSN-shaped identifier
    re.compile(r"\b\d{10,}\b"),             # long numeric IDs and unformatted phone numbers
    re.compile(r"\b\S+@\S+\.\S+\b"),      # email address
    re.compile(r"\b(?:date of birth|dob|medical record number|mrn|home address|patient name)\b", re.I),
    re.compile(r"\b(?:19|20)\d{2}-\d{2}-\d{2}\b"),  # ISO calendar date
)


def contains_direct_identifier(value: str) -> bool:
    return any(pattern.search(value) for pattern in _DIRECT_IDENTIFIER_PATTERNS)
