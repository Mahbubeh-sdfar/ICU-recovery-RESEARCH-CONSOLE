from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv


BACKEND_DIR = Path(__file__).resolve().parents[2]
PROJECT_ROOT = BACKEND_DIR.parent
load_dotenv(BACKEND_DIR / ".env")


class Settings:
    """Small environment-backed settings object; secrets are never logged."""

    def __init__(self) -> None:
        self.app_env = os.getenv("APP_ENV", "development")
        self.log_level = os.getenv("LOG_LEVEL", "INFO").upper()
        self.dataset_path = Path(os.getenv("DATASET_PATH", str(PROJECT_ROOT / "data" / "synthetic_icu_patients.csv"))).resolve()
        self.model_dir = Path(os.getenv("MODEL_DIR", str(BACKEND_DIR / "artifacts"))).resolve()
        self.evidence_store_path = Path(os.getenv("EVIDENCE_STORE_PATH", str(BACKEND_DIR / "data" / "evidence_store.json"))).resolve()
        self.ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
        self.ollama_chat_model = os.getenv("OLLAMA_CHAT_MODEL", "gemma3:4b")
        self.ollama_embed_model = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
        self.ollama_timeout_seconds = float(os.getenv("OLLAMA_TIMEOUT_SECONDS", "180"))
        self.ollama_num_ctx = int(os.getenv("OLLAMA_NUM_CTX", "2048"))
        if self.ollama_timeout_seconds <= 0:
            raise ValueError("OLLAMA_TIMEOUT_SECONDS must be positive")
        if self.ollama_num_ctx < 256:
            raise ValueError("OLLAMA_NUM_CTX must be at least 256")
        self.database_url = os.getenv("DATABASE_URL", "postgresql+psycopg://icu_research@127.0.0.1:5432/icu_research")
        self.embedding_dimension = int(os.getenv("EMBEDDING_DIMENSION", "768"))
        self.research_source_dir = Path(os.getenv("RESEARCH_SOURCE_DIR", str(PROJECT_ROOT / "data" / "papers"))).resolve()
        self.document_storage_dir = Path(os.getenv("DOCUMENT_STORAGE_DIR", str(BACKEND_DIR / "document_storage" / "research"))).resolve()
        self.research_manifest_path = Path(os.getenv("RESEARCH_MANIFEST_PATH", str(BACKEND_DIR / "research_corpus" / "manifest.json"))).resolve()
        self.ingestion_admin_token = os.getenv("INGESTION_ADMIN_TOKEN", "")
        self.chunk_target_tokens = int(os.getenv("CHUNK_TARGET_TOKENS", "550"))
        self.chunk_overlap_tokens = int(os.getenv("CHUNK_OVERLAP_TOKENS", "75"))
        self.database_enabled = os.getenv("DATABASE_ENABLED", "false").lower() in {"1", "true", "yes"}
        if not 1 <= self.embedding_dimension <= 2000:
            raise ValueError("EMBEDDING_DIMENSION must be between 1 and 2000 for the configured pgvector HNSW index")
        if self.chunk_target_tokens < 100 or not 0 <= self.chunk_overlap_tokens < self.chunk_target_tokens:
            raise ValueError("Chunk target must be >=100 and overlap must be nonnegative and smaller than target")


settings = Settings()
