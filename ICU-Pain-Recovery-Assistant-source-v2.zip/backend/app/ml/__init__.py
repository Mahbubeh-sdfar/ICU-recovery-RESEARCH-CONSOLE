"""Leakage-safe training and evaluation for synthetic research outcomes."""
