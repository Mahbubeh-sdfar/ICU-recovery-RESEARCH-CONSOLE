from __future__ import annotations

import json
import math
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from sklearn.base import clone
from sklearn.calibration import calibration_curve
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix,
                             f1_score, precision_recall_curve, precision_score, recall_score,
                             roc_auc_score, roc_curve)
from sklearn.model_selection import GridSearchCV, StratifiedGroupKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from app.core.config import settings
from app.services.dataset import DatasetService


SEED = 20261102
PREDICTION_TIME_HOURS = 6
SYNTHETIC_NOTICE = (
    "SYNTHETIC-DATA EXPERIMENT ONLY. These results measure performance on artificially generated data. "
    "They are not clinical evidence, real-patient performance estimates, or suitable for patient care or clinical validation."
)
TARGET_NAMES = ("uncontrolled_pain", "delayed_mobilization")
MODEL_GRIDS: dict[str, tuple[Any, dict[str, list[Any]]]] = {
    "logistic_regression": (
        LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED),
        {"classifier__C": [0.1, 1.0, 10.0]},
    ),
    "random_forest": (
        RandomForestClassifier(class_weight="balanced_subsample", random_state=SEED, n_jobs=-1),
        {"classifier__n_estimators": [200], "classifier__max_depth": [None, 10],
         "classifier__min_samples_leaf": [1, 3], "classifier__max_features": ["sqrt", 0.8]},
    ),
    "hist_gradient_boosting": (
        HistGradientBoostingClassifier(class_weight="balanced", random_state=SEED),
        {"classifier__max_iter": [100, 200], "classifier__learning_rate": [0.05, 0.1],
         "classifier__max_leaf_nodes": [15, 31]},
    ),
}


def patient_level_frame(dataset: DatasetService, target: str) -> pd.DataFrame:
    """Aggregate eligible <=6-hour features to exactly one row per patient."""
    if target not in TARGET_NAMES:
        raise ValueError(f"Unsupported target: {target}")
    target_column = f"{target}_target"
    records: list[dict[str, Any]] = []
    for patient_id, observations in dataset.all_patient_records().items():
        if not observations:
            continue
        splits = {row.get("data_split") for row in observations}
        labels = {row.get(target_column) for row in observations}
        if len(splits) != 1:
            raise ValueError(f"Patient {patient_id} crosses supplied data splits")
        labels.discard(None)
        if len(labels) > 1:
            raise ValueError(f"Patient {patient_id} has inconsistent {target_column} labels")
        if not labels:
            # The pain outcome is undefined if no eligible post-index assessment exists.
            continue
        features = dataset.prediction_features(patient_id, PREDICTION_TIME_HOURS)
        forbidden = {"patient_id", target_column, "uncontrolled_pain_target", "delayed_mobilization_target",
                     "first_mobilization_hours", "mobilization_by_72h", "icu_length_of_stay_hours",
                     "observation_hours_postop", "observation_datetime_utc", "data_split"}
        leaked = forbidden.intersection(features)
        if leaked:
            raise ValueError(f"Leakage fields present in features: {sorted(leaked)}")
        # Only aggregate records at/before the index; delayed-mobility post-index status is never used.
        records.append({"patient_id": patient_id, "data_split": next(iter(splits)),
                        "target": int(next(iter(labels))), **features})
    frame = pd.DataFrame.from_records(records)
    if frame.empty:
        raise ValueError(f"No labeled patients are available for {target}")
    if frame["patient_id"].duplicated().any():
        raise ValueError("Model matrix must contain one row per patient")
    return frame


def make_pipeline(frame: pd.DataFrame, classifier: Any, scale_numeric: bool) -> Pipeline:
    feature_columns = [col for col in frame.columns if col not in {"patient_id", "data_split", "target"}]
    numeric = [c for c in feature_columns if pd.api.types.is_numeric_dtype(frame[c])]
    categorical = [c for c in feature_columns if c not in numeric]
    numeric_steps: list[tuple[str, Any]] = [("imputer", SimpleImputer(strategy="median", add_indicator=True,
                                                                          keep_empty_features=True))]
    if scale_numeric:
        numeric_steps.append(("scaler", StandardScaler()))
    categorical_steps = [
        ("imputer", SimpleImputer(strategy="most_frequent", add_indicator=True, keep_empty_features=True)),
        ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ]
    transformers = []
    if numeric:
        transformers.append(("numeric", Pipeline(numeric_steps), numeric))
    if categorical:
        transformers.append(("categorical", Pipeline(categorical_steps), categorical))
    preprocessor = ColumnTransformer(transformers, remainder="drop", verbose_feature_names_out=True)
    return Pipeline([("preprocessor", preprocessor), ("classifier", classifier)])


def choose_threshold(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    """Choose a research-only F1 threshold on validation data, never on test data."""
    candidates = np.unique(np.concatenate(([0.5], probabilities)))
    scored = [(f1_score(y_true, probabilities >= threshold, zero_division=0),
               -abs(float(threshold) - 0.5), float(threshold)) for threshold in candidates]
    return max(scored)[2]


def classification_metrics(y_true: np.ndarray, probabilities: np.ndarray, threshold: float) -> dict[str, Any]:
    predictions = (probabilities >= threshold).astype(int)
    matrix = confusion_matrix(y_true, predictions, labels=[0, 1])
    tn, fp, fn, tp = (int(x) for x in matrix.ravel())
    return {
        "auroc": float(roc_auc_score(y_true, probabilities)) if len(np.unique(y_true)) == 2 else None,
        "auprc": float(average_precision_score(y_true, probabilities)) if len(np.unique(y_true)) == 2 else None,
        "sensitivity": float(recall_score(y_true, predictions, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if tn + fp else None,
        "precision": float(precision_score(y_true, predictions, zero_division=0)),
        "f1": float(f1_score(y_true, predictions, zero_division=0)),
        "brier_score": float(brier_score_loss(y_true, probabilities)),
        "threshold_research_only": float(threshold),
        "confusion_matrix_labels": ["negative", "positive"],
        "confusion_matrix": [[tn, fp], [fn, tp]],
        "class_count": {"negative": int((y_true == 0).sum()), "positive": int((y_true == 1).sum())},
    }


def calibration_bins(y_true: np.ndarray, probabilities: np.ndarray, bins: int = 10) -> dict[str, list[float]]:
    observed, predicted = calibration_curve(y_true, probabilities, n_bins=bins, strategy="quantile")
    return {"mean_predicted_probability": [float(x) for x in predicted],
            "observed_fraction_positive": [float(x) for x in observed]}


def _prepare_split(frame: pd.DataFrame) -> dict[str, Any]:
    training = frame.loc[frame["data_split"] == "train"].copy()
    test = frame.loc[frame["data_split"] == "test"].copy()
    if training.empty or test.empty:
        raise ValueError("The supplied patient-level train and test partitions must both be non-empty")
    fit, validation = train_test_split(training, test_size=0.20, random_state=SEED,
                                       stratify=training["target"])
    return {"fit": fit, "validation": validation, "development": training, "test": test}


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    return value


def _save_comparison_plots(target: str, y_test: np.ndarray, predictions: dict[str, np.ndarray],
                           thresholded: dict[str, tuple[np.ndarray, float]], report_dir: Path) -> None:
    names = list(predictions)
    fig, axes = plt.subplots(1, len(names), figsize=(5 * len(names), 4))
    for ax, name in zip(np.atleast_1d(axes), names):
        probs = predictions[name]
        fpr, tpr, _ = roc_curve(y_test, probs)
        auc = roc_auc_score(y_test, probs)
        ax.plot(fpr, tpr, label=f"AUROC={auc:.3f}")
        ax.plot([0, 1], [0, 1], "--", color="gray")
        ax.set(title=name.replace("_", " "), xlabel="False positive rate", ylabel="Sensitivity")
        ax.legend(loc="lower right")
    fig.suptitle(f"{target}: ROC curves — synthetic-data experiment")
    fig.tight_layout()
    fig.savefig(report_dir / f"{target}_roc.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(1, len(names), figsize=(5 * len(names), 4))
    for ax, name in zip(np.atleast_1d(axes), names):
        probabilities = predictions[name]
        observed, predicted = calibration_curve(y_test, probabilities, n_bins=10, strategy="quantile")
        brier = brier_score_loss(y_test, probabilities)
        ax.plot(predicted, observed, marker="o", label=f"Brier={brier:.3f}")
        ax.plot([0, 1], [0, 1], "--", color="gray")
        ax.set(title=name.replace("_", " "), xlabel="Mean predicted probability", ylabel="Observed positive fraction",
               xlim=(0, 1), ylim=(0, 1))
        ax.legend(loc="upper left")
    fig.suptitle(f"{target}: calibration — synthetic-data experiment")
    fig.tight_layout()
    fig.savefig(report_dir / f"{target}_calibration.png", dpi=150)
    plt.close(fig)

    fig, axes = plt.subplots(1, len(names), figsize=(5 * len(names), 4))
    for ax, name in zip(np.atleast_1d(axes), names):
        predicted, threshold = thresholded[name]
        matrix = confusion_matrix(y_test, predicted, labels=[0, 1])
        ax.imshow(matrix, cmap="Blues")
        ax.set(title=f"{name.replace('_', ' ')}\nvalidation F1 threshold={threshold:.3f}",
               xticks=[0, 1], yticks=[0, 1], xlabel="Predicted", ylabel="Observed")
        for (row, col), value in np.ndenumerate(matrix):
            ax.text(col, row, str(value), ha="center", va="center")
    fig.suptitle(f"{target}: test confusion matrices — synthetic-data experiment")
    fig.tight_layout()
    fig.savefig(report_dir / f"{target}_confusion_matrices.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5))
    for name, probs in predictions.items():
        precision, recall, _ = precision_recall_curve(y_test, probs)
        ax.plot(recall, precision, label=f"{name.replace('_', ' ')} (AP={average_precision_score(y_test, probs):.3f})")
    ax.set(title=f"{target}: precision-recall curves — synthetic-data experiment",
           xlabel="Recall", ylabel="Precision", xlim=(0, 1), ylim=(0, 1))
    ax.legend()
    fig.tight_layout()
    fig.savefig(report_dir / f"{target}_precision_recall.png", dpi=150)
    plt.close(fig)


def _save_feature_importance(name: str, estimator: Pipeline, X_validation: pd.DataFrame,
                             y_validation: np.ndarray, report_dir: Path, target: str) -> list[dict[str, Any]]:
    result = permutation_importance(estimator, X_validation, y_validation, scoring="roc_auc",
                                   n_repeats=5, random_state=SEED, n_jobs=-1)
    rows = [{"feature": feature, "mean_auroc_decrease": float(mean), "std": float(std)}
            for feature, mean, std in zip(X_validation.columns, result.importances_mean, result.importances_std)]
    rows.sort(key=lambda row: row["mean_auroc_decrease"], reverse=True)
    csv_path = report_dir / f"{target}_{name}_feature_importance.csv"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    if rows:
        top = rows[:20][::-1]
        fig, ax = plt.subplots(figsize=(9, max(4, len(top) * 0.28)))
        ax.barh([row["feature"] for row in top], [row["mean_auroc_decrease"] for row in top],
                xerr=[row["std"] for row in top])
        ax.set(title=f"{target} / {name}: permutation importance (validation)", xlabel="AUROC decrease after permutation")
        fig.tight_layout()
        fig.savefig(report_dir / f"{target}_{name}_feature_importance.png", dpi=150)
        plt.close(fig)
    return rows


def _save_shap(name: str, estimator: Pipeline, X_validation: pd.DataFrame,
               report_dir: Path, target: str) -> dict[str, Any]:
    """Create a validation-sample SHAP plot for the selected model where supported."""
    try:
        preprocessor = estimator.named_steps["preprocessor"]
        classifier = estimator.named_steps["classifier"]
        transformed = np.asarray(preprocessor.transform(X_validation.iloc[:min(100, len(X_validation))]))
        feature_names = preprocessor.get_feature_names_out()
        if isinstance(classifier, (RandomForestClassifier, HistGradientBoostingClassifier)):
            explainer = shap.TreeExplainer(classifier)
        elif isinstance(classifier, LogisticRegression):
            background = transformed[:min(50, len(transformed))]
            explainer = shap.LinearExplainer(classifier, background)
        else:
            return {"status": "not_applicable", "reason": "No supported explainer for selected estimator."}
        values = explainer(transformed)
        shap_array = np.asarray(values.values if hasattr(values, "values") else values)
        if shap_array.ndim == 3:
            shap_array = shap_array[:, :, 1]
        plt.figure(figsize=(9, 6))
        shap.summary_plot(shap_array, transformed, feature_names=feature_names, plot_type="bar",
                          max_display=20, show=False)
        plt.title(f"{target} / {name}: SHAP summary — validation sample")
        plt.tight_layout()
        plt.savefig(report_dir / f"{target}_{name}_shap.png", dpi=150, bbox_inches="tight")
        plt.close()
        return {"status": "created", "file": f"{target}_{name}_shap.png",
                "sample_size": int(len(transformed)),
                "note": "SHAP values explain model output on synthetic validation patients; they are not causal or clinical explanations."}
    except Exception as exc:  # SHAP support varies by estimator/library version; training results remain usable.
        plt.close("all")
        return {"status": "unavailable", "reason": f"{type(exc).__name__}: {exc}"}


def _write_markdown_report(target: str, result: dict[str, Any], report_dir: Path) -> None:
    lines = [f"# {target.replace('_', ' ').title()} model evaluation", "", f"> **{SYNTHETIC_NOTICE}**", "",
             "## Design", "", f"- Prediction index: postoperative hour {PREDICTION_TIME_HOURS}.",
             "- Unit of analysis: one aggregated feature row per synthetic patient.",
             "- Split: supplied patient-level train/test partition; validation sampled only from supplied training patients.",
             "- Hyperparameter tuning: 5-fold StratifiedGroupKFold on the fit partition, grouped by patient ID.",
             "- Thresholds: selected from validation predictions by maximum F1; research-only and not clinical cutoffs.",
             "- Imputation and one-hot encoding are fitted inside each cross-validation pipeline.",
             "- All feature values are restricted to baseline and observations at or before hour 6.", "",
             "## Class balance", "", "| Partition | Patients | Negative | Positive | Positive fraction |", "|---|---:|---:|---:|---:|"]
    for part, counts in result["class_balance"].items():
        lines.append(f"| {part} | {counts['patients']} | {counts['negative']} | {counts['positive']} | {counts['positive_fraction']:.3f} |")
    lines += ["", "## Model comparison on held-out test patients", "",
              "| Model | Test AUROC | Test AUPRC | Sensitivity | Specificity | F1 | Brier | Validation AUROC | 5-fold CV AUROC |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for name, model_result in result["models"].items():
        m = model_result["test_metrics"]
        lines.append(f"| {name} | {m['auroc']:.3f} | {m['auprc']:.3f} | {m['sensitivity']:.3f} | {m['specificity']:.3f} | {m['f1']:.3f} | {m['brier_score']:.3f} | {model_result['validation_metrics']['auroc']:.3f} | {model_result['cross_validation']['auroc']:.3f} |")
    lines += ["", f"Selected deployment candidate by validation AUROC: **{result['selected_model']}**.",
              "The test set was not used for model or threshold selection.", "",
              "## Figures and artifacts", "",
              f"- ROC: `{target}_roc.png`; precision-recall: `{target}_precision_recall.png`.",
              f"- Calibration: `{target}_calibration.png`; confusion matrices: `{target}_confusion_matrices.png`.",
              f"- Selected model permutation importance: `{target}_{result['selected_model']}_feature_importance.csv`.",
              f"- SHAP status: `{result['shap']['status']}`.", "",
              "## Interpretation limits", "",
              "These results describe a hand-designed artificial data generator. They must not be interpreted as clinical evidence, real-world prevalence, validated clinical performance, or treatment guidance. Feature importance and SHAP values describe model behavior on this simulated dataset and do not establish causation.", ""]
    (report_dir / f"{target}_report.md").write_text("\n".join(lines), encoding="utf-8")


def train_and_evaluate(dataset: DatasetService | None = None, model_dir: Path | None = None,
                       report_dir: Path | None = None) -> dict[str, Any]:
    dataset = dataset or DatasetService(settings.dataset_path)
    model_dir = model_dir or settings.model_dir
    report_dir = report_dir or (settings.model_dir.parent / "reports" / "model_evaluation")
    model_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    all_results: dict[str, Any] = {"synthetic_data_experiment": True, "notice": SYNTHETIC_NOTICE,
                                   "seed": SEED, "prediction_time_hours": PREDICTION_TIME_HOURS,
                                   "targets": {}}
    trained_at = datetime.now(timezone.utc).isoformat()

    for target in TARGET_NAMES:
        frame = patient_level_frame(dataset, target)
        splits = _prepare_split(frame)
        X_fit = splits["fit"].drop(columns=["patient_id", "data_split", "target"])
        y_fit = splits["fit"]["target"].to_numpy(dtype=int)
        groups = splits["fit"]["patient_id"].to_numpy()
        X_validation = splits["validation"].drop(columns=["patient_id", "data_split", "target"])
        y_validation = splits["validation"]["target"].to_numpy(dtype=int)
        X_development = splits["development"].drop(columns=["patient_id", "data_split", "target"])
        y_development = splits["development"]["target"].to_numpy(dtype=int)
        X_test = splits["test"].drop(columns=["patient_id", "data_split", "target"])
        y_test = splits["test"]["target"].to_numpy(dtype=int)

        class_balance = {}
        for part in ("fit", "validation", "test"):
            labels = splits[part]["target"].to_numpy(dtype=int)
            positive = int((labels == 1).sum())
            class_balance[part] = {"patients": int(len(labels)), "positive": positive,
                                   "negative": int(len(labels) - positive),
                                   "positive_fraction": float(positive / len(labels))}

        cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
        model_results: dict[str, Any] = {}
        validation_probabilities: dict[str, np.ndarray] = {}
        test_probabilities: dict[str, np.ndarray] = {}
        thresholded_test: dict[str, tuple[np.ndarray, float]] = {}
        fitted_on_development: dict[str, Pipeline] = {}

        for model_name, (classifier, param_grid) in MODEL_GRIDS.items():
            pipeline = make_pipeline(frame, classifier, scale_numeric=(model_name == "logistic_regression"))
            search = GridSearchCV(
                pipeline, param_grid, scoring={"auroc": "roc_auc", "auprc": "average_precision", "f1": "f1"},
                refit="auroc", cv=cv, n_jobs=-1, return_train_score=False, error_score="raise",
            )
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                search.fit(X_fit, y_fit, groups=groups)
            best = search.best_estimator_
            validation_scores = best.predict_proba(X_validation)[:, 1]
            threshold = choose_threshold(y_validation, validation_scores)
            validation_metrics = classification_metrics(y_validation, validation_scores, threshold)
            final_estimator = clone(best)
            final_estimator.fit(X_development, y_development)
            test_scores = final_estimator.predict_proba(X_test)[:, 1]
            test_metrics = classification_metrics(y_test, test_scores, threshold)
            cv_report = {"auroc": float(search.best_score_),
                         "auprc": float(search.cv_results_["mean_test_auprc"][search.best_index_]),
                         "f1_at_default_0_5": float(search.cv_results_["mean_test_f1"][search.best_index_]),
                         "folds": 5, "refit_metric": "auroc"}
            model_results[model_name] = {"best_params": search.best_params_, "cross_validation": cv_report,
                                         "validation_metrics": validation_metrics,
                                         "test_metrics": test_metrics,
                                         "validation_calibration": calibration_bins(y_validation, validation_scores),
                                         "test_calibration": calibration_bins(y_test, test_scores)}
            validation_probabilities[model_name] = validation_scores
            test_probabilities[model_name] = test_scores
            thresholded_test[model_name] = ((test_scores >= threshold).astype(int), threshold)
            fitted_on_development[model_name] = final_estimator

            artifact = {"pipeline": final_estimator, "model_name": model_name,
                        "model_version": "synthetic-research-v2", "target": target,
                        "training_patients": int(len(splits["development"])),
                        "prediction_time_hours": PREDICTION_TIME_HOURS, "trained_at_utc": trained_at,
                        "validation_threshold_research_only": threshold,
                        "feature_policy": "baseline and observations available at or before postoperative hour 6; one row per patient",
                        "synthetic_data": True, "clinical_use": False}
            joblib.dump(artifact, model_dir / f"{target}_{model_name}.joblib")

        # Choose only by validation AUROC (tie-break by validation AUPRC); never inspect test metrics here.
        selected_model = max(model_results, key=lambda name: (
            model_results[name]["validation_metrics"]["auroc"],
            model_results[name]["validation_metrics"]["auprc"],
        ))
        selected_threshold = model_results[selected_model]["validation_metrics"]["threshold_research_only"]
        deploy_artifact = {"pipeline": fitted_on_development[selected_model], "model_name": selected_model,
                           "model_version": "synthetic-research-v2", "target": target,
                           "training_patients": int(len(splits["development"])),
                           "prediction_time_hours": PREDICTION_TIME_HOURS, "trained_at_utc": trained_at,
                           "validation_threshold_research_only": selected_threshold,
                           "feature_policy": "baseline and observations available at or before postoperative hour 6; one row per patient",
                           "synthetic_data": True, "clinical_use": False}
        joblib.dump(deploy_artifact, model_dir / f"{target}.joblib")

        feature_importance = {}
        for model_name, estimator in fitted_on_development.items():
            feature_importance[model_name] = _save_feature_importance(
                model_name, estimator, X_validation, y_validation, report_dir, target)
        shap_status = _save_shap(selected_model, fitted_on_development[selected_model],
                                 X_validation, report_dir, target)
        _save_comparison_plots(target, y_test, test_probabilities, thresholded_test, report_dir)
        target_result = {
            "target": target,
            "notice": SYNTHETIC_NOTICE,
            "n_labeled_patients": int(len(frame)),
            "patient_counts": {key: int(len(value)) for key, value in splits.items()},
            "class_balance": class_balance,
            "excluded_unlabeled_patients": int(dataset.patient_count - len(frame)),
            "feature_columns": [col for col in frame.columns if col not in {"patient_id", "data_split", "target"}],
            "feature_policy": "DatasetService prediction_features restricted to <=6 hours; patient-level aggregation; future/outcome fields rejected.",
            "models": model_results,
            "selected_model": selected_model,
            "selection_rule": "Highest validation AUROC; tie-break by validation AUPRC. The test partition was not used for selection.",
            "feature_importance": feature_importance,
            "shap": shap_status,
            "calibration_metric": "Brier score; calibration curves use 10 quantile bins.",
        }
        target_result = _json_safe(target_result)
        all_results["targets"][target] = target_result
        (report_dir / f"{target}_evaluation.json").write_text(json.dumps(target_result, indent=2), encoding="utf-8")
        _write_markdown_report(target, target_result, report_dir)

    all_results["trained_at_utc"] = trained_at
    (report_dir / "evaluation_summary.json").write_text(json.dumps(_json_safe(all_results), indent=2), encoding="utf-8")
    (model_dir / "training_metadata.json").write_text(json.dumps(_json_safe(all_results), indent=2), encoding="utf-8")
    return all_results
