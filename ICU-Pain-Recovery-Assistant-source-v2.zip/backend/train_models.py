"""Tune and evaluate synthetic-data prediction models without patient leakage."""
from __future__ import annotations

import json

from app.ml.training import train_and_evaluate


def train():
    """Backward-compatible entry point used by local training instructions."""
    return train_and_evaluate()


if __name__ == "__main__":
    result = train()
    print(json.dumps({"synthetic_data_experiment": result["synthetic_data_experiment"],
                      "targets": {name: {"selected_model": target["selected_model"],
                                         "patient_counts": target["patient_counts"]}
                                  for name, target in result["targets"].items()},
                      "notice": result["notice"]}, indent=2))
