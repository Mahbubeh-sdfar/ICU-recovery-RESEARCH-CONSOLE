# LangGraph assistant workflow

The workflow is implemented by `app.services.chat_workflow.ICUChatWorkflow` and is used by `POST /api/chat`. It only reads synthetic patient data, existing research predictions, and local evidence passages. It has no tool or route for placing orders or executing treatment.

```mermaid
flowchart TD
    START([Start]) --> QC[Query classifier]
    QC -->|Unsafe action request| SV[Safety verification]
    QC -->|Patient or general question| PC[Patient context]
    PC --> DV[Data validation]
    DV -->|Missing or inconsistent required data| RG[Response generation: clarification]
    DV -->|Sufficient context| MP[ML prediction]
    MP -->|Evidence required| ER[Evidence retrieval]
    MP -->|No evidence needed| CR[Clinical reasoning]
    ER --> CR
    CR --> SV
    SV --> RG
    RG --> END([End])
```

## Node responsibilities

1. **Query classifier** categorizes the request as patient summary, pain, sedation, vital signs, medication exposure, mobility/recovery, prediction, clinical evidence, general help, or an unsafe action. It determines if a synthetic patient is required, identifies a prediction target, and decides whether evidence retrieval is needed.
2. **Patient context** fetches only the selected synthetic profile and relevant observations. For prediction requests it limits observations to the documented prediction time and removes target labels, length of stay, and future mobilization outcomes from model-facing context.
3. **Data validation** checks required patient context, observation order, score ranges, and the NRS/CPOT distinction. Missing required context routes to a response that asks the clinician to clarify.
4. **ML prediction** retrieves the configured research prediction and its limitations when a prediction is requested. Missing model artifacts are returned as limitations; prediction failure does not silently change the target.
5. **Evidence retrieval** searches the local evidence collection and assigns temporary reference labels to passages. No match routes to an explicit evidence-insufficient abstention without an LLM call.
6. **Clinical reasoning** asks the configured model provider to summarize only supplied context and retrieved passages. Provider failures are contained and never trigger an external-provider fallback.
7. **Safety verification** blocks medication/order and mobilization-safety instructions, rejects citations that do not map to retrieved passages, and requires citation markers for evidence-answer paragraphs.
8. **Response generation** returns a structured answer, citation records, limitations, workflow category, and clarification fields.

## Conditional routing

- Unsafe requests go directly to safety verification, then to a refusal response.
- Missing/invalid synthetic patient IDs or required observations go from data validation to clarification, bypassing prediction and model generation.
- Valid requests retrieve a prediction only when the query asks for one.
- Evidence retrieval runs when explicitly requested, when `include_evidence` is true, or when the question is a general clinical evidence question.
- Evidence-required questions with no relevant passages abstain and state that the local knowledge base was insufficient.
- Other supported paths reach clinical reasoning, safety verification, and response generation.

The graph can also produce its Mermaid visualization through `ICUChatWorkflow.mermaid()`.
