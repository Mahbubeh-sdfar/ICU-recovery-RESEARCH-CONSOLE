# Delayed Mobilization model evaluation

> **SYNTHETIC-DATA EXPERIMENT ONLY. These results measure performance on artificially generated data. They are not clinical evidence, real-patient performance estimates, or suitable for patient care or clinical validation.**

## Design

- Prediction index: postoperative hour 6.
- Unit of analysis: one aggregated feature row per synthetic patient.
- Split: supplied patient-level train/test partition; validation sampled only from supplied training patients.
- Hyperparameter tuning: 5-fold StratifiedGroupKFold on the fit partition, grouped by patient ID.
- Thresholds: selected from validation predictions by maximum F1; research-only and not clinical cutoffs.
- Imputation and one-hot encoding are fitted inside each cross-validation pipeline.
- All feature values are restricted to baseline and observations at or before hour 6.

## Class balance

| Partition | Patients | Negative | Positive | Positive fraction |
|---|---:|---:|---:|---:|
| fit | 3200 | 1742 | 1458 | 0.456 |
| validation | 800 | 436 | 364 | 0.455 |
| test | 1000 | 551 | 449 | 0.449 |

## Model comparison on held-out test patients

| Model | Test AUROC | Test AUPRC | Sensitivity | Specificity | F1 | Brier | Validation AUROC | 5-fold CV AUROC |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| logistic_regression | 0.637 | 0.580 | 0.864 | 0.245 | 0.619 | 0.237 | 0.637 | 0.609 |
| random_forest | 0.625 | 0.582 | 0.842 | 0.269 | 0.615 | 0.237 | 0.636 | 0.617 |
| hist_gradient_boosting | 0.614 | 0.570 | 0.900 | 0.178 | 0.619 | 0.240 | 0.618 | 0.608 |

Selected deployment candidate by validation AUROC: **logistic_regression**.
The test set was not used for model or threshold selection.

## Figures and artifacts

- ROC: `delayed_mobilization_roc.png`; precision-recall: `delayed_mobilization_precision_recall.png`.
- Calibration: `delayed_mobilization_calibration.png`; confusion matrices: `delayed_mobilization_confusion_matrices.png`.
- Selected model permutation importance: `delayed_mobilization_logistic_regression_feature_importance.csv`.
- SHAP status: `created`.

## Interpretation limits

These results describe a hand-designed artificial data generator. They must not be interpreted as clinical evidence, real-world prevalence, validated clinical performance, or treatment guidance. Feature importance and SHAP values describe model behavior on this simulated dataset and do not establish causation.
