# Uncontrolled Pain model evaluation

> **SYNTHETIC-DATA EXPERIMENT ONLY. These results measure performance on artificially generated data. They are not clinical evidence, real-patient performance estimates, or suitable for patient care or clinical validation.**

## Design

- Prediction index: postoperative hour 6.
- Unit of analysis: one aggregated feature row per synthetic patient.
- Split: supplied patient-level train/test partition; validation sampled only from supplied training patients.
- Hyperparameter tuning: 5-fold StratifiedGroupKFold on the fit partition, grouped by patient ID.
- Thresholds: selected from validation predictions by maximum F1; research-only and not clinical cutoffs.
- Imputation and one-hot encoding are fitted inside each cross-validation pipeline.
- All feature values are restricted to baseline and observations at or before hour 6.

## Class balance

| Partition | Patients | Negative | Positive | Positive fraction |
|---|---:|---:|---:|---:|
| fit | 3200 | 1780 | 1420 | 0.444 |
| validation | 800 | 445 | 355 | 0.444 |
| test | 1000 | 569 | 431 | 0.431 |

## Model comparison on held-out test patients

| Model | Test AUROC | Test AUPRC | Sensitivity | Specificity | F1 | Brier | Validation AUROC | 5-fold CV AUROC |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| logistic_regression | 0.746 | 0.682 | 0.768 | 0.629 | 0.680 | 0.203 | 0.682 | 0.728 |
| random_forest | 0.735 | 0.665 | 0.847 | 0.425 | 0.650 | 0.208 | 0.670 | 0.722 |
| hist_gradient_boosting | 0.735 | 0.669 | 0.831 | 0.469 | 0.656 | 0.207 | 0.663 | 0.706 |

Selected deployment candidate by validation AUROC: **logistic_regression**.
The test set was not used for model or threshold selection.

## Figures and artifacts

- ROC: `uncontrolled_pain_roc.png`; precision-recall: `uncontrolled_pain_precision_recall.png`.
- Calibration: `uncontrolled_pain_calibration.png`; confusion matrices: `uncontrolled_pain_confusion_matrices.png`.
- Selected model permutation importance: `uncontrolled_pain_logistic_regression_feature_importance.csv`.
- SHAP status: `created`.

## Interpretation limits

These results describe a hand-designed artificial data generator. They must not be interpreted as clinical evidence, real-world prevalence, validated clinical performance, or treatment guidance. Feature importance and SHAP values describe model behavior on this simulated dataset and do not establish causation.
