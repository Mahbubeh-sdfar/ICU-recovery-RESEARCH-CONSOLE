"""Initialize an empty database with the bundled synthetic cohort, without overwriting data."""
from __future__ import annotations

import json

from sqlalchemy import func, select

from app.core.config import settings
from app.db.importer import import_synthetic_dataset
from app.db.models import Patient
from app.db.session import SessionLocal
from app.services.dataset import DatasetService


def main() -> None:
    dataset = DatasetService(settings.dataset_path)
    expected_ids = set(dataset.all_patient_records())
    with SessionLocal() as session:
        existing_count = session.scalar(select(func.count()).select_from(Patient)) or 0
        if existing_count:
            stored_ids = set(session.scalars(select(Patient.patient_id)).all())
            if stored_ids != expected_ids or any(not patient_id.startswith("SYN-") for patient_id in stored_ids):
                raise SystemExit(
                    "Database contains a different or incomplete cohort; startup will not overwrite it. "
                    "Review the data, then explicitly run scripts.import_synthetic_dataset --replace if intended."
                )
            print(json.dumps({"status": "already_initialized", "patients": existing_count}))
            return
        result = import_synthetic_dataset(session, dataset)
        print(json.dumps({"status": "initialized", **result}, indent=2))


if __name__ == "__main__":
    main()
