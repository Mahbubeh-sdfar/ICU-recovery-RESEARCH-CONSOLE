"""Create/recreate local Ollama embeddings for already-ingested research chunks."""
from __future__ import annotations

import argparse

from sqlalchemy import or_, select

from app.core.config import settings
from app.db.models import DocumentChunk
from app.db.session import SessionLocal
from app.providers.ollama import OllamaProvider


def embed_research_documents(batch_size: int = 24) -> dict[str, int | str]:
    if not settings.database_enabled:
        raise RuntimeError("Set DATABASE_ENABLED=true before creating research embeddings.")
    provider = OllamaProvider()
    total = 0
    with SessionLocal() as session:
        while True:
            chunks = session.scalars(
                select(DocumentChunk)
                .where(or_(DocumentChunk.embedding.is_(None),
                           DocumentChunk.embedding_model != settings.ollama_embed_model))
                .order_by(DocumentChunk.document_id, DocumentChunk.chunk_index)
                .limit(batch_size)
            ).all()
            if not chunks:
                break
            inputs = [f"search_document: {chunk.text}" for chunk in chunks]
            vectors = provider.embed(inputs)
            if len(vectors) != len(chunks):
                raise RuntimeError("Ollama returned a different number of embeddings than input chunks.")
            for chunk, vector in zip(chunks, vectors, strict=True):
                chunk.embedding = vector
                chunk.embedding_model = settings.ollama_embed_model
            session.commit()
            total += len(chunks)
            print(f"Embedded {total} research chunks with {settings.ollama_embed_model}.")
    return {"embedded_chunks": total, "embedding_model": settings.ollama_embed_model,
            "embedding_dimension": settings.embedding_dimension}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch-size", type=int, default=24)
    args = parser.parse_args()
    if args.batch_size < 1 or args.batch_size > 128:
        parser.error("--batch-size must be between 1 and 128")
    result = embed_research_documents(args.batch_size)
    print(result)


if __name__ == "__main__":
    main()
