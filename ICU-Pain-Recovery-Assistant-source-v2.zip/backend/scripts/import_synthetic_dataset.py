"""Import only the bundled SYN-* dataset into a migrated PostgreSQL database."""
from __future__ import annotations

import argparse
import json

from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.importer import import_synthetic_dataset
from app.db.session import SessionLocal
from app.services.dataset import DatasetService


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace", action="store_true", help="Delete existing synthetic patient rows before reimporting.")
    args = parser.parse_args()
    dataset = DatasetService(settings.dataset_path)
    with SessionLocal() as session:
        result = import_synthetic_dataset(session, dataset, replace_existing=args.replace)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
