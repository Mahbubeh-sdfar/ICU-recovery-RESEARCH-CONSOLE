"""Run the manifest-driven local research PDF ingestion batch."""
from __future__ import annotations

import argparse
import json

from app.db.session import SessionLocal
from app.services.document_ingestion import ingest_documents


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--document-id", action="append", dest="document_ids",
                        help="Manifest document ID to ingest; may be repeated. Defaults to all approved entries.")
    args = parser.parse_args()
    with SessionLocal() as session:
        print(json.dumps(ingest_documents(session, args.document_ids), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
