"""Check the migrated PostgreSQL schema and imported synthetic data."""
from __future__ import annotations

import json

from sqlalchemy import inspect, select, text

from app.db.models import (AIConversationHistory, ClinicalDocument, ClinicalObservation, DocumentChunk,
                           MLPrediction, MedicationRecord, MobilityRecoveryAssessment, PainAssessment, Patient)
from app.db.session import SessionLocal


def main() -> None:
    expected = {"patients": Patient, "clinical_observations": ClinicalObservation, "pain_assessments": PainAssessment,
                "medication_records": MedicationRecord, "mobility_recovery_assessments": MobilityRecoveryAssessment,
                "ml_predictions": MLPrediction, "clinical_documents": ClinicalDocument,
                "document_chunks": DocumentChunk, "ai_conversation_history": AIConversationHistory}
    with SessionLocal() as session:
        inspector = inspect(session.bind)
        missing = sorted(set(expected) - set(inspector.get_table_names()))
        if missing:
            raise SystemExit(f"Missing tables; run alembic upgrade head first: {missing}")
        extension = session.execute(text("SELECT extname FROM pg_extension WHERE extname = 'vector'")).scalar()
        if extension != "vector":
            raise SystemExit("pgvector extension is missing")
        patient_count = session.scalar(select(text("count(*)")).select_from(Patient))
        non_synthetic = session.scalar(select(text("count(*)")).select_from(Patient).where(~Patient.patient_id.like("SYN-%")))
        fk_count = sum(len(inspector.get_foreign_keys(name)) for name in expected)
        vector_index = any(index["name"] == "ix_document_chunks_embedding_hnsw"
                           for index in inspector.get_indexes("document_chunks"))
        if non_synthetic:
            raise SystemExit(f"Found {non_synthetic} patient IDs outside the synthetic ID namespace")
        print(json.dumps({"status": "PASS", "tables": sorted(expected), "patient_count": patient_count,
                          "non_synthetic_patient_ids": non_synthetic, "foreign_key_count": fk_count,
                          "pgvector_extension": extension, "hnsw_vector_index": vector_index}, indent=2))


if __name__ == "__main__":
    main()
