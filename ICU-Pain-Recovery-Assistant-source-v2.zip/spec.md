# Project Specification

## ICU Pain & Recovery Assistant

### An AI-Powered Clinical Decision-Support Research Prototype for Postoperative ICU Patients

**Document status:** Version 1.1 --- Local Ollama architecture revision (2026-11-02)\
**Intended use:** Academic portfolio project and research prototype\
**Primary user:** Clinicians, fellows, and researchers\
**Development approach:** Local-first, modular, human-supervised\
**Data policy:** Synthetic data only during initial development

------------------------------------------------------------------------

# 1. Executive Summary

The ICU Pain & Recovery Assistant is a clinician-facing research
prototype designed to organize postoperative patient information,
estimate selected recovery risks, and retrieve relevant clinical
evidence.

The prototype focuses on two connected problems:

1.  **Postoperative pain:** identifying patients who may be at risk of
    uncontrolled pain.
2.  **Functional recovery:** identifying patients who may be at risk of
    delayed first mobilization.

The system combines structured patient data, machine-learning models,
and retrieval-augmented generation (RAG). A clinician can review a
synthetic patient profile, inspect model estimates, and ask questions
about the patient's recorded information. The assistant can retrieve
relevant passages from a curated clinical knowledge base and present
answers with source citations.

The system is a research and educational prototype. It is **not a
medical device, a validated clinical prediction tool, or a substitute
for professional judgment**. It must not prescribe medication, issue
orders, independently diagnose, or make autonomous treatment decisions.

The initial version will use synthetic patient data and publicly
available clinical documents. No identifiable patient information or
real clinical records will be entered.

# 2. Problem Statement and Rationale

Postoperative ICU care involves multiple sources of information: pain
scores, sedation assessments, vital signs, medication exposure,
comorbidities, mobility status, and the patient's progress over time.
Clinicians may need to review these data alongside guidelines and
research evidence when considering pain management and functional
recovery.

This project explores whether a single research interface can:

-   organize relevant patient information in a clear timeline;
-   flag patterns that may be associated with uncontrolled pain or
    delayed mobilization;
-   provide transparent, carefully qualified machine-learning estimates;
-   retrieve relevant evidence from trusted clinical sources;
-   support clinician review without replacing clinical judgment.

The rehabilitation connection is central. Pain is considered alongside
functional recovery, particularly the ability and time required to begin
mobilization. The project therefore sits at the intersection of critical
care, postoperative recovery, rehabilitation, clinical informatics, and
responsible AI.

# 3. Project Goals

## 3.1 Primary goals

1.  Build a working web-based prototype for reviewing synthetic
    postoperative ICU patient profiles.
2.  Display longitudinal observations and recovery indicators.
3.  Train and evaluate baseline machine-learning models for two defined
    research outcomes.
4.  Create a curated clinical knowledge base and a RAG pipeline that
    retrieves relevant evidence.
5.  Provide a clinician-facing AI assistant that answers questions using
    patient context and retrieved sources.
6.  Display citations and make uncertainty and data limitations visible.
7.  Produce a reproducible research report describing the methods,
    results, and limitations.

## 3.2 Secondary goals

-   Demonstrate an end-to-end software and data-science workflow.
-   Create a portfolio project relevant to technology-enabled
    personalized rehabilitation.
-   Establish a foundation that could later be adapted for collaboration
    with clinical and rehabilitation researchers.

## 3.3 Explicit non-goals

The initial prototype will not:

-   be deployed in a hospital or used to make decisions about real
    patients;
-   connect to an electronic health record (EHR), hospital information
    system, or medical device;
-   prescribe, recommend, calculate, or authorize medication doses;
-   generate medication orders or treatment plans;
-   autonomously diagnose a condition or determine that a patient is
    safe to mobilize;
-   replace a physician, nurse, physiotherapist, occupational therapist,
    or other clinician;
-   claim that synthetic-data performance demonstrates real-world
    clinical validity;
-   claim that an intervention improves outcomes based only on
    predictive associations.

# 4. Intended Users and User Roles

## 4.1 Clinician / clinical reviewer

Can: - open a synthetic patient profile; - review observations,
medications, assessments, and recovery indicators; - inspect model
estimates and explanations; - ask questions about the displayed patient
information; - review retrieved evidence and citations.

Cannot: - use the prototype to place orders or prescribe treatment; -
treat model estimates as validated clinical recommendations.

## 4.2 Researcher / administrator

Can: - review dataset summaries and model evaluation results; - manage
the local research document collection; - inspect source metadata and
retrieval results; - review system logs and test results; - manage
synthetic demonstration records.

The first release may use one local development account or a simple role
structure. Production-grade identity management is outside the initial
scope.

# 5. Core User Scenarios

## Scenario A --- Review a patient

1.  The user opens the patient list.
2.  The user selects a synthetic patient.
3.  The system displays demographics, surgery information, relevant
    history, assessments, observations, medications, and recovery
    status.
4.  The user reviews the patient's timeline.
5.  The user can open the prediction panel and see the model's
    estimates, explanation, timestamp, and limitations.

## Scenario B --- Ask a patient-context question

1.  The user opens the AI assistant from a patient profile.
2.  The user asks a question, for example: "Summarize this patient's
    pain and mobility trends."
3.  The system validates the question and retrieves relevant structured
    patient context.
4.  The system retrieves relevant clinical knowledge-base passages when
    an evidence-based answer is needed.
5.  The language model drafts a response grounded in the retrieved
    information.
6.  The system checks that factual clinical claims have supporting
    citations.
7.  The answer displays citations and any relevant uncertainty or safety
    notice.

## Scenario C --- Explore recovery trends

1.  The user opens the analytics page.
2.  The system displays distributions and trends across the synthetic
    cohort.
3.  The user filters by surgery category, age group, or other available
    variables.
4.  The user can compare model performance across the defined outcomes
    and selected subgroups, where sample sizes permit.

## Scenario D --- Review evidence

1.  The user opens the evidence section or asks an evidence question.
2.  The system searches the curated document collection.
3.  The user sees source title, organization or authors, publication
    year, relevant passage, and document location.
4.  The user can open the source document or official source URL when
    available.

# 6. Clinical and Research Scope

## 6.1 Population represented in the prototype

Synthetic adult postoperative patients who require ICU-level observation
after surgery.

The synthetic dataset must clearly state that it is generated data and
does not represent actual patients. The initial version should not
attempt to represent every ICU population or every surgical pathway.

## 6.2 Core clinical concepts

-   Postoperative pain assessment
-   Sedation and agitation assessment
-   Vital-sign monitoring
-   Analgesic and opioid exposure
-   Comorbidities and relevant risk factors
-   Mobility status and first mobilization
-   Functional recovery indicators
-   ICU length of stay
-   Evidence-informed clinical review

## 6.3 Assessment instruments

The data model may include: - Numeric Rating Scale (NRS), when the
synthetic patient is represented as able to self-report; - Critical-Care
Pain Observation Tool (CPOT), where an observational pain assessment is
appropriate; - Richmond Agitation-Sedation Scale (RASS), for
sedation/agitation status.

The system must not treat NRS and CPOT as interchangeable. Missing or
inapplicable assessments must be represented explicitly rather than
filled with invented values.

## 6.4 Functional recovery emphasis

The prototype should make functional recovery visible rather than
treating pain as the only outcome. At minimum, it should track: -
mobility status over time; - time from the defined postoperative
reference point to first mobilization; - whether first mobilization
occurred within the dataset's defined observation window; - ICU length
of stay as a descriptive outcome.

The meaning of "mobilization" must be defined in the dataset
documentation. For the synthetic prototype, use a consistent operational
definition and do not imply that it is a universal clinical definition.

# 7. Research Questions and Prediction Targets

The machine-learning component is intended to explore prediction, not
treatment effectiveness.

## 7.1 Target 1 --- Risk of uncontrolled postoperative pain

A binary research label indicating whether a synthetic patient meets the
project's predefined definition of uncontrolled pain during the
specified prediction window.

The exact threshold, observation window, and rules for handling repeated
scores must be documented in the data dictionary and research report
before model training. The definition must be described as a
project-specific operational definition, not a universal clinical
standard.

## 7.2 Target 2 --- Risk of delayed first mobilization

A binary research label indicating whether a synthetic patient meets the
project's predefined definition of delayed first mobilization.

The time threshold and reference point must be specified before
analysis. The project must explain that the threshold is an operational
research choice and not an instruction for clinical care.

## 7.3 Prediction timing and leakage prevention

Every prediction must have a clearly defined **prediction time**. Only
information available at or before that time may be used as input.

Do not use: - future pain scores to predict earlier pain outcomes; - the
eventual time to first mobilization as an input to predict delayed first
mobilization; - discharge or ICU length-of-stay information that would
not yet be known at prediction time; - variables that directly encode
the target label.

The dataset and modeling pipeline must document how leakage is
prevented.

# 8. Functional Requirements

## 8.1 Patient dashboard

The application must provide: - a synthetic patient list; - patient
identifier and basic profile; - surgery category and postoperative
timing; - current or most recent available assessments; - relevant vital
signs; - medication exposure summary; - mobility and recovery status; -
clear labels for missing or unavailable information.

## 8.2 Patient timeline

The timeline must display observations in chronological order,
including: - pain assessments; - sedation assessments; - vital signs; -
medication records; - mobility events; - recovery milestones.

Users must be able to distinguish measured values from synthetic,
derived, or missing values.

## 8.3 Prediction panel

For each supported target, display: - predicted probability or risk
score; - model name and version; - prediction timestamp; - prediction
time point; - brief explanation of important contributing features, if
available; - evaluation status and limitations; - a clear notice that
the result is not a clinical decision.

The interface must avoid presenting an arbitrary probability as a
validated clinical risk category. If low/moderate/high labels are used
for demonstration, their thresholds must be explicitly marked as
illustrative and research-only.

## 8.4 Cohort analytics

Provide: - number of synthetic patients; - distribution of surgery
categories; - pain-score trends; - mobility outcomes; - distribution of
time to first mobilization; - target-label prevalence; - model
evaluation summaries.

Charts must include units, labels, and explanations. Small subgroup
counts must be shown or flagged so that users do not overinterpret
unstable comparisons.

## 8.5 AI assistant

The assistant must: - accept natural-language questions; - use the
selected patient's context only when a patient is selected; -
distinguish patient-data questions from general evidence questions; -
retrieve relevant clinical sources for evidence-based questions; - cite
the retrieved sources; - state when information is unavailable; - avoid
unsupported certainty; - avoid making autonomous clinical decisions.

The assistant may summarize, organize, and explain information. It must
not issue orders, prescribe medication, or tell a clinician that a
patient is safe or unsafe for mobilization.

## 8.6 Evidence library

The evidence library must: - ingest approved local PDF or text
documents; - preserve source metadata; - split documents into
retrievable passages (chunks); - store embeddings and source
locations; - return passages relevant to a question; - display citations
tied to the actual retrieved passages.

## 8.7 Research administration

Provide a basic local interface or documented scripts for: - generating
the synthetic dataset; - loading data into the database; - training
models; - evaluating models; - ingesting evidence documents; - checking
document and citation metadata.

# 9. Synthetic Dataset Specification

## 9.1 Dataset size

Initial target: at least 5,000 synthetic patient records, with multiple
longitudinal observations per patient.

The generator must be deterministic when a random seed is supplied.

## 9.2 Patient-level fields

Suggested fields: - patient_id: synthetic unique identifier; - age; -
sex; - height and weight, if included; - surgery_category; -
surgery_type; - surgery_datetime or relative postoperative time
origin; - selected comorbidities; - relevant baseline characteristics.

Avoid unnecessary personal identifiers. Do not generate real names,
addresses, phone numbers, or medical record numbers.

## 9.3 Longitudinal observation fields

Suggested fields: - observation_id; - patient_id; - observation_datetime
or hours_since_surgery; - NRS score, when applicable; - CPOT score, when
applicable; - RASS score; - heart rate; - systolic and diastolic blood
pressure; - respiratory rate; - oxygen saturation; - temperature; -
recorded mobility status; - relevant clinical context.

The generator must produce plausible ranges and internally consistent
timestamps. These are synthetic values, not clinical reference ranges or
clinical guidance.

## 9.4 Medication fields

Suggested fields: - medication_record_id; - patient_id; - medication
category or generic medication name; - route; - recorded amount and
unit, if simulated; - administration timestamp or relative time; -
opioid exposure indicator; - synthetic morphine-equivalent exposure,
only if a defensible conversion method is documented.

Medication fields are for research-data demonstration only. The
application must not calculate or recommend doses.

## 9.5 Recovery fields

Suggested fields: - patient_id; - first_mobilization_time; -
mobilization_status; - ICU_length_of_stay; - recovery observation
window; - outcome-label definitions and provenance.

## 9.6 Data quality

The generator and validation scripts must check: - unique identifiers; -
valid data types; - allowed categorical values; - plausible synthetic
ranges; - timestamp order; - missing-value patterns; - consistency
between patient, observation, medication, and recovery records; -
target-label reproducibility; - absence of direct target leakage.

A data dictionary must describe every field, its type, allowed values,
unit, missing-value behavior, and whether it is an input, outcome, or
descriptive field.

# 10. Machine-Learning Specification

## 10.1 Baseline models

For each binary target, compare: - logistic regression; - random
forest; - gradient boosting (for example, scikit-learn
HistGradientBoosting or another documented implementation).

A simple baseline is preferred before adding complex models.

## 10.2 Data splitting

Use patient-level splitting. All observations belonging to one patient
must remain in only one partition. If the task is explicitly time-based,
use a time-aware design where appropriate.

Recommended initial split: - training set: 70%; - validation set: 15%; -
test set: 15%.

The exact strategy must be recorded. Do not tune models on the final
test set.

## 10.3 Evaluation metrics

Report, as appropriate: - AUROC; - AUPRC; - sensitivity/recall; -
specificity; - precision; - F1 score; - confusion matrix; - calibration
plot and a calibration metric.

For imbalanced outcomes, do not rely on accuracy alone. Report class
prevalence and explain the limitations of each metric.

## 10.4 Explainability

Use interpretable coefficients for logistic regression and suitable
feature-importance or SHAP-based explanations where appropriate.

Explanations must be described as model associations or contributions,
not proof of causality. The interface must not imply that a feature
caused the outcome.

## 10.5 Model limitations

Every report and interface must state: - models are trained on synthetic
data; - performance does not establish clinical validity; - synthetic
patterns may not reflect real clinical populations; - external
validation on appropriately governed real-world data would be required
before any clinical use; - predictions are not treatment
recommendations.

# 11. Clinical Knowledge Base and RAG Specification

## 11.1 Initial source categories

Prioritize authoritative and traceable sources, such as: - Society of
Critical Care Medicine (SCCM) PADIS guidelines and updates; - SCCM ICU
Liberation / ABCDEF bundle resources; - validated pain and sedation
assessment resources, including CPOT, BPS, and RASS materials where
relevant; - NICE guidance on rehabilitation after critical illness in
adults; - ERAS Society guidance relevant to postoperative recovery,
pain, and early mobilization; - peer-reviewed open-access research on
ICU pain assessment, early mobilization, functional recovery, opioid
exposure, and digital rehabilitation.

Use the latest available version where appropriate. Record the
publication or update date. Do not assume that a source remains current
merely because it is already in the local folder.

## 11.2 Source metadata

For every document, store: - document_id; - full title; - authors or
issuing organization; - publication/update year; - source type
(guideline, consensus statement, research article, assessment tool,
etc.); - journal or publisher, if applicable; - DOI or official URL; -
local filename; - version or access date; - relevant page, section, or
heading information; - copyright or permitted-use notes where known.

## 11.3 Ingestion and retrieval

The RAG pipeline must keep these operations separate and traceable:

1. **Document ingestion and chunking:** load approved documents; extract
   and clean text without removing clinically meaningful content; retain
   page and section information; split into overlapping chunks; and
   attach source metadata and stable identifiers to every chunk.
2. **Embedding generation:** use the configured embedding-provider
   interface to create vectors for chunks during ingestion and for user
   queries at retrieval time. The initial embedding provider is local
   Ollama using `nomic-embed-text`. Store the model name and vector
   dimensions with the index configuration. Do not send documents or
   queries to an external embedding service in the initial version.
3. **Vector retrieval:** search PostgreSQL with pgvector for relevant
   chunks. Return the exact stored chunk text, stable chunk ID, source
   metadata, and page/section location. Retrieval settings and any
   metadata filters must be configurable and documented.
4. **LLM response generation:** pass the user question and retrieved
   evidence to the configured chat-model provider. The initial provider
   is local Ollama using `gemma3:4b`. The response must distinguish
   retrieved literature from synthetic patient information and model
   estimates.
5. **Citation verification:** construct citations from retrieved chunk
   records rather than asking the model to invent citation details.
   Verify that each citation ID exists in the retrieval result and that
   cited source metadata and page/section locations match that record.
   Check that substantive clinical claims are supported by the cited
   passages. If support cannot be established, remove the unsupported
   claim or abstain and state that evidence is insufficient.

The chunking method, chunk size, overlap, embedding model, vector
dimensions, retrieval settings, and citation checks must be configurable
and documented. Embedding generation, vector retrieval, answer
generation, and citation verification are separate stages and must be
testable independently.

## 11.4 Citation requirements

Every substantive clinical or guideline-based claim in an
evidence-grounded answer must be supported by one or more retrieved
passages.

A citation should show, where available: - source title; - issuing
organization or authors; - year; - journal or guideline; - DOI or
official URL; - page, section, or heading.

A citation must refer to a source actually retrieved for that answer.
The assistant must never invent a title, DOI, page number, quotation, or
source.

If retrieval does not find adequate support, the assistant must say that
the available knowledge base does not provide enough evidence to answer
confidently.

## 11.5 Retrieval evaluation

Create a small manually reviewed test set of questions and relevant
source passages. Evaluate: - whether the correct document is
retrieved; - whether relevant passages appear near the top; - whether
the answer is supported by the retrieved passages; - whether citations
point to the correct source and location.

# 12. Large Language Model and Agent Workflow

## 12.1 LLM and model-provider abstraction

The initial chat and embedding provider is Ollama running locally on
Windows 11 at `http://localhost:11434`. Use `gemma3:4b` for chat and
`nomic-embed-text` for embeddings. The initial version must not require a
paid API, an API key, or an external LLM account.

The application must depend on provider interfaces rather than directly
on Ollama-specific request formats. Define separate interfaces for chat
generation and text embedding, with an Ollama adapter implementing both
capabilities. Provider selection and model names must come from
configuration. The RAG pipeline and LangGraph workflow must depend only
on those interfaces so another compatible provider can be added by
implementing an adapter, without rewriting retrieval or agent logic.

Add these environment variables to `.env.example` (with no secrets):

```dotenv
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_CHAT_MODEL=gemma3:4b
OLLAMA_EMBED_MODEL=nomic-embed-text
```

Keep `.env` out of version control. If a future provider requires
credentials, keep them server-side in environment variables and never
commit or expose them to frontend code. The initial local Ollama setup
must not make network calls to an external model provider.

### Provider error handling

Return safe, structured errors and log diagnostic context without
logging prompts, patient context, or credentials. The application must:

- report **Ollama not running** as a provider-unavailable error, explain
  that the local Ollama service should be started, and avoid an
  unhandled exception;
- report **model not downloaded** with the missing configured model tag
  and the local action needed to pull it; do not silently switch models;
- enforce a configurable request timeout and report **connection
  timeout** distinctly, allowing a bounded retry only where safe;
- report **insufficient local resources** (including an Ollama resource
  or model-load failure) as a recoverable local-capacity error, without
  retry loops or a fallback to an external service;
- validate response shape and required content, report **invalid model
  response** when it is malformed or empty, and do not present it as a
  successful answer; and
- preserve clinical safety behavior if any provider call fails: return
  an uncertainty/abstention response when needed and never bypass the
  safety or citation checks.

## 12.2 Agent workflow

Use LangGraph to implement a controlled workflow with these conceptual
stages:

1.  **Input validation:** validate the user question and request
    context.
2.  **Query classification:** identify whether the question concerns
    patient data, clinical evidence, model output, or general system
    help.
3.  **Patient-context retrieval:** retrieve only the relevant synthetic
    patient information.
4.  **Data sufficiency check:** identify missing or conflicting
    information.
5.  **Prediction retrieval:** obtain an existing model estimate or run
    an approved prediction function when requested.
6.  **Evidence retrieval:** retrieve relevant knowledge-base passages
    when needed.
7.  **Response drafting:** produce a concise answer grounded in the
    available context.
8.  **Safety and citation check:** check for unsupported clinical
    claims, fabricated citations, prescribing language, or autonomous
    decisions.
9.  **Final response:** return the answer with citations, limitations,
    and an appropriate notice.

Not every question needs every stage. The workflow should use
conditional routing.

## 12.3 Response behavior

The assistant must: - separate observed patient data from model
estimates and literature evidence; - state when data are missing; -
avoid fabricating measurements or clinical history; - distinguish
association from causation; - identify when evidence is conflicting or
limited; - avoid giving patient-specific treatment instructions; -
recommend clinician review rather than making a decision.

# 13. Safety, Privacy, and Responsible AI

This project is a research prototype and must remain restricted to
synthetic data during the initial phase.

Mandatory safeguards: - a persistent notice that the system is not for
clinical use; - no real patient names, identifiers, or records; - no EHR
integration; - no medication prescribing or order entry; - no autonomous
diagnosis or treatment decisions; - no claim of validated clinical risk
prediction; - clear distinction between model output and clinical
evidence; - local-only Ollama access for the initial version, with no
external model account or API key requirement; - server-side handling of
credentials if a future provider requires them; - input validation and
safe error handling; - basic access controls appropriate for local
research use; - no logging of secrets or unnecessary sensitive
information.

If real clinical data are ever considered in a future phase, that work
requires appropriate institutional approval, ethics review, data
governance, privacy safeguards, security review, and clinical oversight
before collection or processing.

# 14. Technical Architecture

## 14.1 Frontend

-   React
-   TypeScript
-   A modern component-based UI
-   Plotly or an equivalent charting library

Responsibilities: - patient list and profile; - patient timeline; -
prediction display; - cohort analytics; - AI chat interface; - citations
and source display; - research/admin views.

## 14.2 Backend

-   Python
-   FastAPI
-   Pydantic for request and response validation
-   SQLAlchemy for database access
-   Alembic for database migrations

Responsibilities: - API endpoints; - data validation; - patient and
observation retrieval; - model inference; - RAG retrieval; - LLM
orchestration; - audit-friendly application events and error handling.

The backend calls the configured model-provider interfaces. Only the
Ollama adapter knows the Ollama API. Patient data remain synthetic.

## 14.3 Database and vector search

-   PostgreSQL
-   pgvector extension

Initial logical entities: - patients; - observations; - assessments; -
medication_records; - recovery_outcomes; - model_predictions; -
documents; - document_chunks; - conversations; - messages.

Use foreign keys, indexes, timestamps, and migration scripts. Avoid
storing duplicated patient information unnecessarily.

## 14.4 Machine learning

-   pandas;
-   NumPy;
-   scikit-learn;
-   SHAP, if appropriate and technically justified.

Model training and evaluation should be separated from the online API
process. Save model artifacts with version and training metadata.

## 14.5 AI orchestration and retrieval

-   LangGraph for workflow orchestration;
-   LangChain components only where useful;
-   provider interfaces for chat generation and embedding generation;
-   Ollama as the initial local provider at `http://localhost:11434`;
-   `gemma3:4b` as the initial chat model;
-   `nomic-embed-text` as the initial embedding model;
-   PostgreSQL/pgvector for vector storage;
-   a RAG pipeline whose ingestion, embedding, retrieval, response
    generation, and citation-verification stages are independent of the
    selected provider.

Avoid unnecessary frameworks. Each dependency should have a clear role.

## 14.6 Development and deployment

Initial development should run locally on Windows 11. Use: - Visual
Studio Code; - Python virtual environment; - Git; - Ollama installed and
running locally at `http://localhost:11434`; - the configured chat and
embedding models downloaded locally; - Docker Compose when
database/container setup is introduced; - `.env` for local
configuration, excluded from Git; - `.env.example` with the Ollama
defaults above and placeholders only for any optional future secrets.

Cloud hosting is not required for the first working prototype.

# 15. Proposed Repository Structure

``` text
icu-pain-recovery-assistant/
│
├── README.md
├── spec.md
├── .gitignore
├── .env.example
├── docker-compose.yml
│
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── api/
│   │   ├── core/
│   │   ├── models/
│   │   ├── schemas/
│   │   ├── services/
│   │   ├── providers/       # Chat/embedding interfaces and Ollama adapter
│   │   ├── ml/
│   │   ├── rag/
│   │   └── agent/
│   ├── tests/
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   ├── public/
│   └── package.json
│
├── data/
│   ├── synthetic/
│   ├── processed/
│   └── data_dictionary/
│
├── knowledge_base/
│   ├── guidelines/
│   ├── assessment_tools/
│   ├── research_papers/
│   │   ├── pain_management/
│   │   ├── early_mobilization/
│   │   ├── functional_recovery/
│   │   └── digital_rehabilitation/
│   └── metadata/
│
├── models/
│   ├── artifacts/
│   └── evaluation/
│
├── scripts/
│   ├── generate_synthetic_data.py
│   ├── validate_data.py
│   ├── train_models.py
│   └── ingest_knowledge_base.py
│
├── reports/
│   ├── model_evaluation/
│   └── research_report/
│
└── docs/
    ├── architecture.md
    ├── data_dictionary.md
    ├── safety_and_limitations.md
    └── user_guide.md
```

This is a proposed structure. It may be adjusted during implementation,
but the project should remain modular and easy to understand.

# 16. Initial API Requirements

The exact route names may be refined during implementation. The backend
should provide equivalent functionality for:

  --------------------------------------------------------------------------------------
  Area                    Example endpoint                       Purpose
  ----------------------- -------------------------------------- -----------------------
  Health                  `GET /health`                          Check service status

  Patients                `GET /api/patients`                    List synthetic patients

  Patient profile         `GET /api/patients/{id}`               Retrieve a patient
                                                                 profile

  Timeline                `GET /api/patients/{id}/timeline`      Retrieve longitudinal
                                                                 data

  Predictions             `POST /api/predictions/{id}`           Generate or retrieve a
                                                                 research prediction

  Analytics               `GET /api/analytics/summary`           Cohort-level summaries

  Chat                    `POST /api/chat`                       Submit a question to
                                                                 the assistant

  Sources                 `GET /api/sources/{id}`                Retrieve source
                                                                 metadata

  Research                `GET /api/research/model-evaluation`   Retrieve evaluation
                                                                 results
  --------------------------------------------------------------------------------------

All endpoints must validate inputs and return structured errors. The API
must not expose secrets or internal stack traces.

# 17. Testing and Quality Assurance

## 17.1 Unit tests

Test: - data validation; - target-label generation; - leakage prevention
rules; - feature preparation; - model loading and inference; - retrieval
metadata; - citation validation; - API response schemas.

## 17.2 Integration tests

Test: - backend/database connection; - patient profile and timeline
retrieval; - model prediction endpoint; - document ingestion and
retrieval; - assistant workflow; - frontend/backend communication.

## 17.3 Safety tests

Include test questions that attempt to make the assistant: - prescribe
an opioid or another medication; - recommend a specific dose; - make an
autonomous mobilization decision; - invent a patient observation; -
answer without evidence while pretending to cite a source; - treat a
synthetic prediction as a validated clinical risk.

The expected behavior is to refuse or safely redirect the request,
explain limitations, and preserve clinician oversight.

## 17.4 Acceptance criteria

The initial prototype is considered technically complete when: 1. The
application runs locally using documented steps. 2. At least 5,000
synthetic patient records can be generated reproducibly. 3. Data
validation and data dictionary are available. 4. A user can open a
patient profile and inspect a chronological timeline. 5. Both prediction
tasks have baseline models and documented evaluation. 6. The evidence
pipeline ingests documents and retrieves source-linked passages. 7. The
assistant can answer supported questions with valid citations. 8.
Unsupported questions trigger an uncertainty or abstention response. 9.
Safety notices are visible and safety tests pass. 10. The README
explains setup, usage, architecture, data limitations, and research
limitations.

# 18. Development Phases and Deliverables

## Phase 1 --- Project foundation

Deliverables: - approved `spec.md`; - repository structure; - Python
environment; - Git repository; - minimal FastAPI application; - initial
README.

## Phase 2 --- Synthetic data

Deliverables: - synthetic data generator; - at least 5,000 synthetic
patients; - longitudinal observations and related records; - data
dictionary; - validation report; - target-label definitions.

## Phase 3 --- Database and backend

Deliverables: - PostgreSQL/pgvector setup; - database schema and
migrations; - patient and timeline APIs; - automated tests.

## Phase 4 --- Machine learning

Deliverables: - baseline models for both outcomes; - leakage-safe
patient-level evaluation; - metrics and plots; - model artifacts; -
limitations report.

## Phase 5 --- Clinical evidence and RAG

Deliverables: - curated source collection; - metadata catalog; -
ingestion and retrieval pipeline; - retrieval evaluation; - citation
verification.

## Phase 6 --- AI assistant

Deliverables: - LLM provider integration; - controlled agent workflow; -
patient-context retrieval; - evidence-grounded responses; - safety and
abstention checks.

## Phase 7 --- Frontend

Deliverables: - patient dashboard; - patient timeline; - predictions
view; - cohort analytics; - AI assistant and citations; - research
evaluation view.

## Phase 8 --- Integration and final portfolio package

Deliverables: - integrated local application; - unit and integration
test results; - safety test results; - setup and user documentation; -
architecture diagram; - research report; - screenshots or demonstration
recording using synthetic data.

# 19. Research Reporting Requirements

The final research report should include:

1.  Background and motivation.
2.  Research aims and questions.
3.  Synthetic dataset generation method.
4.  Operational definitions of both outcomes.
5.  Feature selection and leakage prevention.
6.  Model development and validation method.
7.  Model evaluation metrics and results.
8.  Explainability results and limitations.
9.  Knowledge-base selection and RAG method.
10. Retrieval and citation evaluation.
11. System architecture and implementation.
12. Safety, ethical, privacy, and governance considerations.
13. Limitations of synthetic data and generalizability.
14. Future work, including external validation and clinical
    collaboration requirements.

The report must not claim clinical effectiveness or clinical validity
from synthetic-data experiments.

# 20. Key Definitions and Glossary

  -----------------------------------------------------------------------
  Term                                Definition in this project
  ----------------------------------- -----------------------------------
  ICU                                 Intensive Care Unit

  Postoperative                       The period following a surgical
                                      procedure

  NRS                                 Numeric Rating Scale, a
                                      patient-reported pain rating

  CPOT                                Critical-Care Pain Observation
                                      Tool, an observational pain
                                      assessment

  RASS                                Richmond Agitation-Sedation Scale

  Early mobilization                  Initiation of appropriate physical
                                      activity or movement during
                                      recovery; the project's operational
                                      definition must be documented

  Functional recovery                 Recovery of activities or physical
                                      function relevant to the patient's
                                      postoperative course

  Machine learning (ML)               Methods that learn statistical
                                      patterns from data to estimate or
                                      classify outcomes

  Prediction target                   The outcome a model is trained to
                                      estimate

  Data leakage                        Use of information during model
                                      training that would not
                                      legitimately be available at
                                      prediction time

  AUROC                               Area under the receiver operating
                                      characteristic curve

  AUPRC                               Area under the precision-recall
                                      curve

  Calibration                         Agreement between predicted
                                      probabilities and observed outcome
                                      frequencies

  Explainability                      Methods that help describe how
                                      model inputs contribute to a model
                                      output

  RAG                                 Retrieval-augmented generation:
                                      retrieving external source passages
                                      and using them to ground a
                                      language-model response

  Embedding                           A numerical representation of text
                                      used for similarity search

  Vector database                     A database capability for storing
                                      and searching numerical vectors

  pgvector                            A PostgreSQL extension for vector
                                      similarity search

  LLM                                 Large language model

  Model-provider abstraction          Application interfaces for chat
                                      generation and embeddings, implemented
                                      by provider-specific adapters

  Ollama                              Local model-serving runtime used by
                                      the initial Windows development setup

  Agent workflow                      A controlled sequence of steps that
                                      routes a request through
                                      validation, retrieval, analysis,
                                      and response generation

  Synthetic data                      Artificially generated data that do
                                      not represent actual patient
                                      records

  Human-in-the-loop                   A design in which a qualified
                                      person remains responsible for
                                      reviewing and making decisions

  Clinical decision support           Software that organizes or presents
                                      information to support, but not
                                      replace, professional
                                      decision-making

  Model drift                         Change over time in input data or
                                      model performance

  External validation                 Evaluation of a model on an
                                      independent dataset from a
                                      different setting or population
  -----------------------------------------------------------------------

# 21. Decisions to Confirm Before Implementation

The following choices should be explicitly reviewed before coding:

1.  **Operational definition of uncontrolled pain:** specify the score
    threshold, eligible assessment type, and prediction window.
2.  **Operational definition of delayed mobilization:** specify the
    reference time and threshold.
3.  **Synthetic population:** confirm which surgery categories and
    comorbidities will be represented.
4.  **Prediction time:** define when each prediction is made and which
    data are available at that point.
5.  **Knowledge-base documents:** select the first set of authoritative
    documents and record their versions.
6.  **Interface language:** decide whether the prototype will be
    English-only initially.
7.  **Embedding index dimensions and migration (resolved):** the selected
    `nomic-embed-text` model returns 768-dimensional embeddings by default.
    Use `EMBEDDING_DIMENSION=768`; migration `0003_nomic_vector_768`
    upgrades an empty legacy 384-dimensional column and stops safely when
    vectors exist, requiring them to be regenerated instead of coerced.
8.  **Local resource and concurrency limits:** choose the minimum
    supported Windows hardware profile, maximum concurrent model
    requests, and default request timeout/retry limits for local use.
9.  **LangGraph state persistence:** decide whether graph execution
    state is request-scoped or persisted in PostgreSQL, separately from
    the conversation-history records already specified.

The initial provider choice is set: local Ollama at
`http://localhost:11434`, with `gemma3:4b` for chat and
`nomic-embed-text` for embeddings. It does not require approval to
replace the previous provider proposal.

Do not silently invent clinical thresholds or treat them as established
standards. Record and justify project-specific research choices.

# 22. Final Project Positioning

The most accurate description of this project is:

> A synthetic-data research prototype that integrates longitudinal
> postoperative ICU data, exploratory machine-learning models, and
> evidence-grounded AI assistance to study patterns associated with pain
> control and early functional recovery.

Its relevance to rehabilitation is its emphasis on mobility and
functional recovery, alongside postoperative pain. Its contribution is
an integrated technical research workflow---not a clinically validated
prediction system or autonomous medical agent.
