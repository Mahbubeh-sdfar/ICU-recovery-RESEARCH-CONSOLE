# ICU Pain & Recovery Assistant — Research Demonstration Report

**Review date:** 4 November 2026  
**Assessment type:** local software integration and synthetic-data demonstration  
**Clinical validation:** none. No real patient data was used or required.

## Result

The local demonstration stack is operational: React/TypeScript frontend, FastAPI, PostgreSQL with pgvector, local Ollama (`gemma3:4b` and `nomic-embed-text`), LangGraph workflow, document ingestion, vector retrieval, and saved synthetic-data ML experiments. The API and frontend are configured for loopback access. Research documents remain distinct from the artificial patient histories.

## Validation performed

- Backend test suite: **38 passed**, including an opt-in live test that created a query embedding with Ollama and retrieved a traceable passage through PostgreSQL/pgvector.
- Frontend: TypeScript and Vite production build succeeded. Vite reported a large JavaScript bundle warning (620 kB minified); this does not block the build.
- Dependency audit: npm previously reported zero known vulnerabilities after upgrading Vite and its React plugin. A repeat audit in this run could not reach `registry.npmjs.org` because network access was unavailable.
- PostgreSQL: Docker Compose pgvector service started; Alembic upgraded through revision 0003; synthetic import loaded 5,000 patients and 53,550 observations. Database validator confirmed nine expected tables, seven foreign keys, pgvector and an HNSW index, and no non-synthetic patient IDs.
- Research source: approved `padis-adult-2018` PDF extracted into 149 traceable chunks and embedded as 768-dimensional vectors. Re-running ingestion is idempotent. Extraction and indexing remain separate operations.
- Vector search: live `/api/evidence/search` returned retrieved document chunks with source identifiers and page/section provenance.
- Ollama: local model inventory confirmed both configured models; embedding dimensionality matched the 768-dimensional schema. A harmless chat smoke test returned a response.
- Application chat: live request traversed FastAPI → LangGraph → Ollama embedding → pgvector → Gemma. Gemma's draft did not pass citation verification, so the workflow withheld the draft and returned verified source records with an explicit no-clinical-conclusion message. This is safe behavior; it does not demonstrate reliable clinical answer generation.

## Architecture and safeguards

The browser talks to FastAPI over local REST/JSON. Synthetic cohort and recovery endpoints use the artificial CSV/DB records. LangGraph coordinates context validation, synthetic model outputs, evidence retrieval, safety checks, and response construction. An LLM/embedding provider interface isolates the workflow from Ollama. `RAGService` embeds queries using the configured local embedding model, searches pgvector by cosine distance, and maps each match to its document, stable chunk ID, section, and page. Lexical fallback is used only when the database is disabled or has no indexed rows.

The vector column uses 768 dimensions for `nomic-embed-text`; migration `0003_nomic_vector_768` refuses to reinterpret populated legacy vectors and requires re-embedding. The PDF extraction command itself does not call an LLM or generate embeddings; `scripts.embed_research_documents` is the separate local indexing step.

Patient histories are artificially generated. Research PDFs are source material, not synthetic histories. The assistant is not authorized to diagnose autonomously, prescribe, issue orders, or execute treatment. Unverified citation drafts are withheld. Predictions and saved metrics are synthetic-data experiments only.

## Known limitations

- The Gemma response in the live chat smoke test failed citation verification. The safe fallback worked, but users should not interpret the generated draft as a cited clinical summary.
- The frontend build emits a bundle-size warning. Code splitting could reduce initial download size.
- npm audit could not be repeated during this run due unavailable registry access; the last successful audit after dependency updates found zero vulnerabilities.
- No broad browser interaction, penetration test, or production deployment assessment was performed. The local API has no general user authentication; do not expose it beyond loopback.
- Synthetic ML performance does not imply real-world accuracy, clinical validity, or benefit.

## Reproducible checks

From `backend/`, with PostgreSQL and Ollama available and a document embedded:

```powershell
$env:RUN_DB_INTEGRATION = "1"
python -m pytest -q
```

From `frontend/`:

```powershell
npm run build
```

All results above are software demonstration checks, not clinical evidence or validation.
