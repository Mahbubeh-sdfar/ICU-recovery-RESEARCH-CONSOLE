$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$backendDir = Join-Path $projectRoot "backend"
$frontendDir = Join-Path $projectRoot "frontend"
$pythonExe = Join-Path $backendDir ".venv\Scripts\python.exe"
$dockerExe = "C:\Users\asus\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe"
$dockerDesktopExe = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
$nodePackageRoot = "C:\Users\asus\AppData\Local\Microsoft\WinGet\Packages"

if (-not (Test-Path $pythonExe)) { throw "Backend environment missing. Follow README.md installation steps first." }
if (-not (Test-Path (Join-Path $backendDir ".env"))) { throw "backend/.env missing. Copy backend/.env.example to backend/.env and configure it." }
if (-not (Test-Path $dockerExe)) { throw "Docker Desktop CLI was not found at $dockerExe." }

$env:PATH = "$(Split-Path $dockerExe);$env:PATH"
$engineReady = $false
try { & $dockerExe info --format "{{.ServerVersion}}" *> $null; $engineReady = ($LASTEXITCODE -eq 0) } catch { $engineReady = $false }
if (-not $engineReady) {
    if (Test-Path $dockerDesktopExe) {
        Start-Process -FilePath $dockerDesktopExe -WindowStyle Hidden
    } else {
        $alternateDockerDesktop = "C:\Users\asus\AppData\Local\Programs\DockerDesktop\Docker Desktop.exe"
        if (-not (Test-Path $alternateDockerDesktop)) { throw "Docker Desktop is installed but its application could not be found." }
        Start-Process -FilePath $alternateDockerDesktop -WindowStyle Hidden
    }
    for ($attempt = 0; $attempt -lt 36; $attempt++) {
        Start-Sleep -Seconds 5
        try { & $dockerExe info --format "{{.ServerVersion}}" *> $null; $engineReady = ($LASTEXITCODE -eq 0) } catch { $engineReady = $false }
        if ($engineReady) { break }
    }
    if (-not $engineReady) { throw "Docker Desktop did not become ready. Open Docker Desktop and rerun this script." }
}

Push-Location $backendDir
try {
    & $dockerExe compose -f docker-compose.yml up -d
    if ($LASTEXITCODE -ne 0) { throw "PostgreSQL/pgvector did not start." }
    & $pythonExe -m alembic upgrade head
    if ($LASTEXITCODE -ne 0) { throw "Database migrations failed. Check backend/.env and Docker status." }
    & $pythonExe -m scripts.ensure_synthetic_dataset
    if ($LASTEXITCODE -ne 0) { throw "Synthetic dataset initialization failed." }
}
finally { Pop-Location }

$logDir = Join-Path $backendDir ".tmp"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$apiReady = $false
try { Invoke-RestMethod "http://127.0.0.1:8000/health" -TimeoutSec 2 | Out-Null; $apiReady = $true } catch { $apiReady = $false }
if (-not $apiReady) {
    Start-Process -FilePath $pythonExe -ArgumentList @("-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000") -WorkingDirectory $backendDir -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logDir "api.out.log") -RedirectStandardError (Join-Path $logDir "api.err.log") | Out-Null
}

$frontendReady = $false
try { Invoke-WebRequest "http://127.0.0.1:5173" -TimeoutSec 2 | Out-Null; $frontendReady = $true } catch { $frontendReady = $false }
if (-not $frontendReady) {
    $nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($nodeCommand) {
        $nodeExe = $nodeCommand.Source
        $npmCli = Join-Path (Split-Path $nodeExe) "node_modules\npm\bin\npm-cli.js"
    } else {
        $nodePackage = Get-ChildItem $nodePackageRoot -Directory -ErrorAction SilentlyContinue | Where-Object Name -like "OpenJS.NodeJS.LTS*" | Select-Object -First 1
        if (-not $nodePackage) { throw "Node.js LTS was not found. Install Node.js 22.12 or newer." }
        $nodeDir = Get-ChildItem $nodePackage.FullName -Directory | Select-Object -First 1
        $nodeExe = Join-Path $nodeDir.FullName "node.exe"
        $npmCli = Join-Path $nodeDir.FullName "node_modules\npm\bin\npm-cli.js"
    }
    if (-not (Test-Path $npmCli)) { throw "npm was not found alongside Node.js. Install Node.js with npm." }
    if (-not (Test-Path (Join-Path $frontendDir "node_modules"))) { throw "Frontend dependencies missing. Run npm install in frontend/." }
    Start-Process -FilePath $nodeExe -ArgumentList @($npmCli, "run", "dev") -WorkingDirectory $frontendDir -WindowStyle Hidden -RedirectStandardOutput (Join-Path $frontendDir "vite.out.log") -RedirectStandardError (Join-Path $frontendDir "vite.err.log") | Out-Null
}

$apiReady = $false
$frontendReady = $false
for ($attempt = 0; $attempt -lt 24; $attempt++) {
    Start-Sleep -Seconds 2
    try { $health = Invoke-RestMethod "http://127.0.0.1:8000/health" -TimeoutSec 2; $apiReady = ($health.status -eq "ok") } catch { $apiReady = $false }
    try { $page = Invoke-WebRequest "http://127.0.0.1:5173" -TimeoutSec 2; $frontendReady = ($page.StatusCode -eq 200) } catch { $frontendReady = $false }
    if ($apiReady -and $frontendReady) { break }
}
if (-not $apiReady -or -not $frontendReady) { throw "A local app service did not start. Check backend/.tmp/api.err.log and frontend/vite.err.log." }

Write-Host "ICU Pain & Recovery Assistant is ready."
Write-Host "Dashboard: http://127.0.0.1:5173"
Write-Host "API docs:  http://127.0.0.1:8000/docs"
Write-Host "Synthetic patient records only."
