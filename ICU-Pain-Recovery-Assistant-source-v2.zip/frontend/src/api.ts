import type { ChatAnswer, Evaluation, Observation, Patient, Prediction, Summary } from './types';

export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
async function request<T>(path:string, init?:RequestInit):Promise<T> {
  let response:Response;
  try { response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers:{'Content-Type':'application/json',...init?.headers} }); }
  catch { throw new Error(`Cannot reach the API at ${API_BASE_URL}. Start FastAPI and check the API address.`); }
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try { const body = await response.json(); message = body?.error?.message || body?.detail || message; } catch { /* use status */ }
    throw new Error(String(message));
  }
  return response.json() as Promise<T>;
}
export const api = {
  summary:()=>request<Summary>('/api/analytics/summary'),
  patients:(limit=100,offset=0)=>request<{items:Patient[];total:number}>(`/api/patients?limit=${limit}&offset=${offset}`),
  patient:(id:string)=>request<Patient>(`/api/patients/${encodeURIComponent(id)}`),
  observations:(id:string)=>request<{items:Observation[];total:number}>(`/api/patients/${encodeURIComponent(id)}/observations?start_hour=0&end_hour=168&limit=500`),
  recovery:(id:string)=>request<Record<string,unknown>>(`/api/recovery/patients/${encodeURIComponent(id)}`),
  predict:(id:string,target:'uncontrolled_pain'|'delayed_mobilization')=>request<Prediction>(`/api/predictions/${encodeURIComponent(id)}`,{method:'POST',body:JSON.stringify({target,prediction_time_hours:6})}),
  chat:(question:string,patient_id:string|null,include_evidence=true)=>request<ChatAnswer>('/api/chat',{method:'POST',body:JSON.stringify({question,patient_id,include_evidence})}),
  evaluation:()=>request<Evaluation>('/api/research/model-evaluation'),
  source:(id:string)=>request<Record<string,unknown>>(`/api/evidence/sources/${encodeURIComponent(id)}`),
};
