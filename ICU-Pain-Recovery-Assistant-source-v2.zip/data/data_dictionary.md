# Synthetic postoperative ICU dataset: data dictionary

> **SIMULATED DATA ONLY.** Every patient, timestamp, assessment, vital sign, medication exposure, mobility event, and outcome in this file is artificially generated. Nothing represents an actual patient or establishes a real clinical distribution. This dataset is unsuitable for clinical validation, clinical decision-making, patient care, dosing, or claims about real-world performance.

## Dataset and generation

- File: `synthetic_icu_patients.csv`
- Grain: one row per simulated observation, with patient-level characteristics and outcomes repeated on each row. `patient_id` is the grouping key; `observation_id` is unique per row.
- Cohort: 5,000 simulated adult postoperative ICU patients and 53,550 longitudinal observations in the default generation.
- Reproduce: `node data/generate_synthetic_icu.mjs` (default seed `20261102`). Optional arguments: `--seed <integer>`, `--patients <integer>`, `--output <path>`.
- Time: observations every four simulated postoperative hours, from hour 0 through the simulated ICU stay (up to 168 hours). `observation_datetime_utc` is a synthetic sortable timestamp; it is not a real procedure date.
- Prediction index: 6 postoperative hours. A model feature must have been available by this time. At the four-hour cadence, eligible longitudinal records are hours 0 and 4 only. Baseline patient characteristics are available at index time.
- Split: deterministic patient-level 80/20 partition (`data_split`): 4,000 train patients and 1,000 test patients by default. All observations for a given patient remain in one partition. Do not randomly split rows.
- Missingness: blank CSV cells mean unavailable/not applicable. No missing values were imputed. NRS and CPOT are purposefully mutually exclusive; either may be missing due to simulated non-recording.
- Clinical relationships are hand-designed simulation mechanisms with random variation, not fitted to or calibrated against real clinical data. The generated distributions and associations are illustrative only.

## Operational outcomes (project-specific, not standards of care)

1. `uncontrolled_pain_target`: patient-level binary research label. Positive if at least one available assessment strictly after hour 6 and through hour 24 is NRS >= 4, or (when NRS is not applicable) CPOT >= 3. Blank if there is no eligible, observed assessment in that window. The target is repeated on each patient row for convenient joins. This threshold/window are arbitrary operational choices for this synthetic exercise.
2. `delayed_mobilization_target`: patient-level binary research label. Positive if first simulated mobilization occurs after 24 hours from surgery. For this dataset's generation, first mobilization is always simulated by 72 hours, so the complementary negative group mobilizes by 24 hours. The 24-hour threshold and surgery-time origin are arbitrary project choices, not clinical instructions.

### Leakage controls

For either model, first restrict to index-time features: baseline characteristics and longitudinal observations with `observation_hours_postop <= prediction_time_hours` (6). Aggregate eligible observations per patient using a documented method, then train/evaluate at the patient level. Never use either target as a feature. For the uncontrolled-pain target, exclude all post-index pain assessments and other post-index observations. For delayed mobilization, exclude all post-index records and all outcome or outcome-proxy fields, especially `first_mobilization_hours`, `mobilization_by_72h`, `mobility_status` after hour 6, `delayed_mobilization_target`, and `icu_length_of_stay_hours`. The complete CSV intentionally contains follow-up/outcome data and is not itself a ready-to-model feature matrix. The patient-level split is supplied; do not recompute it from rows.

## Fields

| Field | Type / unit | Allowed values or range | Missingness | Role and meaning |
|---|---|---|---|---|
| `patient_id` | string identifier | `SYN-` plus zero-padded sequence | Never | Synthetic patient grouping key; no real identifiers. Split key. |
| `observation_id` | string identifier | Patient ID plus `-T` and hour | Never | Unique synthetic observation key. |
| `observation_hours_postop` | integer hours | 0–168, four-hour increments | Never | Relative time from simulated surgery origin. Longitudinal index. |
| `observation_datetime_utc` | ISO 8601 UTC timestamp | Generated timestamp | Never | Sortable synthetic timestamp; equivalent to simulated patient offset plus postoperative hour. |
| `prediction_time_hours` | integer hours | 6 | Never | Shared prediction index; longitudinal inputs after this point are ineligible. |
| `data_split` | category | `train`, `test` | Never | Patient-level 80/20 holdout assignment; same value on all patient rows. |
| `age_years` | integer years | 18–90 | Never | Simulated demographic baseline. |
| `sex_category` | category | `female`, `male`, `another_or_not_recorded` | Never | Simulated demographic category; not intended to represent population frequencies. |
| `surgery_category` | category | `cardiac`, `abdominal`, `orthopedic`, `thoracic`, `vascular`, `other` | Never | Simulated broad surgery group. |
| `surgery_type` | category | Generated subgroup listed below | Never | Simulated surgery subtype nested under category. |
| `asa_class_simulated` | integer, ordinal | 1–5 | Never | Artificial ordinal severity marker; not an actual ASA assessment. |
| `bmi_kg_m2` | decimal kg/m² | 16–48 | Never | Simulated baseline body-mass index. |
| `diabetes` | binary integer | 0, 1 | Never | Simulated comorbidity indicator. |
| `cardiovascular_comorbidity` | binary integer | 0, 1 | Never | Simulated comorbidity indicator. |
| `chronic_pain` | binary integer | 0, 1 | Never | Simulated history indicator. |
| `pulmonary_comorbidity` | binary integer | 0, 1 | Never | Simulated comorbidity indicator. |
| `baseline_severity_index` | decimal, unitless | 0–1 | Never | Artificial generator latent severity summary; not a validated score. Baseline candidate feature only for this simulated exercise. |
| `nrs_pain_score` | integer score | 0–10 | Blank if CPOT used or simulated non-recording | Simulated self-report assessment. Candidate feature only at/before index; after index contributes to pain target. |
| `cpot_pain_score` | integer score | 0–8 | Blank if NRS used or simulated non-recording | Simulated observational assessment when self-report is unavailable. Not interchangeable with NRS. Candidate feature only at/before index; after index contributes to pain target. |
| `pain_assessment_type` | category | `NRS`, `CPOT` | Never | Which assessment is represented for the observation. |
| `rass_score` | integer score | -5 to +4 | Occasionally blank | Simulated sedation/agitation score. Candidate feature only at/before index. |
| `heart_rate_bpm` | integer beats/min | 42–148 | Occasionally blank | Simulated vital sign; candidate feature only at/before index. |
| `systolic_bp_mmhg` | integer mmHg | 78–205 | Occasionally blank | Simulated systolic blood pressure; candidate feature only at/before index. |
| `diastolic_bp_mmhg` | integer mmHg | 38–125 | Occasionally blank | Simulated diastolic blood pressure; candidate feature only at/before index. |
| `respiratory_rate_bpm` | integer breaths/min | 7–38 | Occasionally blank | Simulated respiratory rate; candidate feature only at/before index. |
| `oxygen_saturation_pct` | decimal percent | 82–100 | Occasionally blank | Simulated oxygen saturation; candidate feature only at/before index. |
| `medication_category` | category | `none`, `nonopioid`, `opioid`, `multimodal` | Never | Simulated medication-exposure category for the interval/observation; not a medication order. Candidate feature only at/before index. |
| `medication_route` | category | `none`, `oral`, `intravenous`, `epidural`, `other` | Never | Simulated route category; not a dosing instruction. Candidate feature only at/before index. |
| `medication_exposure_index` | integer ordinal, unitless | 0–3 | Never | Arbitrary exposure-intensity index, not a dose or dose equivalent. Candidate feature only at/before index. |
| `opioid_exposure` | binary integer | 0, 1 | Never | Simulated indicator; not dose, morphine equivalents, or a recommendation. Candidate feature only at/before index. |
| `mobility_status` | category | `in_bed`, `bed_exercises`, `chair_or_standing`, `walking_assisted` | Never | Simulated status at observation time. At/before index may describe baseline; after index is post-index and must be excluded from delayed-mobilization features. |
| `first_mobilization_hours` | decimal hours | 6–72, or blank if >72 (not generated in default setup) | May be blank | Simulated recovery outcome; never a predictor for delayed mobilization. |
| `mobilization_by_72h` | binary integer | 0, 1 | Never | Simulated recovery descriptor; an outcome proxy and prohibited predictor for delayed mobilization. |
| `icu_length_of_stay_hours` | decimal hours | 24–240 | Never | Simulated descriptive outcome; future information and prohibited predictor at 6-hour index. |
| `uncontrolled_pain_target` | binary integer | 0, 1, or blank | Blank if no eligible observed future score | Target 1. Never a feature. Patient-level label repeated across rows. |
| `delayed_mobilization_target` | binary integer | 0, 1 | Never | Target 2. Never a feature. Patient-level label repeated across rows. |

### Surgery subtype values

`cardiac`: `bypass`, `valve`, `other_cardiac`; `abdominal`: `colorectal`, `hepatobiliary`, `other_abdominal`; `orthopedic`: `joint_replacement`, `spine`, `other_orthopedic`; `thoracic`: `lung_resection`, `other_thoracic`; `vascular`: `aortic`, `peripheral`, `other_vascular`; `other`: `transplant`, `complex_other`.

## Validation performed by the generator

Running the generator writes the CSV and checks: requested patient count; unique patient grouping and observation identifiers; strictly ordered unique observation times per patient; a single train/test partition per patient; allowed value ranges for pain, RASS, and vital-sign fields; and mutual exclusivity of NRS and CPOT. The generator stops with an error if these checks fail. Seed, counts, split sizes, target counts, and validation result are printed to the console.

The generator does not claim statistical, clinical, or external validation. The emitted file deliberately includes repeated patient-level columns so ordinary row-level model splitting or unrestricted use of all columns can leak patient identity, future information, or outcome definitions.

### Default generation check (seed `20261102`)

Validation passed for 5,000 unique patients, 53,550 unique observations, 4,000 train patients, and 1,000 test patients. Both targets were reproducible from the emitted observed fields; the pain label was available for all 5,000 patients. There were 2,206 positive pain labels and 2,271 positive delayed-mobilization labels in this particular artificial run. These figures describe only this generator output and are not clinical prevalence estimates.
