#!/usr/bin/env node
// Reproducible generator for an artificial postoperative ICU research dataset.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const arg = (name, fallback) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : fallback; };
const n = Number(arg('--patients', '5000'));
const seed = Number(arg('--seed', '20261102')) >>> 0;
const output = path.resolve(arg('--output', path.join(here, 'synthetic_icu_patients.csv')));
let state = seed || 1;
const rand = () => { state = (Math.imul(1664525, state) + 1013904223) >>> 0; return state / 4294967296; };
const normal = () => Math.sqrt(-2 * Math.log(Math.max(rand(), 1e-12))) * Math.cos(2 * Math.PI * rand());
const pick = (xs, weights) => { let x = rand() * weights.reduce((a, b) => a + b, 0); for (let i = 0; i < xs.length; i++) { x -= weights[i]; if (x <= 0) return xs[i]; } return xs.at(-1); };
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const round = (x, digits = 0) => Number(x.toFixed(digits));
const missing = (x, p) => rand() < p ? '' : x;
const surgeries = ['cardiac', 'abdominal', 'orthopedic', 'thoracic', 'vascular', 'other'];
const types = {
  cardiac: ['bypass', 'valve', 'other_cardiac'], abdominal: ['colorectal', 'hepatobiliary', 'other_abdominal'],
  orthopedic: ['joint_replacement', 'spine', 'other_orthopedic'], thoracic: ['lung_resection', 'other_thoracic'],
  vascular: ['aortic', 'peripheral', 'other_vascular'], other: ['transplant', 'complex_other'],
};
const fields = ['patient_id','observation_id','observation_hours_postop','observation_datetime_utc','prediction_time_hours','data_split',
  'age_years','sex_category','surgery_category','surgery_type','asa_class_simulated','bmi_kg_m2','diabetes','cardiovascular_comorbidity',
  'chronic_pain','pulmonary_comorbidity','baseline_severity_index','nrs_pain_score','cpot_pain_score','pain_assessment_type','rass_score',
  'heart_rate_bpm','systolic_bp_mmhg','diastolic_bp_mmhg','respiratory_rate_bpm','oxygen_saturation_pct','medication_category',
  'medication_route','medication_exposure_index','opioid_exposure','mobility_status','first_mobilization_hours','mobilization_by_72h',
  'icu_length_of_stay_hours','uncontrolled_pain_target','delayed_mobilization_target'];
const esc = v => { const s = String(v ?? ''); return /[",\r\n]/.test(s) ? `"${s.replaceAll('"','""')}"` : s; };
const shuffled = Array.from({length:n}, (_,i)=>i+1);
for(let i=shuffled.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];}
const split = new Map(shuffled.map((id,i)=>[id, i<Math.round(n*.8)?'train':'test']));
const rows = [];
const base = Date.UTC(2025,0,1);
for(let id=1;id<=n;id++){
  const patient=`SYN-${String(id).padStart(5,'0')}`;
  const age=Math.round(clamp(18+rand()*72,18,90));
  const sex=pick(['female','male','another_or_not_recorded'],[48,50,2]);
  const surgery=pick(surgeries,[21,25,20,12,11,11]);
  const surgeryType=types[surgery][Math.floor(rand()*types[surgery].length)];
  const diabetes=+(rand()<.12+.1*(age>65));
  const cardio=+(rand()<.16+.2*(age>65)+.1*(surgery==='cardiac'));
  const chronic=+(rand()<.23), pulmonary=+(rand()<.1+.1*(age>65));
  const bmi=round(clamp(27+5*normal(),16,48),1);
  const severity=round(clamp(.45+.12*(age>70)+.1*cardio+.1*(surgery==='cardiac')+.18*normal(),0,1),3);
  const asa=Math.round(clamp(2+2*severity+.4*normal(),1,5));
  const pain=clamp(.34+.18*chronic+.12*(['abdominal','thoracic'].includes(surgery))+.12*severity-.1*(surgery==='cardiac')+.12*normal(),.05,.9);
  const delayP=clamp(.2+.3*severity+.16*(surgery==='cardiac')+.12*(surgery==='vascular')+.12*(age>75)+.12*chronic+.12*normal(),.05,.95);
  const delayed=+(rand()<delayP);
  const mobilize=round(delayed?clamp(24.5+rand()*(72-24.5),24.5,72):clamp(6+rand()*18,6,24),1);
  const los=round(clamp(Math.exp(3+.6*severity+.35*delayed+.25*(surgery==='cardiac')+.45*normal()),24,240),1);
  const patientRows=[];
  for(let hour=0;hour<=168&&hour<=los;hour+=4){
    const recovery=Math.min(hour/los,1);
    const nrsLatent=clamp(1.0+2*pain+.5*chronic+.35*(['abdominal','thoracic'].includes(surgery))-.5*recovery+1.15*normal(),0,10);
    const rass=Math.round(clamp(-.2-1.6*severity+.9*recovery+normal(),-5,4));
    const canReport=!(rass<=-3||(hour===0&&rand()<.18));
    const nrs=canReport?Math.round(nrsLatent):'';
    const cpot=canReport?'':Math.round(clamp(1.1+2.7*pain+.9*(['abdominal','thoracic'].includes(surgery))-.35*recovery+normal(),0,8));
    const assessment=canReport?'NRS':'CPOT';
    const hr=Math.round(clamp(78+1.8*nrsLatent+10*severity-.08*hour+9*normal(),42,148));
    const sbp=Math.round(clamp(119+2*nrsLatent+11*severity+14*normal(),78,205));
    const dbp=Math.round(clamp(70+.8*nrsLatent+5*severity+9*normal(),38,125));
    const rr=Math.round(clamp(16+.55*nrsLatent+2.2*pulmonary+1.7*severity+3*normal(),7,38));
    const spo2=round(clamp(97-2*pulmonary-1.7*severity+2*normal(),82,100),1);
    const med=rand()<.12?'none':pick(['nonopioid','opioid','multimodal'],[.28,.58+.15*pain-.1*(rass<=-3),.4]);
    const route=med==='none'?'none':pick(['oral','intravenous','epidural','other'],[.28,.48,.12,.12]);
    const exposure=med==='none'?0:pick([1,2,3],[.55,.33,.12]);
    const opioid=+(['opioid','multimodal'].includes(med)&&rand()<.78);
    const mobility=hour>=mobilize?pick(['chair_or_standing','walking_assisted'],[.7,.3]):hour>=12&&rand()<(.12+.2*recovery)?'bed_exercises':'in_bed';
    const dt=new Date(base+id*86400000+hour*3600000).toISOString();
    patientRows.push({patient_id:patient,observation_id:`${patient}-T${String(hour).padStart(3,'0')}`,observation_hours_postop:hour,
      observation_datetime_utc:dt,prediction_time_hours:6,data_split:split.get(id),age_years:age,sex_category:sex,surgery_category:surgery,
      surgery_type:surgeryType,asa_class_simulated:asa,bmi_kg_m2:bmi,diabetes,cardiovascular_comorbidity:cardio,chronic_pain:chronic,
      pulmonary_comorbidity:pulmonary,baseline_severity_index:severity,nrs_pain_score:canReport?missing(nrs,.04):'',
      cpot_pain_score:canReport?'':missing(cpot,.04),pain_assessment_type:assessment,rass_score:missing(rass,.025),heart_rate_bpm:missing(hr,.025),
      systolic_bp_mmhg:missing(sbp,.025),diastolic_bp_mmhg:missing(dbp,.025),respiratory_rate_bpm:missing(rr,.025),
      oxygen_saturation_pct:missing(spo2,.025),medication_category:med,medication_route:route,medication_exposure_index:exposure,
      opioid_exposure:opioid,mobility_status:mobility,first_mobilization_hours:mobilize<=72?mobilize:'',mobilization_by_72h:+(mobilize<=72),
      icu_length_of_stay_hours:los});
  }
  const future=[];
  for(const r of patientRows) if(r.observation_hours_postop>6&&r.observation_hours_postop<=24){
    const score=r.nrs_pain_score!==''?r.nrs_pain_score:r.cpot_pain_score;
    const threshold=r.nrs_pain_score!==''?4:3;
    if(score!=='')future.push(+score>=threshold);
  }
  const painTarget=future.length?+(future.some(Boolean)):'';
  for(const r of patientRows){r.uncontrolled_pain_target=painTarget;r.delayed_mobilization_target=delayed;rows.push(r);}
}
const lines=[fields.join(','),...rows.map(r=>fields.map(f=>esc(r[f])).join(','))];
fs.mkdirSync(path.dirname(output),{recursive:true});
fs.writeFileSync(output,lines.join('\n')+'\n','utf8');

// Validation checks run against emitted records; splitting is by patient, never row.
const byPatient=new Map();for(const r of rows){if(!byPatient.has(r.patient_id))byPatient.set(r.patient_id,[]);byPatient.get(r.patient_id).push(r);}
const errors=[];
if(byPatient.size!==n)errors.push(`patient count ${byPatient.size} != ${n}`);
for(const [p,rs] of byPatient){
  const times=rs.map(r=>r.observation_hours_postop);
  if(new Set(times).size!==times.length||times.some((x,i)=>i&&x<=times[i-1]))errors.push(`timestamps unordered/duplicated ${p}`);
  if(new Set(rs.map(r=>r.data_split)).size!==1)errors.push(`split leakage ${p}`);
  if(new Set(rs.map(r=>r.uncontrolled_pain_target)).size!==1||new Set(rs.map(r=>r.delayed_mobilization_target)).size!==1)errors.push(`inconsistent patient target ${p}`);
  const future=[];
  for(const r of rs)if(r.observation_hours_postop>6&&r.observation_hours_postop<=24){
    const score=r.nrs_pain_score!==''?r.nrs_pain_score:r.cpot_pain_score, threshold=r.nrs_pain_score!==''?4:3;
    if(score!=='')future.push(+score>=threshold);
  }
  const expectedPain=future.length?+(future.some(Boolean)):'';
  if(rs[0].uncontrolled_pain_target!==expectedPain)errors.push(`pain target not reproducible from observed values ${p}`);
  const expectedDelay=+(Number(rs[0].first_mobilization_hours)>24);
  if(rs[0].delayed_mobilization_target!==expectedDelay)errors.push(`mobilization target inconsistent ${p}`);
  for(const r of rs){
    for(const [k,lo,hi] of [['nrs_pain_score',0,10],['cpot_pain_score',0,8],['rass_score',-5,4],['heart_rate_bpm',42,148],['systolic_bp_mmhg',78,205],['diastolic_bp_mmhg',38,125],['respiratory_rate_bpm',7,38],['oxygen_saturation_pct',82,100]])if(r[k]!==''&&(Number(r[k])<lo||Number(r[k])>hi))errors.push(`range ${k} ${p}`);
    if(r.pain_assessment_type==='NRS'&&r.cpot_pain_score!==''||r.pain_assessment_type==='CPOT'&&r.nrs_pain_score!=='')errors.push(`assessment mismatch ${p}`);
  }
}
if(errors.length)throw new Error(errors.slice(0,10).join('; '));
const positive=(field)=>new Set(rows.filter(r=>r[field]==='1'||r[field]===1).map(r=>r.patient_id)).size;
const summary={validation:'PASS',seed,patients:byPatient.size,observations:rows.length,train_patients:[...split.values()].filter(x=>x==='train').length,
  test_patients:[...split.values()].filter(x=>x==='test').length,patients_with_pain_label:new Set(rows.filter(r=>r.uncontrolled_pain_target!==''&&r.uncontrolled_pain_target!==null).map(r=>r.patient_id)).size,
  pain_positive_patients:positive('uncontrolled_pain_target'),delayed_mobilization_positive_patients:positive('delayed_mobilization_target'),
  unique_observation_ids:new Set(rows.map(r=>r.observation_id)).size};
console.log(JSON.stringify(summary,null,2));
